// Copia o leitor de imagem (OCR) e o modelo de português para dentro do site: nada é baixado de fora.
import { cpSync, mkdirSync } from 'node:fs';
import { createRequire } from 'node:module';
import { dirname, join } from 'node:path';
const require = createRequire(import.meta.url);
const dir = p => dirname(require.resolve(p + '/package.json'));
const out = new URL('../public/ocr/', import.meta.url).pathname;
mkdirSync(out, { recursive: true });
cpSync(join(dir('tesseract.js'), 'dist', 'worker.min.js'), join(out, 'worker.min.js'));
for (const f of ['tesseract-core-lstm.wasm.js', 'tesseract-core-simd-lstm.wasm.js', 'tesseract-core-lstm.js', 'tesseract-core-simd-lstm.js', 'tesseract-core-lstm.wasm', 'tesseract-core-simd-lstm.wasm'])
  cpSync(join(dir('tesseract.js-core'), f), join(out, f));
cpSync(join(dir('@tesseract.js-data/por'), '4.0.0_best_int', 'por.traineddata.gz'), join(out, 'por.traineddata.gz'));
console.log('OCR copiado para public/ocr');
