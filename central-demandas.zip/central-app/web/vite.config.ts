import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
const DEMO = process.env.VITE_DEMO === '1';
export default defineConfig({
  base: DEMO ? './' : '/',
  publicDir: DEMO ? false : 'public',
  plugins: [react()],
  server: { port: 5173, proxy: { '/api': 'http://localhost:3000', '/health': 'http://localhost:3000' } },
  build: { outDir: DEMO ? 'dist-demo' : 'dist', sourcemap: false, chunkSizeWarningLimit: 1500 },
});
