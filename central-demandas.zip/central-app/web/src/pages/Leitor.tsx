import { useEffect, useRef, useState } from 'react';
import { get, post, put, del, upload, fmtDT, ApiError } from '../api';
import { useApp, canWrite } from '../ctx';
import { toRow, toBR, money, brToISO, addDays, refPeriod, type Row, type Supplier } from '../nf/parse';
import { readFile } from '../nf/read';

const COLS: { k: keyof Row; t: string; w: number; r?: boolean }[] = [
  { k: 'mes', t: 'Mês', w: 55 }, { k: 'qz', t: 'QZ', w: 45 }, { k: 'base', t: 'Base', w: 80 }, { k: 'codigo', t: 'Código', w: 110 }, { k: 'fornecedor', t: 'Fornecedor', w: 230 },
  { k: 'rc', t: 'RC', w: 100 }, { k: 'po', t: 'PO', w: 110 }, { k: 'migo', t: 'MIGO', w: 90 }, { k: 'nf', t: 'Nº NF', w: 80 }, { k: 'valor', t: 'Valor total', w: 110, r: true },
  { k: 'emissao', t: 'Emissão', w: 105 }, { k: 'venc', t: 'Vencimento', w: 105 }, { k: 'envio', t: 'Envio central', w: 110 }];
const REQUIRED: (keyof Row)[] = ['fornecedor', 'nf', 'valor', 'emissao', 'venc'];
const uid = () => crypto.randomUUID();
const clean = (v: unknown) => String(v ?? '').replace(/[\t\r\n]+/g, ' ').trim();
const loadPrefs = () => { try { return JSON.parse(localStorage.getItem('nf.prefs') || '') as { venc: number; dias: number }; } catch { return { venc: 30, dias: 7 }; } };

export default function Leitor() {
  const { team, toast } = useApp();
  const [rows, setRows] = useState<Row[]>([]);
  const [sup, setSup] = useState<Supplier[]>([]);
  const [prefs, setPrefs] = useState(loadPrefs);
  // arquivo original de cada linha: vai junto para a nota quando salvar na equipe (PDF/XML)
  const arquivos = useRef(new Map<string, File>());
  const [guardar, setGuardar] = useState(true);
  const [prog, setProg] = useState<{ done: number; total: number } | null>(null);
  const [over, setOver] = useState(false);
  const [drafts, setDrafts] = useState<any[]>([]);
  const [draftId, setDraftId] = useState<string>(() => uid());
  const [draftName, setDraftName] = useState('');
  const fileRef = useRef<HTMLInputElement>(null);
  const write = canWrite(team);

  useEffect(() => { if (team) get(`/api/teams/${team.id}/fornecedores`).then(setSup).catch(() => setSup([])); }, [team]);
  const loadDrafts = () => get('/api/rascunhos').then(setDrafts).catch(() => {});
  useEffect(() => { loadDrafts(); }, []);
  useEffect(() => { try { localStorage.setItem('nf.prefs', JSON.stringify(prefs)); } catch { /* sem armazenamento */ } }, [prefs]);

  const handle = async (list: File[]) => {
    const files = list.filter(f => /\.(pdf|xml|jpe?g|png|webp|bmp|tiff?)$/i.test(f.name) || /pdf|xml|image/.test(f.type)).slice(0, 100);
    if (!files.length) { toast('Envie arquivos PDF, XML ou imagem.'); return; }
    const jobs = files.map(f => ({ f, id: uid() }));
    for (const j of jobs) arquivos.current.set(j.id, j.f);
    setRows(r => [...r, ...jobs.map(j => ({ id: j.id, file: j.f.name, status: 'load' as const, warn: [], mes: '', qz: '', base: '', codigo: '', fornecedor: '', cnpj: '', rc: '', po: '', migo: '', nf: '', valor: '', emissao: '', venc: '', envio: '' }))]);
    let done = 0; setProg({ done, total: jobs.length });
    for (const j of jobs) { // uma por vez: o leitor de imagem é pesado
      try { const d = await readFile(j.f); const r = toRow(j.f.name, d, sup, prefs); setRows(rs => rs.map(x => x.id === j.id ? { ...x, ...r } as Row : x)); }
      catch (e) { setRows(rs => rs.map(x => x.id === j.id ? { ...x, status: 'err', msg: (e as Error).message } : x)); }
      setProg({ done: ++done, total: jobs.length });
    }
    setTimeout(() => setProg(null), 1500);
  };

  const edit = (id: string, k: keyof Row, raw: string) => setRows(rs => rs.map(r => {
    if (r.id !== id) return r;
    let v = raw.trim(); const n: Row = { ...r };
    if (k === 'emissao' || k === 'venc' || k === 'envio') v = toBR(v);
    if (k === 'valor') v = money(v);
    (n as any)[k] = v;
    if (k === 'emissao') { const p = refPeriod(v); n.mes = p.mes; n.qz = p.qz; n.venc = addDays(v, prefs.venc) || n.venc; n.envio = addDays(n.venc, -prefs.dias); }
    if (k === 'venc') n.envio = addDays(v, -prefs.dias);
    if (k === 'codigo' || k === 'base' || k === 'fornecedor') {
      const e = k === 'codigo' ? sup.find(s => s.codigo.toUpperCase() === v.toUpperCase() && (!n.base || s.base?.toUpperCase() === n.base.toUpperCase())) ?? sup.find(s => s.codigo.toUpperCase() === v.toUpperCase())
        : k === 'base' ? sup.find(s => s.base?.toUpperCase() === v.toUpperCase()) : undefined;
      if (e) { n.codigo = e.codigo; n.base = e.base ?? n.base; n.fornecedor = e.nome; }
    }
    if (k !== 'migo') n.warn = n.warn.filter(w => !w.toLowerCase().startsWith(k === 'nf' ? 'nº nf' : k));
    return n;
  }));

  const ready = rows.filter(r => r.status === 'ok');
  const missing = (r: Row) => REQUIRED.filter(k => !r[k]);
  const tsv = (list: Row[], head: boolean) => [...(head ? [COLS.map(c => c.t.toUpperCase()).join('\t')] : []), ...list.map(r => COLS.map(c => clean(r[c.k])).join('\t'))].join('\n');
  const copy = async (head: boolean) => {
    try { await navigator.clipboard.writeText(tsv(ready, head)); toast(`${ready.length} linha${ready.length === 1 ? '' : 's'} copiada${ready.length === 1 ? '' : 's'}. Cole no Excel com Ctrl+V.`); }
    catch { toast('Não consegui copiar. Selecione a tabela e copie com Ctrl+C.'); }
  };
  const saveTeam = async () => {
    if (!team) return;
    const bad = ready.filter(r => missing(r).length);
    if (bad.length) { toast(`Complete os campos amarelos de ${bad.length} linha${bad.length > 1 ? 's' : ''} antes de salvar.`); return; }
    try {
      const r = await post(`/api/teams/${team.id}/notas`, { notas: ready.map(x => ({ mes: x.mes, qz: x.qz, base: x.base, codigo: x.codigo, fornecedor: x.fornecedor, cnpj: x.cnpj || null,
        rc: x.rc, po: x.po, migo: x.migo, numero_nf: x.nf, valor: x.valor || null, emissao: brToISO(x.emissao), vencimento: brToISO(x.venc), envio_central: brToISO(x.envio) })) });
      let anexados = 0, falhas = 0;
      if (guardar) for (let i = 0; i < ready.length; i++) {
        const f = arquivos.current.get(ready[i].id), id = r.ids?.[i];
        if (!f || !id || !/\.(pdf|xml)$/i.test(f.name)) continue;
        try { await upload(`/api/teams/${team.id}/notas/${id}/anexos`, f, f.name); anexados++; } catch { falhas++; }
      }
      toast(`${r.criadas} nota${r.criadas === 1 ? '' : 's'} salva${r.criadas === 1 ? '' : 's'} na equipe${anexados ? ` com ${anexados} arquivo${anexados > 1 ? 's' : ''}` : ''}${r.duplicadas.length ? ` · já existiam: ${r.duplicadas.join(', ')}` : ''}${falhas ? ` · ${falhas} arquivo${falhas > 1 ? 's' : ''} não foi anexado` : ''}`);
    } catch (x) { const e = x as ApiError; toast(e.fields?.length ? `Dado inválido: ${e.fields[0].path} (${e.fields[0].message})` : e.message); }
  };
  const saveDraft = async () => {
    const name = draftName.trim() || `Leitura de ${new Date().toLocaleDateString('pt-BR')}`;
    try { await put(`/api/rascunhos/${draftId}`, { nome: name, linhas: rows.filter(r => r.status !== 'load').map(({ warn, msg, status, ...r }) => r) }); setDraftName(name); toast('Rascunho salvo (só você vê).'); loadDrafts(); }
    catch (x) { toast((x as ApiError).message); }
  };
  const openDraft = (d: any) => { setDraftId(d.id); setDraftName(d.nome); setRows((d.linhas as any[]).map(r => ({ ...r, id: r.id || uid(), status: 'ok', warn: [] }))); };

  return <>
    <div><p className="sect">Leitor de NF</p><h2 className="ptitle">Solte as notas. A linha da planilha já sai pronta.</h2>
      <p className="lead">Lê PDF, XML ou foto da nota no seu próprio computador (o arquivo não é enviado ao servidor) e preenche as 13 colunas da planilha de controle. Confira as células amarelas, salve na equipe e copie para o Excel.</p></div>
    <div className="two">
      <label className={'drop' + (over ? ' over' : '')} onDragOver={e => { e.preventDefault(); setOver(true); }} onDragLeave={() => setOver(false)}
        onDrop={e => { e.preventDefault(); setOver(false); handle([...e.dataTransfer.files]); }}>
        <strong>Arraste as notas para cá</strong><span className="from">ou clique para escolher · PDF, XML ou imagem · várias de uma vez</span>
        <input ref={fileRef} type="file" multiple accept=".pdf,.xml,image/*,application/pdf,text/xml" aria-label="Escolher notas fiscais" onChange={e => { handle([...(e.target.files ?? [])]); e.target.value = ''; }} />
      </label>
      <div className="box" style={{ display: 'grid', gap: 12, alignContent: 'start' }}>
        <p className="sect">Regras de datas</p>
        <div className="fields" style={{ marginTop: 0 }}>
          <label>Vencimento: dias após a emissão<input type="number" min={0} max={365} value={prefs.venc} onChange={e => setPrefs(p => ({ ...p, venc: Number(e.target.value) || 0 }))} /></label>
          <label>Envio à central: dias antes do vencimento<input type="number" min={0} max={365} value={prefs.dias} onChange={e => setPrefs(p => ({ ...p, dias: Number(e.target.value) || 0 }))} /></label>
        </div>
        <p className="from" style={{ margin: 0 }}>Mês e quinzena saem da data de emissão (quinzena anterior à emissão). Fornecedor, código e base vêm do cadastro de fornecedores da equipe{sup.length ? ` (${sup.length} cadastrados)` : ' (ainda vazio)'}.</p>
      </div>
    </div>
    {prog && <div className="status" role="status">Lendo {Math.min(prog.done + 1, prog.total)} de {prog.total}…<div className="ptrack"><div className="pfill" style={{ width: `${Math.round(100 * prog.done / prog.total)}%` }} /></div></div>}
    <div className="bar">
      <div className="row" style={{ marginTop: 0 }}>
        <input aria-label="Nome do rascunho" placeholder="Nome desta leitura (opcional)" value={draftName} maxLength={120} onChange={e => setDraftName(e.target.value)} style={{ width: 260 }} />
        <span className="count">{rows.length} linha{rows.length === 1 ? '' : 's'} · {ready.length} pronta{ready.length === 1 ? '' : 's'}</span>
      </div>
      <div className="row" style={{ marginTop: 0 }}>
        <button className="primary" disabled={!ready.length} onClick={() => copy(false)}>Copiar linhas</button>
        <button disabled={!ready.length} onClick={() => copy(true)}>Copiar com cabeçalho</button>
        {write && <button disabled={!ready.length} onClick={saveTeam}>Salvar na equipe</button>}
        {write && <label className="check" style={{ display: 'inline-flex', alignItems: 'center', gap: 6, fontSize: 13 }}><input type="checkbox" checked={guardar} onChange={e => setGuardar(e.target.checked)} style={{ width: 18, minHeight: 0 }} /> Guardar o PDF/XML junto</label>}
        <button disabled={!rows.length} onClick={saveDraft}>Salvar rascunho</button>
        <button disabled={!rows.length} onClick={() => { setRows([]); setDraftId(uid()); setDraftName(''); }}>Limpar</button>
      </div>
    </div>
    <div className="tablebox" style={{ maxHeight: '70vh' }}>
      <table className="grid-nf">
        <thead><tr>{COLS.map(c => <th key={c.k} style={{ minWidth: c.w }}>{c.t}</th>)}<th style={{ minWidth: 220 }}>Situação</th><th /></tr></thead>
        <tbody>
          {!rows.length && <tr><td colSpan={COLS.length + 2} className="from" style={{ textAlign: 'center', padding: 30 }}>Nenhuma nota ainda.</td></tr>}
          {rows.map(r => <tr key={r.id}>
            {COLS.map(c => <td key={c.k}><input aria-label={`${c.t} da linha ${r.file}`} className={r.status === 'ok' && REQUIRED.includes(c.k) && !r[c.k] ? 'empty' : ''} style={c.r ? { textAlign: 'right' } : undefined}
              disabled={r.status === 'load'} defaultValue={String(r[c.k] ?? '')} key={String(r[c.k] ?? '') + r.status} onBlur={e => e.target.value !== String(r[c.k] ?? '') && edit(r.id, c.k, e.target.value)} /></td>)}
            <td>{r.status === 'load' ? <span className="pill acc">Lendo…</span> : r.status === 'err' ? <><span className="pill err">Erro</span><div className="from">{r.msg}</div></>
              : missing(r).length ? <><span className="pill warn">Conferir</span><div className="from">Falta: {missing(r).join(', ')}</div></> : r.warn.length ? <><span className="pill warn">Conferir</span><div className="from">{r.warn.join(' ')}</div></> : <span className="pill ok">Pronta</span>}
              <div className="from">{r.file}</div></td>
            <td><button onClick={() => setRows(rs => rs.filter(x => x.id !== r.id))} aria-label={`Remover ${r.file}`}>Remover</button></td>
          </tr>)}
        </tbody>
      </table>
    </div>
    {drafts.length > 0 && <div className="box"><p className="sect">Seus rascunhos (só você vê)</p>
      <div className="list" style={{ marginTop: 10 }}>{drafts.map(d => <div key={d.id} className="bar" style={{ borderTop: '1px solid var(--line)', paddingTop: 8 }}>
        <span><b>{d.nome}</b> <span className="from">· {(d.linhas as any[]).length} linhas · {fmtDT(d.updated_at)}</span></span>
        <span className="row" style={{ marginTop: 0 }}><button onClick={() => openDraft(d)}>Abrir</button><button className="danger" onClick={async () => { await del(`/api/rascunhos/${d.id}`); loadDrafts(); }}>Apagar</button></span></div>)}</div></div>}
  </>;
}
