import { useCallback, useEffect, useRef, useState, type FormEvent } from 'react';
import { useSearchParams } from 'react-router-dom';
import { get, patch, post, del, fmtDate, fmtDT, ApiError } from '../api';
import { useApp, canWrite } from '../ctx';

interface Demanda { id: string; origem: string; subject: string; sender_email: string | null; sender_name: string | null; received_at: string; web_link: string | null;
  categoria: string; tipo: string; resumo: string; acao: string; prazo: string | null; prioridade: string; status: string; obs: string; suspeito: boolean; nova_msg: boolean; decisao_ia: string }
type View = 'validar' | 'abertas' | 'retorno' | 'concluidas' | 'descartadas' | 'todas' | 'atrasadas' | 'fin';
const STATUSES = ['Para validar', 'A fazer', 'Aguardando retorno', 'Concluída', 'Descartada'];
const CAT: Record<string, string> = { 'nota fiscal': 'Nota fiscal', pagamento: 'Pagamento', fornecedor: 'Fornecedor' };
const TABS: [View, string][] = [['validar', 'Para validar'], ['abertas', 'Abertas'], ['retorno', 'Aguardando retorno'], ['atrasadas', 'Atrasadas'], ['concluidas', 'Concluídas'], ['descartadas', 'Descartadas'], ['todas', 'Todas']];
const today = () => new Date().toLocaleDateString('sv-SE');

export default function Fila({ mode }: { mode: 'fila' | 'fin' }) {
  const { team, toast } = useApp();
  const [params, setParams] = useSearchParams();
  const sender = params.get('remetente') ?? '';
  const [view, setView] = useState<View>(mode === 'fin' ? 'fin' : 'validar');
  const [q, setQ] = useState('');
  const [items, setItems] = useState<Demanda[] | null>(null);
  const [painel, setPainel] = useState<any>(null);
  const [status, setStatus] = useState<{ t: string; err?: boolean } | null>(null);
  const [busy, setBusy] = useState(false);
  const dlg = useRef<HTMLDialogElement>(null);
  const write = canWrite(team);
  useEffect(() => { setView(mode === 'fin' ? 'fin' : 'validar'); }, [mode]);

  const load = useCallback(async () => {
    if (!team) return;
    try {
      const qs = new URLSearchParams({ view: sender ? 'todas' : view }); if (q) qs.set('q', q); if (sender) qs.set('sender', sender);
      const [list, p] = await Promise.all([get<Demanda[]>(`/api/teams/${team.id}/demandas?${qs}`), get(`/api/teams/${team.id}/painel`)]);
      setItems(list); setPainel(p);
    } catch (x) { setStatus({ t: (x as ApiError).message, err: true }); }
  }, [team, view, q, sender]);
  useEffect(() => { const t = setTimeout(load, q ? 300 : 0); return () => clearTimeout(t); }, [load, q]);

  if (!team) return <div className="empty">Você ainda não faz parte de nenhuma equipe. Peça a um administrador para incluir você.</div>;

  const change = async (d: Demanda, field: string, value: unknown) => {
    setItems(list => list?.map(x => x.id === d.id ? { ...x, [field]: value } : x) ?? null);
    try { await patch(`/api/teams/${team.id}/demandas/${d.id}`, { [field]: value }); if (field === 'status') load(); }
    catch (x) { toast((x as ApiError).message); load(); }
  };
  const sync = async () => {
    setBusy(true); setStatus({ t: 'Buscando e-mails novos…' });
    try {
      const r = await post(`/api/teams/${team.id}/sync`);
      const s = r.results?.[0];
      setStatus(!s ? { t: 'Nenhuma caixa configurada para esta equipe.' } : s.error ? { t: `Erro ao ler ${s.mailbox}: ${s.error}`, err: true }
        : { t: `Pronto: ${s.recebidos} e-mails novos · ${s.regra} ignorados pelas regras · ${s.info} só informativos · ${s.novas} novas demandas${s.atualizadas ? ` · ${s.atualizadas} conversas atualizadas` : ''}.` });
      load();
    } catch (x) { setStatus({ t: (x as ApiError).message, err: true }); }
    setBusy(false);
  };
  const criar = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    try {
      await post(`/api/teams/${team.id}/demandas`, { subject: f.get('subject'), sender_name: f.get('sender') || undefined, acao: f.get('acao'), prioridade: f.get('prioridade'), prazo: f.get('prazo') || null, categoria: f.get('categoria') });
      dlg.current?.close(); toast('Demanda adicionada'); load();
    } catch (x) { toast((x as ApiError).message); }
  };
  const c = painel?.counts ?? {};
  const kpis: [View | null, string, number, string][] = mode === 'fin' ? [['fin', 'Em aberto', c.fin ?? 0, 'main']] : [
    ['validar', 'Para validar', c.validar ?? 0, 'main'], [null, 'Notas, pagamentos e fornecedores', c.fin ?? 0, ''], [null, 'Alta prioridade', c.alta ?? 0, ''],
    ['atrasadas', 'Atrasadas', c.atrasadas ?? 0, c.atrasadas ? 'bad' : ''], [null, 'Vencem hoje ou amanhã', c.vence ?? 0, ''], ['retorno', 'Aguardando retorno', c.retorno ?? 0, ''], ['concluidas', 'Concluídas em 7 dias', c.concluidas7 ?? 0, '']];
  const box = painel?.mailboxes?.[0];

  return <>
    <div className="bar">
      <div>
        <p className="sect">{mode === 'fin' ? 'Notas, pagamentos e fornecedores' : 'Fila de demandas'}</p>
        <h2 className="ptitle">{sender ? `Demandas de ${sender}` : mode === 'fin' ? 'Notas fiscais, pagamentos e fornecedores' : 'O que precisa de você'}</h2>
        <p className="lead">{box ? `Caixa ${box.address} · última leitura ${box.last_sync_at ? fmtDT(box.last_sync_at) : 'ainda não feita'}${box.last_error ? ' · último erro: ' + box.last_error : ''}` : 'Nenhuma caixa configurada. Um administrador cadastra a caixa em Administração.'}</p>
      </div>
      <div className="row" style={{ marginTop: 0 }}>
        {write && <button className="primary" onClick={sync} disabled={busy}>{busy ? 'Buscando…' : 'Buscar e-mails novos'}</button>}
        {write && <button onClick={() => dlg.current?.showModal()}>+ Nova demanda</button>}
      </div>
    </div>
    {status && <div className={'status' + (status.err ? ' err' : '')} role="status">{status.t}</div>}
    {sender && <div className="status">Filtrando por remetente. <button className="link" onClick={() => setParams({})}>Mostrar todos</button></div>}
    <div className="kpis">{kpis.map(([v, l, n, cls]) => <button key={l} className={`kpi ${cls} ${v && view === v ? 'sel' : ''}`} onClick={() => v && setView(v)} disabled={!v} style={!v ? { opacity: 1, cursor: 'default' } : undefined}><span>{l}</span><b>{n}</b></button>)}</div>
    {mode === 'fila' && !sender && <div className="tabs" role="tablist">{TABS.map(([v, l]) => <button key={v} role="tab" aria-selected={view === v} onClick={() => setView(v)}>{l}</button>)}</div>}
    <div className="bar"><input className="search" type="search" placeholder="Procurar por assunto, remetente, resumo ou observação" value={q} maxLength={100} onChange={e => setQ(e.target.value)} />
      <span className="count">{items ? `${items.length} demanda${items.length === 1 ? '' : 's'}` : 'Carregando…'}</span></div>
    <div className="list">
      {items && !items.length && <div className="empty">Nada por aqui.</div>}
      {items?.map(d => {
        const late = !!d.prazo && d.prazo < today() && ['A fazer', 'Aguardando retorno'].includes(d.status);
        return <article key={d.id} className={`card ${d.prioridade === 'alta' ? 'alta' : d.categoria ? 'fin' : ''} ${late ? 'late' : ''}`}>
          <h3>{d.subject}</h3>
          <div className="from">{d.sender_name || d.sender_email || (d.origem === 'manual' ? 'Cadastrada à mão' : '')}{d.received_at ? ' · ' + fmtDT(d.received_at) : ''}</div>
          {d.resumo && <p>{d.resumo}</p>}
          {d.acao && <p><b>O que fazer:</b> {d.acao}</p>}
          <div className="pills">
            {d.categoria && <span className="pill acc">{CAT[d.categoria]}</span>}
            {d.tipo && <span className="pill">{d.tipo}</span>}
            <span className={`pill ${d.prioridade === 'alta' ? 'err' : ''}`}>Prioridade {d.prioridade === 'media' ? 'média' : d.prioridade}</span>
            {d.prazo && <span className={`pill ${late ? 'err' : 'warn'}`}>{late ? 'Atrasada · ' : ''}Prazo {fmtDate(d.prazo)}</span>}
            {d.nova_msg && <span className="pill acc">Nova mensagem na conversa</span>}
            {d.suspeito && <span className="pill err">Parece suspeito: confira o remetente antes de agir</span>}
            {d.decisao_ia && d.status === 'Para validar' && <span className="pill">Sugestão: {d.decisao_ia}</span>}
          </div>
          <div className="fields">
            <label>Situação<select disabled={!write} value={d.status} onChange={e => change(d, 'status', e.target.value)}>{STATUSES.map(s => <option key={s}>{s}</option>)}</select></label>
            <label>Prioridade<select disabled={!write} value={d.prioridade} onChange={e => change(d, 'prioridade', e.target.value)}><option value="alta">Alta</option><option value="media">Média</option><option value="baixa">Baixa</option></select></label>
            <label>Prazo<input type="date" disabled={!write} value={d.prazo ?? ''} onChange={e => change(d, 'prazo', e.target.value || null)} /></label>
            <label>Assunto<select disabled={!write} value={d.categoria} onChange={e => change(d, 'categoria', e.target.value)}><option value="">Outro</option><option value="nota fiscal">Nota fiscal</option><option value="pagamento">Pagamento</option><option value="fornecedor">Fornecedor</option></select></label>
            <label>Observação<input disabled={!write} maxLength={500} defaultValue={d.obs} placeholder="ex.: encaminhei para…" onBlur={e => e.target.value !== d.obs && change(d, 'obs', e.target.value)} /></label>
          </div>
          <div className="row">
            {write && d.status === 'Para validar' && <><button className="primary" onClick={() => change(d, 'status', 'A fazer')}>Confirmar demanda</button><button onClick={() => change(d, 'status', 'Descartada')}>Descartar</button></>}
            {d.web_link && <a href={d.web_link} target="_blank" rel="noopener noreferrer">Abrir no Outlook</a>}
            {team.role === 'gestor' && <button className="link" style={{ color: 'var(--err)', marginLeft: 'auto' }} onClick={async () => { if (confirmDel(d)) { await del(`/api/teams/${team.id}/demandas/${d.id}`).catch(x => toast(x.message)); load(); } else toast('Clique de novo em Apagar para confirmar.'); }}>Apagar</button>}
          </div>
        </article>;
      })}
    </div>
    <dialog ref={dlg} aria-labelledby="nd-title">
      <h2 className="ptitle" id="nd-title">Nova demanda</h2>
      <form className="form" onSubmit={criar}>
        <label>Assunto<input name="subject" required maxLength={300} /></label>
        <label>Quem pediu<input name="sender" maxLength={200} /></label>
        <label>O que precisa ser feito<textarea name="acao" maxLength={300} /></label>
        <div className="fields">
          <label>Prioridade<select name="prioridade" defaultValue="media"><option value="alta">Alta</option><option value="media">Média</option><option value="baixa">Baixa</option></select></label>
          <label>Prazo<input name="prazo" type="date" /></label>
          <label>Assunto<select name="categoria" defaultValue=""><option value="">Outro</option><option value="nota fiscal">Nota fiscal</option><option value="pagamento">Pagamento</option><option value="fornecedor">Fornecedor</option></select></label>
        </div>
        <div className="row"><button className="primary">Adicionar</button><button type="button" onClick={() => dlg.current?.close()}>Cancelar</button></div>
      </form>
    </dialog>
  </>;
}
// confirmação simples sem alert/confirm do navegador
const pending = new Set<string>();
function confirmDel(d: { id: string }) { if (pending.has(d.id)) { pending.delete(d.id); return true; } pending.add(d.id); setTimeout(() => pending.delete(d.id), 4000); return false; }
