import { useCallback, useEffect, useRef, useState } from 'react';
import { get, patch, del, upload, fmtDate, brl, ApiError } from '../api';
import { useApp, canWrite } from '../ctx';
import Visualizador, { type Arquivo } from '../components/Visualizador';

type Nota = { id: string; numero_nf: string | null; fornecedor: string | null; base: string | null; codigo: string | null; cnpj: string | null; rc: string | null; po: string | null; migo: string | null;
  mes: string | null; qz: string | null; valor: string | null; emissao: string | null; vencimento: string | null; envio_central: string | null; status: 'pendente' | 'lancada';
  origem: 'leitor' | 'email'; avisos: string; conferir: boolean; anexos: Arquivo[] };
type Aba = 'pendente' | 'conferir' | 'lancada' | 'todas';
const ABAS: [Aba, string][] = [['pendente', 'Pendentes'], ['conferir', 'Para conferir'], ['lancada', 'Lançadas'], ['todas', 'Todas']];
const cnpjFmt = (c: string | null) => c && c.length === 14 ? c.replace(/^(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})$/, '$1.$2.$3/$4-$5') : c ?? '';

export default function Notas() {
  const { team, toast } = useApp();
  const [status, setStatus] = useState<Aba>('pendente');
  const [q, setQ] = useState(''); const [rows, setRows] = useState<Nota[] | null>(null); const [sel, setSel] = useState<Set<string>>(new Set());
  const [aberta, setAberta] = useState<string | null>(null);
  const [apagar, setApagar] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null); const alvo = useRef<string>('');
  const load = useCallback(() => { if (team) get<Nota[]>(`/api/teams/${team.id}/notas?status=${status}${q ? '&q=' + encodeURIComponent(q) : ''}`).then(r => { setRows(r); setSel(s => new Set([...s].filter(id => r.some(x => x.id === id)))); }).catch((x: ApiError) => toast(x.message)); }, [team, status, q]);
  useEffect(() => { const t = setTimeout(load, q ? 300 : 0); return () => clearTimeout(t); }, [load, q]);
  if (!team) return <div className="empty">Você ainda não faz parte de nenhuma equipe.</div>;
  const write = canWrite(team);
  const total = (rows ?? []).reduce((s, r) => s + Number(r.valor || 0), 0);
  const nota = rows?.find(r => r.id === aberta) ?? null;
  const marcar = async (st: 'lancada' | 'pendente') => {
    for (const id of sel) await patch(`/api/teams/${team.id}/notas/${id}`, { status: st }).catch((x: ApiError) => toast(x.message));
    toast(`${sel.size} nota${sel.size > 1 ? 's' : ''} marcada${sel.size > 1 ? 's' : ''} como ${st === 'lancada' ? 'lançada' : 'pendente'}`); load();
  };
  const copy = async () => {
    const list = (rows ?? []).filter(r => sel.size ? sel.has(r.id) : true);
    const tsv = list.map(r => [r.mes, r.qz, r.base, r.codigo, r.fornecedor, r.rc, r.po, r.migo, r.numero_nf, r.valor ? Number(r.valor).toLocaleString('pt-BR', { minimumFractionDigits: 2 }) : '', fmtDate(r.emissao), fmtDate(r.vencimento), fmtDate(r.envio_central)].map(v => String(v ?? '').replace(/[\t\n]/g, ' ')).join('\t')).join('\n');
    try { await navigator.clipboard.writeText(tsv); toast(`${list.length} linhas copiadas`); } catch { toast('Não consegui copiar.'); }
  };
  const anexar = (id: string) => { alvo.current = id; fileRef.current?.click(); };
  const enviar = async (f: File) => {
    if (!/\.(pdf|xml)$/i.test(f.name)) { toast('Escolha um arquivo PDF ou XML.'); return; }
    if (f.size > 15 * 1024 * 1024) { toast('Arquivo maior que 15 MB.'); return; }
    try { await upload(`/api/teams/${team.id}/notas/${alvo.current}/anexos`, f, f.name); toast('Arquivo anexado à nota.'); load(); }
    catch (x) { toast((x as ApiError).message); }
  };
  const abrir = (r: Nota) => setAberta(r.id);
  const stop = (e: React.SyntheticEvent) => e.stopPropagation();

  return <>
    <div><p className="sect">Notas salvas</p><h2 className="ptitle">Notas da equipe</h2>
      <p className="lead">Notas salvas pelo Leitor de NF e as que chegaram anexadas na caixa. Clique numa nota para ver o PDF e os dados lado a lado. A mesma nota (fornecedor + número) nunca entra duas vezes.</p></div>
    <div className="kpis">
      <div className="kpi main"><span>Notas na lista</span><b>{rows?.length ?? '…'}</b></div>
      <div className="kpi"><span>Valor somado</span><b>{brl(total)}</b></div>
      <div className={`kpi${rows?.some(r => r.conferir) ? ' bad' : ''}`}><span>Para conferir</span><b>{rows?.filter(r => r.conferir).length ?? '…'}</b></div>
      <div className="kpi"><span>Vindas do e-mail</span><b>{rows?.filter(r => r.origem === 'email').length ?? '…'}</b></div>
    </div>
    <div className="tabs" role="tablist">{ABAS.map(([v, l]) => <button key={v} role="tab" aria-selected={status === v} onClick={() => setStatus(v)}>{l}</button>)}</div>
    <div className="bar"><input className="search" type="search" placeholder="Procurar fornecedor, Nº NF, PO ou código" value={q} maxLength={100} onChange={e => setQ(e.target.value)} />
      <div className="row" style={{ marginTop: 0 }}>
        <button onClick={copy} disabled={!rows?.length}>Copiar {sel.size ? 'selecionadas' : 'todas'} para o Excel</button>
        {write && <button className="primary" disabled={!sel.size} onClick={() => marcar('lancada')}>Marcar como lançadas</button>}
        {write && status !== 'pendente' && <button disabled={!sel.size} onClick={() => marcar('pendente')}>Voltar para pendente</button>}
      </div></div>
    <input ref={fileRef} type="file" hidden accept=".pdf,.xml,application/pdf,text/xml,application/xml" onChange={e => { const f = e.target.files?.[0]; e.target.value = ''; if (f) enviar(f); }} />
    <div className="tablebox"><table style={{ minWidth: 1400 }}>
      <thead><tr><th><input type="checkbox" aria-label="Selecionar todas" checked={!!rows?.length && sel.size === rows.length} onChange={e => setSel(e.target.checked ? new Set(rows!.map(r => r.id)) : new Set())} style={{ minHeight: 0, width: 18 }} /></th>
        <th>Nº NF</th><th style={{ minWidth: 220 }}>Fornecedor</th><th>Base</th><th>Código</th><th>PO</th><th className="n">Valor</th><th>Emissão</th><th>Vencimento</th><th>Envio central</th><th>Documento</th><th>Situação</th><th /></tr></thead>
      <tbody>
        {rows?.map(r => <tr key={r.id} className="clic" onClick={() => abrir(r)} tabIndex={0} onKeyDown={e => { if (e.key === 'Enter' && e.target === e.currentTarget) abrir(r); }} aria-label={`Abrir nota ${r.numero_nf ?? 'sem número'} de ${r.fornecedor ?? 'fornecedor não identificado'}`}>
          <td onClick={stop}><input type="checkbox" aria-label={`Selecionar nota ${r.numero_nf ?? ''}`} checked={sel.has(r.id)} onChange={e => setSel(s => { const n = new Set(s); e.target.checked ? n.add(r.id) : n.delete(r.id); return n; })} style={{ minHeight: 0, width: 18 }} /></td>
          <td><b>{r.numero_nf ?? <span className="from">sem número</span>}</b></td><td>{r.fornecedor}</td><td>{r.base}</td><td>{r.codigo}</td><td>{r.po}</td><td className="n">{brl(r.valor)}</td>
          <td>{fmtDate(r.emissao)}</td><td>{fmtDate(r.vencimento)}</td><td>{fmtDate(r.envio_central)}</td>
          <td onClick={stop}><div className="file-btns">
            {r.anexos.map(a => <button key={a.id} onClick={() => abrir(r)} title={a.nome}>{a.tipo === 'pdf' ? 'Ver PDF' : 'Ver XML'}</button>)}
            {!r.anexos.length && (write ? <button onClick={() => anexar(r.id)}>Anexar</button> : <span className="from">—</span>)}
          </div></td>
          <td><div className="pills" style={{ marginTop: 0, flexWrap: 'nowrap' }}>
            <span className={`pill ${r.status === 'lancada' ? 'ok' : 'warn'}`}>{r.status === 'lancada' ? 'Lançada' : 'Pendente'}</span>
            {r.conferir && <span className="pill err" title={r.avisos}>Conferir</span>}
            {r.origem === 'email' && <span className="pill acc">E-mail</span>}
          </div></td>
          <td onClick={stop}>{team.role === 'gestor' && (apagar === r.id
            ? <button className="link" style={{ color: 'var(--err)' }} onBlur={() => setApagar(null)} autoFocus onClick={async () => { setApagar(null); await del(`/api/teams/${team.id}/notas/${r.id}`).catch((x: ApiError) => toast(x.message)); toast('Nota apagada.'); load(); }}>Confirmar{r.anexos.length ? ' (apaga os arquivos)' : ''}</button>
            : <button className="link" style={{ color: 'var(--err)' }} onClick={() => setApagar(r.id)}>Apagar</button>)}</td>
        </tr>)}
        {rows && !rows.length && <tr><td colSpan={13} className="from" style={{ textAlign: 'center', padding: 24 }}>Nenhuma nota aqui.</td></tr>}
      </tbody></table></div>
    {nota && <Visualizador teamId={team.id} arquivos={nota.anexos} onClose={() => setAberta(null)}
      titulo={`NF ${nota.numero_nf ?? 'sem número'}${nota.fornecedor ? ' · ' + nota.fornecedor : ''}`}
      painel={<Painel key={nota.id} nota={nota} teamId={team.id} write={write} onSaved={load} onAnexar={() => anexar(nota.id)} />} />}
  </>;
}

const CAMPOS: { k: keyof Nota; t: string; tipo?: 'date'; wide?: boolean; max: number }[] = [
  { k: 'numero_nf', t: 'Nº NF', max: 40 }, { k: 'valor', t: 'Valor (R$)', max: 20 }, { k: 'fornecedor', t: 'Fornecedor', wide: true, max: 200 },
  { k: 'codigo', t: 'Código', max: 40 }, { k: 'base', t: 'Base', max: 40 }, { k: 'cnpj', t: 'CNPJ', max: 18 }, { k: 'po', t: 'PO', max: 40 },
  { k: 'rc', t: 'RC', max: 40 }, { k: 'migo', t: 'MIGO', max: 40 },
  { k: 'emissao', t: 'Emissão', tipo: 'date', max: 10 }, { k: 'vencimento', t: 'Vencimento', tipo: 'date', max: 10 }, { k: 'envio_central', t: 'Envio central', tipo: 'date', max: 10 }];
const inicial = (n: Nota) => Object.fromEntries(CAMPOS.map(c => [c.k, c.k === 'valor' ? (n.valor ? Number(n.valor).toLocaleString('pt-BR', { minimumFractionDigits: 2 }) : '') : c.k === 'cnpj' ? cnpjFmt(n.cnpj) : c.tipo ? String(n[c.k] ?? '').slice(0, 10) : String(n[c.k] ?? '')])) as Record<string, string>;

function Painel({ nota, teamId, write, onSaved, onAnexar }: { nota: Nota; teamId: string; write: boolean; onSaved: () => void; onAnexar: () => void }) {
  const { toast } = useApp();
  const [v, setV] = useState(() => inicial(nota));
  const [salvando, setSalvando] = useState(false);
  const orig = inicial(nota);
  const mudou = CAMPOS.filter(c => v[c.k] !== orig[c.k]);
  const salvar = async (extra: Record<string, unknown> = {}) => {
    const body: Record<string, unknown> = { ...extra };
    for (const c of mudou) body[c.k] = v[c.k].trim() === '' ? (c.k === 'numero_nf' ? undefined : null) : v[c.k].trim();
    if (!Object.keys(body).length) return;
    setSalvando(true);
    try { await patch(`/api/teams/${teamId}/notas/${nota.id}`, body); toast(extra.conferir === false ? 'Nota marcada como conferida.' : extra.status ? 'Situação atualizada.' : 'Dados salvos.'); onSaved(); }
    catch (x) { const e = x as ApiError; toast(e.fields?.length ? `Confira o campo ${e.fields[0].path}: ${e.fields[0].message}` : e.message); }
    finally { setSalvando(false); }
  };
  return <form onSubmit={e => { e.preventDefault(); salvar(); }}>
    <h4>Dados da nota</h4>
    <div className="pills" style={{ marginTop: 6 }}>
      <span className={`pill ${nota.status === 'lancada' ? 'ok' : 'warn'}`}>{nota.status === 'lancada' ? 'Lançada' : 'Pendente'}</span>
      <span className="pill acc">{nota.origem === 'email' ? 'Chegou por e-mail' : 'Salva pelo Leitor'}</span>
      {nota.mes && <span className="pill">Mês {nota.mes} · {nota.qz}ª quinzena</span>}
    </div>
    {nota.conferir && <div className="aviso" role="note"><b>Conferir:</b> {nota.avisos || 'confira os dados com o documento.'}</div>}
    {!nota.conferir && nota.avisos && <p className="from" style={{ fontSize: 12.5 }}>{nota.avisos}</p>}
    <fieldset disabled={!write || salvando} style={{ border: 0, padding: 0, margin: 0 }}>
      <div className="fields">{CAMPOS.map(c => <label key={c.k} className={c.wide ? 'wide' : ''}>{c.t}
        <input type={c.tipo ?? 'text'} value={v[c.k]} maxLength={c.max} inputMode={c.k === 'valor' || c.k === 'cnpj' ? 'decimal' : undefined}
          onChange={e => setV(s => ({ ...s, [c.k]: e.target.value }))} /></label>)}</div>
    </fieldset>
    {write && <div className="row" style={{ flexWrap: 'wrap' }}>
      <button type="submit" className="primary" disabled={!mudou.length || salvando}>Salvar dados</button>
      {nota.conferir && <button type="button" disabled={salvando} onClick={() => salvar({ conferir: false })}>Conferida</button>}
      <button type="button" disabled={salvando} onClick={() => salvar({ status: nota.status === 'lancada' ? 'pendente' : 'lancada' })}>{nota.status === 'lancada' ? 'Voltar para pendente' : 'Marcar como lançada'}</button>
      {nota.anexos.length < 5 && <button type="button" onClick={onAnexar}>Anexar outro arquivo</button>}
    </div>}
    {nota.anexos.length > 0 && <p className="from" style={{ fontSize: 12.5, marginTop: 14 }}>Arquivos: {nota.anexos.map(a => a.nome).join(' · ')}</p>}
  </form>;
}
