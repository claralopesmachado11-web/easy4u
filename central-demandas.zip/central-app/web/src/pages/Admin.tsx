import { useCallback, useEffect, useState, type FormEvent } from 'react';
import { get, post, patch, put, del, fmtDT, ApiError } from '../api';
import { useApp } from '../ctx';

export default function Admin() {
  const { user, toast, refresh } = useApp();
  const [users, setUsers] = useState<any[]>([]); const [teams, setTeams] = useState<any[]>([]); const [invites, setInvites] = useState<any[]>([]); const [audit, setAudit] = useState<any[]>([]);
  const [err, setErr] = useState<{ t: string; code?: string } | null>(null); const [link, setLink] = useState<{ link: string; emailed: boolean } | null>(null);
  const load = useCallback(async () => {
    try { const [u, t, i, a] = await Promise.all([get('/api/admin/users'), get('/api/admin/teams'), get('/api/admin/invites'), get('/api/admin/audit')]); setUsers(u); setTeams(t); setInvites(i); setAudit(a); setErr(null); }
    catch (x) { const e = x as ApiError; setErr({ t: e.message, code: e.code }); }
  }, []);
  useEffect(() => { load(); }, [load]);
  if (err?.code === 'mfa_setup_required') return <div className="status err">{err.t} Vá em <a href="/conta">Minha conta</a>.</div>;
  const run = async (p: Promise<unknown>, ok: string) => { try { await p; toast(ok); await load(); await refresh(); } catch (x) { toast((x as ApiError).message); } };
  const convidar = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault(); const f = new FormData(e.currentTarget); const form = e.currentTarget;
    const teamId = String(f.get('teamId') || '');
    try { const r = await post('/api/admin/invites', { email: f.get('email'), globalRole: f.get('globalRole'), ...(teamId ? { teamId, teamRole: f.get('teamRole') } : {}) }); setLink(r); form.reset(); load(); }
    catch (x) { toast((x as ApiError).message); }
  };
  const name = (id: string) => users.find(u => u.id === id)?.name ?? id?.slice(0, 8) ?? '';
  return <>
    {err && <div className="status err">{err.t}</div>}
    <div className="two">
      <form className="box form" onSubmit={convidar} style={{ maxWidth: 'none' }}>
        <p className="sect">Convidar pessoa</p>
        <label>E-mail<input name="email" type="email" required maxLength={254} /></label>
        <div className="fields" style={{ marginTop: 0 }}>
          <label>Tipo de conta<select name="globalRole" defaultValue="user"><option value="user">Usuário</option><option value="admin">Administrador</option></select></label>
          <label>Equipe<select name="teamId" defaultValue=""><option value="">Nenhuma</option>{teams.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}</select></label>
          <label>Nível na equipe<select name="teamRole" defaultValue="operador"><option value="gestor">Gestor</option><option value="operador">Operador</option><option value="leitor">Leitor</option></select></label>
        </div>
        <button className="primary">Gerar convite</button>
        {link && <div className={'status' + (link.emailed ? ' ok' : '')}>{link.emailed ? 'Convite enviado por e-mail. ' : 'Não consegui enviar o e-mail. Mande este link por um canal seguro: '}
          <code style={{ overflowWrap: 'anywhere' }}>{link.link}</code> <small>(vale 3 dias, uso único; não aparece de novo)</small></div>}
      </form>
      <form className="box form" style={{ maxWidth: 'none' }} onSubmit={e => { e.preventDefault(); const f = new FormData(e.currentTarget); const form = e.currentTarget; run(post('/api/admin/teams', { name: f.get('name') }).then(() => form.reset()), 'Equipe criada'); }}>
        <p className="sect">Nova equipe</p>
        <label>Nome<input name="name" required maxLength={80} /></label>
        <button>Criar equipe</button>
      </form>
    </div>

    {teams.map(t => <div key={t.id} className="box" style={{ display: 'grid', gap: 12 }}>
      <div className="bar"><h3 className="ptitle" style={{ fontSize: '1.2rem' }}>{t.name}</h3>
        {t.mailboxes.length > 0 && <button onClick={() => run(post(`/api/admin/teams/${t.id}/sync`), 'Leitura feita')}>Ler a caixa agora</button>}</div>
      <div className="tablebox"><table><thead><tr><th>Pessoa</th><th>Nível</th><th /></tr></thead><tbody>
        {t.members.map((m: any) => <tr key={m.user_id}><td>{m.name}<div className="from">{m.email}</div></td>
          <td><select value={m.role} onChange={e => run(put(`/api/admin/teams/${t.id}/members/${m.user_id}`, { role: e.target.value }), 'Nível alterado')}><option value="gestor">Gestor</option><option value="operador">Operador</option><option value="leitor">Leitor</option></select></td>
          <td><button className="link" style={{ color: 'var(--err)' }} onClick={() => run(del(`/api/admin/teams/${t.id}/members/${m.user_id}`), 'Removido da equipe')}>Remover</button></td></tr>)}
        <tr><td colSpan={3}><form className="row" style={{ marginTop: 0 }} onSubmit={e => { e.preventDefault(); const f = new FormData(e.currentTarget); run(put(`/api/admin/teams/${t.id}/members/${f.get('uid')}`, { role: f.get('role') }), 'Pessoa adicionada'); }}>
          <select name="uid" required style={{ width: 'auto' }}><option value="">Adicionar pessoa…</option>{users.filter(u => !t.members.some((m: any) => m.user_id === u.id)).map(u => <option key={u.id} value={u.id}>{u.name} ({u.email})</option>)}</select>
          <select name="role" defaultValue="operador" style={{ width: 'auto' }}><option value="gestor">Gestor</option><option value="operador">Operador</option><option value="leitor">Leitor</option></select><button>Adicionar</button></form></td></tr>
      </tbody></table></div>
      <div><p className="sect">Caixa compartilhada</p>
        {t.mailboxes.map((b: any) => <p key={b.id} className="lead">{b.address} · última leitura {b.last_sync_at ? fmtDT(b.last_sync_at) : 'nunca'}{b.last_error ? ` · erro: ${b.last_error}` : ''}</p>)}
        {!t.mailboxes.length && <form className="row" onSubmit={e => { e.preventDefault(); const f = new FormData(e.currentTarget); run(post(`/api/admin/teams/${t.id}/mailboxes`, { address: f.get('address') }), 'Caixa cadastrada'); }}>
          <input name="address" type="email" required placeholder="caixa@empresa.com.br" style={{ maxWidth: 320 }} /><button>Cadastrar caixa</button>
          <small className="from">Para cadastrar, você precisa estar na equipe como gestor ou operador.</small></form>}
      </div>
    </div>)}

    <div className="box"><p className="sect">Pessoas</p>
      <div className="tablebox" style={{ marginTop: 10 }}><table style={{ minWidth: 760 }}><thead><tr><th>Nome</th><th>Tipo</th><th>2 etapas</th><th>Situação</th><th /></tr></thead><tbody>
        {users.map(u => <tr key={u.id}><td>{u.name}<div className="from">{u.email}</div></td>
          <td><select disabled={u.id === user.id} value={u.role} onChange={e => run(patch(`/api/admin/users/${u.id}`, { role: e.target.value }), 'Tipo alterado')}><option value="user">Usuário</option><option value="admin">Administrador</option></select></td>
          <td>{u.mfa_enabled ? <span className="pill ok">Ativa</span> : <span className="pill">Não</span>}</td>
          <td>{u.is_active ? (u.locked_until && new Date(u.locked_until) > new Date() ? <span className="pill warn">Bloqueado por tentativas</span> : <span className="pill ok">Ativo</span>) : <span className="pill err">Desativado</span>}</td>
          <td className="row" style={{ marginTop: 0 }}>{u.id !== user.id && <button onClick={() => run(patch(`/api/admin/users/${u.id}`, { is_active: !u.is_active }), u.is_active ? 'Conta desativada' : 'Conta reativada')}>{u.is_active ? 'Desativar' : 'Reativar'}</button>}
            <button onClick={() => run(post(`/api/admin/users/${u.id}/sessions/revoke`), 'Sessões encerradas')}>Encerrar sessões</button></td></tr>)}
      </tbody></table></div></div>

    <div className="box"><p className="sect">Convites</p>
      <div className="tablebox" style={{ marginTop: 10 }}><table><thead><tr><th>E-mail</th><th>Tipo</th><th>Vence</th><th>Situação</th><th /></tr></thead><tbody>
        {invites.map(i => <tr key={i.id}><td>{i.email}</td><td>{i.global_role === 'admin' ? 'Administrador' : 'Usuário'}</td><td>{fmtDT(i.expires_at)}</td>
          <td>{i.used_at ? <span className="pill ok">Usado</span> : new Date(i.expires_at) < new Date() ? <span className="pill">Vencido</span> : <span className="pill warn">Aguardando</span>}</td>
          <td>{!i.used_at && <button className="link" style={{ color: 'var(--err)' }} onClick={() => run(del(`/api/admin/invites/${i.id}`), 'Convite cancelado')}>Cancelar</button>}</td></tr>)}
      </tbody></table></div></div>

    <div className="box"><p className="sect">Registro de auditoria (últimos 100)</p>
      <div className="tablebox" style={{ marginTop: 10, maxHeight: 420 }}><table style={{ minWidth: 700 }}><thead><tr><th>Quando</th><th>Quem</th><th>O quê</th><th>IP</th></tr></thead><tbody>
        {audit.map(a => <tr key={a.id}><td>{fmtDT(a.at)}</td><td>{a.user_id ? name(a.user_id) : 'sistema'}</td><td>{a.action}</td><td>{a.ip}</td></tr>)}
      </tbody></table></div></div>
  </>;
}
