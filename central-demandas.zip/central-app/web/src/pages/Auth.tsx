import { useEffect, useState, type FormEvent, type ReactNode } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { get, post, ApiError } from '../api';

function Frame({ children }: { children: ReactNode }) {
  return <div className="auth">
    <header className="band"><div className="band-in"><div className="brand">
      <div className="mark" aria-hidden="true">CD</div>
      <div><h1>Central de <span>Demandas</span></h1><p className="sub">E-mails da caixa compartilhada e notas fiscais em um só lugar.</p></div>
    </div></div></header>
    <div>{children}</div>
    <footer className="indep">Projeto independente, desenvolvido por fora da empresa. Não é uma ferramenta ou sistema oficial da organização.</footer>
  </div>;
}
// lê o token do endereço (#token) e já apaga da barra: não fica no histórico nem é enviado a outros sites
function useHashToken() {
  const [t] = useState(() => { const v = window.location.hash.slice(1); if (v) history.replaceState(null, '', window.location.pathname); return v; });
  return t;
}
const pwHint = 'Mínimo de 12 caracteres. Uma frase com palavras e números é fácil de lembrar e difícil de adivinhar.';

function PasswordFields({ value, onChange, confirm, onConfirm }: { value: string; onChange: (v: string) => void; confirm: string; onConfirm: (v: string) => void }) {
  return <>
    <label>Nova senha<input type="password" autoComplete="new-password" required minLength={12} maxLength={128} value={value} onChange={e => onChange(e.target.value)} /></label>
    <label>Repita a senha<input type="password" autoComplete="new-password" required value={confirm} onChange={e => onConfirm(e.target.value)} /></label>
    <small className="from">{pwHint}</small>
  </>;
}

export function Login({ onDone, mfa: mfaStart }: { onDone: () => Promise<void>; mfa: boolean }) {
  const [email, setEmail] = useState(''); const [password, setPassword] = useState(''); const [code, setCode] = useState('');
  const [mfa, setMfa] = useState(mfaStart); const [err, setErr] = useState(''); const [busy, setBusy] = useState(false);
  const nav = useNavigate();
  const submit = async (e: FormEvent) => {
    e.preventDefault(); setErr(''); setBusy(true);
    try {
      if (!mfa) { const r = await post('/api/auth/login', { email, password }); setPassword(''); if (r.mfaRequired) { setMfa(true); setBusy(false); return; } }
      else await post('/api/auth/mfa/verify', { code });
      await onDone(); nav('/');
    } catch (x) { setErr((x as ApiError).message); }
    setBusy(false);
  };
  return <Frame><form className="auth-card" onSubmit={submit} noValidate={false}>
    <h2>{mfa ? 'Código de verificação' : 'Entrar'}</h2>
    {err && <div className="status err" role="alert">{err}</div>}
    {!mfa ? <>
      <label>E-mail<input type="email" autoComplete="username" required maxLength={254} value={email} onChange={e => setEmail(e.target.value)} /></label>
      <label>Senha<input type="password" autoComplete="current-password" required maxLength={200} value={password} onChange={e => setPassword(e.target.value)} /></label>
    </> : <label>Código de 6 dígitos do aplicativo autenticador<input inputMode="numeric" autoComplete="one-time-code" pattern="\d{6}" maxLength={6} required value={code} onChange={e => setCode(e.target.value.replace(/\D/g, ''))} autoFocus /></label>}
    <button className="primary" disabled={busy}>{busy ? 'Entrando…' : mfa ? 'Confirmar' : 'Entrar'}</button>
    {!mfa && <Link to="/esqueci-senha">Esqueci minha senha</Link>}
    <small className="from">Não tem conta? O acesso é só por convite de um administrador.</small>
  </form></Frame>;
}

export function Convite({ onDone }: { onDone: () => Promise<void> }) {
  const token = useHashToken();
  const [email, setEmail] = useState<string | null>(null); const [name, setName] = useState('');
  const [pw, setPw] = useState(''); const [pw2, setPw2] = useState(''); const [err, setErr] = useState(''); const [busy, setBusy] = useState(false);
  const nav = useNavigate();
  useEffect(() => { if (!token) { setErr('Link de convite incompleto.'); return; } get(`/api/auth/invite/${encodeURIComponent(token)}`).then(r => setEmail(r.email)).catch(x => setErr(x.message)); }, [token]);
  const submit = async (e: FormEvent) => {
    e.preventDefault(); setErr('');
    if (pw !== pw2) { setErr('As senhas não são iguais.'); return; }
    setBusy(true);
    try { await post('/api/auth/invite/accept', { token, name, password: pw }); await onDone(); nav('/'); }
    catch (x) { setErr((x as ApiError).message); setBusy(false); }
  };
  return <Frame><form className="auth-card" onSubmit={submit}>
    <h2>Criar sua conta</h2>
    {err && <div className="status err" role="alert">{err}</div>}
    {email && <>
      <p className="lead">Convite para <b>{email}</b>.</p>
      <label>Seu nome<input required maxLength={120} autoComplete="name" value={name} onChange={e => setName(e.target.value)} /></label>
      <PasswordFields value={pw} onChange={setPw} confirm={pw2} onConfirm={setPw2} />
      <button className="primary" disabled={busy}>{busy ? 'Criando…' : 'Criar conta'}</button>
    </>}
    <Link to="/entrar">Já tenho conta</Link>
  </form></Frame>;
}

export function Esqueci() {
  const [email, setEmail] = useState(''); const [msg, setMsg] = useState(''); const [err, setErr] = useState(''); const [busy, setBusy] = useState(false);
  const submit = async (e: FormEvent) => {
    e.preventDefault(); setErr(''); setBusy(true);
    try { const r = await post('/api/auth/forgot', { email }); setMsg(r.message); } catch (x) { setErr((x as ApiError).message); }
    setBusy(false);
  };
  return <Frame><form className="auth-card" onSubmit={submit}>
    <h2>Esqueci minha senha</h2>
    {msg ? <div className="status ok" role="status">{msg} O link vale por 1 hora.</div> : <>
      {err && <div className="status err" role="alert">{err}</div>}
      <label>E-mail da sua conta<input type="email" autoComplete="username" required maxLength={254} value={email} onChange={e => setEmail(e.target.value)} /></label>
      <button className="primary" disabled={busy}>Enviar link</button>
    </>}
    <Link to="/entrar">Voltar para o login</Link>
  </form></Frame>;
}

export function Redefinir() {
  const token = useHashToken();
  const [pw, setPw] = useState(''); const [pw2, setPw2] = useState(''); const [err, setErr] = useState(''); const [ok, setOk] = useState(false); const [busy, setBusy] = useState(false);
  const submit = async (e: FormEvent) => {
    e.preventDefault(); setErr('');
    if (pw !== pw2) { setErr('As senhas não são iguais.'); return; }
    setBusy(true);
    try { await post('/api/auth/reset', { token, password: pw }); setOk(true); } catch (x) { setErr((x as ApiError).message); }
    setBusy(false);
  };
  return <Frame><form className="auth-card" onSubmit={submit}>
    <h2>Nova senha</h2>
    {ok ? <div className="status ok">Senha trocada. Por segurança, todas as sessões abertas foram encerradas.</div> : <>
      {!token && <div className="status err">Link incompleto. Peça um novo em "Esqueci minha senha".</div>}
      {err && <div className="status err" role="alert">{err}</div>}
      <PasswordFields value={pw} onChange={setPw} confirm={pw2} onConfirm={setPw2} />
      <button className="primary" disabled={busy || !token}>Salvar nova senha</button>
    </>}
    <Link to="/entrar">Ir para o login</Link>
  </form></Frame>;
}
