import { useState, type FormEvent } from 'react';
import QRCode from 'qrcode';
import { post, ApiError } from '../api';
import { useApp } from '../ctx';

export default function Conta() {
  const { user, refresh, toast } = useApp();
  const [err, setErr] = useState(''); const [mfa, setMfa] = useState<{ secret: string; qr: string } | null>(null); const [code, setCode] = useState('');
  const trocar = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault(); setErr(''); const f = new FormData(e.currentTarget); const form = e.currentTarget;
    if (f.get('password') !== f.get('password2')) { setErr('As senhas novas não são iguais.'); return; }
    try { await post('/api/auth/password', { current: f.get('current'), password: f.get('password') }); form.reset(); toast('Senha trocada. Outras sessões abertas foram encerradas.'); }
    catch (x) { setErr((x as ApiError).message); }
  };
  const iniciar = async () => {
    try { const r = await post('/api/auth/mfa/setup'); setMfa({ secret: r.secret, qr: await QRCode.toDataURL(r.uri, { margin: 1, width: 220 }) }); }
    catch (x) { toast((x as ApiError).message); }
  };
  const ativar = async (e: FormEvent) => {
    e.preventDefault();
    try { await post('/api/auth/mfa/enable', { code }); setMfa(null); toast('Verificação em duas etapas ativada.'); await refresh(); }
    catch (x) { toast((x as ApiError).message); }
  };
  return <>
    <div><p className="sect">Minha conta</p><h2 className="ptitle">{user.name}</h2><p className="lead">{user.email} · {user.role === 'admin' ? 'administrador' : 'usuário'}</p></div>
    <div className="two">
      <form className="box form" onSubmit={trocar} style={{ maxWidth: 'none' }}>
        <p className="sect">Trocar senha</p>
        {err && <div className="status err" role="alert">{err}</div>}
        <label>Senha atual<input name="current" type="password" autoComplete="current-password" required /></label>
        <label>Nova senha<input name="password" type="password" autoComplete="new-password" required minLength={12} maxLength={128} /></label>
        <label>Repita a nova senha<input name="password2" type="password" autoComplete="new-password" required /></label>
        <small className="from">Mínimo de 12 caracteres. Ao trocar, as outras sessões abertas são encerradas.</small>
        <button className="primary">Salvar nova senha</button>
      </form>
      <div className="box form" style={{ maxWidth: 'none' }}>
        <p className="sect">Verificação em duas etapas</p>
        {user.mfaEnabled ? <div className="status ok">Ativa. No login, além da senha, você digita o código do aplicativo autenticador.</div> : <>
          <p className="lead">Além da senha, pede um código de 6 dígitos do celular (Microsoft Authenticator, Google Authenticator ou parecido).{user.role === 'admin' && <b> Obrigatória para usar a Administração.</b>}</p>
          {!mfa ? <button className="primary" onClick={iniciar}>Ativar</button> : <form onSubmit={ativar} className="form">
            <img src={mfa.qr} alt="QR code para o aplicativo autenticador" width={220} height={220} style={{ background: '#fff', borderRadius: 12, padding: 6 }} />
            <small className="from">Não consegue ler o QR? Digite esta chave no aplicativo: <code>{mfa.secret}</code></small>
            <label>Código que aparece no aplicativo<input inputMode="numeric" pattern="\d{6}" maxLength={6} required value={code} onChange={e => setCode(e.target.value.replace(/\D/g, ''))} /></label>
            <button className="primary">Confirmar e ativar</button>
          </form>}
        </>}
      </div>
    </div>
  </>;
}
