import { useEffect, useState } from 'react';
import { get, fmtDate, ApiError } from '../api';
import { useApp } from '../ctx';

export default function Numeros() {
  const { team } = useApp();
  const [rows, setRows] = useState<any[] | null>(null); const [err, setErr] = useState('');
  useEffect(() => { if (team) get(`/api/teams/${team.id}/numeros`).then(setRows).catch((x: ApiError) => setErr(x.message)); }, [team]);
  if (!team) return <div className="empty">Você ainda não faz parte de nenhuma equipe.</div>;
  const max = Math.max(1, ...(rows ?? []).map(r => r.recebidos));
  const tot = (k: string) => (rows ?? []).reduce((s, r) => s + r[k], 0);
  return <>
    <div><p className="sect">Números da caixa</p><h2 className="ptitle">Como a caixa andou nos últimos 14 dias</h2>
      <p className="lead">Quantos e-mails chegaram e para onde foram. Use para mostrar o volume de trabalho e ajustar as regras.</p></div>
    {err && <div className="status err">{err}</div>}
    {rows && rows.length > 0 && <div className="kpis">
      <div className="kpi main"><span>Recebidos</span><b>{tot('recebidos')}</b></div>
      <div className="kpi"><span>Ignorados pelas regras</span><b>{tot('regra')}</b></div>
      <div className="kpi"><span>Só informativos</span><b>{tot('info')}</b></div>
      <div className="kpi"><span>Viraram demanda</span><b>{tot('novas')}</b></div></div>}
    <div className="tablebox"><table>
      <thead><tr><th>Dia</th><th>Recebidos</th><th className="n">Ignorados pelas regras</th><th className="n">Só informativos</th><th className="n">Viraram demanda</th></tr></thead>
      <tbody>
        {rows?.map(r => <tr key={r.dia}><td>{fmtDate(r.dia)}</td><td><div className="hb"><i style={{ width: Math.round(160 * r.recebidos / max) }} />{r.recebidos}</div></td>
          <td className="n">{r.regra}</td><td className="n">{r.info}</td><td className="n">{r.novas}</td></tr>)}
        {rows && !rows.length && <tr><td colSpan={5} className="from">Os números aparecem depois da primeira leitura da caixa.</td></tr>}
      </tbody></table></div>
  </>;
}
