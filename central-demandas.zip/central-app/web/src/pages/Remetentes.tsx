import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { get, fmtDT, ApiError } from '../api';
import { useApp } from '../ctx';

export default function Remetentes() {
  const { team } = useApp();
  const [rows, setRows] = useState<any[] | null>(null); const [err, setErr] = useState('');
  useEffect(() => { if (team) get(`/api/teams/${team.id}/remetentes`).then(setRows).catch((x: ApiError) => setErr(x.message)); }, [team]);
  if (!team) return <div className="empty">Você ainda não faz parte de nenhuma equipe.</div>;
  return <>
    <div><p className="sect">Quem mais pede</p><h2 className="ptitle">Remetentes e fornecedores com demandas</h2>
      <p className="lead">Quem manda mais pedidos e quem tem coisas em aberto ou atrasadas. Clique no nome para ver as demandas dele.</p></div>
    {err && <div className="status err">{err}</div>}
    <div className="tablebox"><table>
      <thead><tr><th>Remetente</th><th className="n">Em aberto</th><th className="n">Atrasadas</th><th className="n">Notas, pagamentos e fornecedores</th><th className="n">Total</th><th>Último pedido</th></tr></thead>
      <tbody>
        {rows?.map(r => <tr key={r.email || r.nome}>
          <td>{r.email ? <Link to={`/?remetente=${encodeURIComponent(r.email)}`}>{r.nome}</Link> : r.nome}<div className="from">{r.email !== r.nome ? r.email : ''}</div></td>
          <td className="n">{r.aberto}</td><td className="n">{r.atrasadas ? <b style={{ color: 'var(--err)' }}>{r.atrasadas}</b> : 0}</td>
          <td className="n">{r.fin}</td><td className="n">{r.total}</td><td>{fmtDT(r.ultimo)}</td></tr>)}
        {rows && !rows.length && <tr><td colSpan={6} className="from">Ainda não há demandas.</td></tr>}
      </tbody></table></div>
  </>;
}
