import { useCallback, useEffect, useState, type FormEvent } from 'react';
import { get, post, patch, del, ApiError } from '../api';
import { useApp, canWrite } from '../ctx';

export default function Fornecedores() {
  const { team, toast } = useApp();
  const [rows, setRows] = useState<any[] | null>(null); const [paste, setPaste] = useState(''); const [q, setQ] = useState('');
  const load = useCallback(() => { if (team) get(`/api/teams/${team.id}/fornecedores`).then(setRows).catch((x: ApiError) => toast(x.message)); }, [team]);
  useEffect(load, [load]);
  if (!team) return <div className="empty">Você ainda não faz parte de nenhuma equipe.</div>;
  const write = canWrite(team);
  const add = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault(); const f = new FormData(e.currentTarget); const form = e.currentTarget;
    try { await post(`/api/teams/${team.id}/fornecedores`, { base: f.get('base'), codigo: f.get('codigo'), nome: f.get('nome'), cnpj: f.get('cnpj') || null }); form.reset(); toast('Fornecedor cadastrado'); load(); }
    catch (x) { toast((x as ApiError).message); }
  };
  // colar do Excel: BASE <tab> CÓDIGO <tab> NOME [<tab> CNPJ]
  const importar = async () => {
    const linhas = paste.split(/\r?\n/).map(l => l.split('\t').map(s => s.trim())).filter(c => c.length >= 3 && c[1] && c[2]);
    let ok = 0, falhas = 0;
    for (const [base, codigo, nome, cnpj] of linhas) {
      try { await post(`/api/teams/${team.id}/fornecedores`, { base, codigo, nome, cnpj: cnpj || null }); ok++; } catch { falhas++; }
    }
    toast(`${ok} importado${ok === 1 ? '' : 's'}${falhas ? ` · ${falhas} não entraram (código repetido ou dado inválido)` : ''}`); setPaste(''); load();
  };
  const save = async (r: any, k: string, v: string) => { if (v === (r[k] ?? '')) return; try { await patch(`/api/teams/${team.id}/fornecedores/${r.id}`, { [k]: v || (k === 'cnpj' ? null : v) }); load(); } catch (x) { toast((x as ApiError).message); load(); } };
  const shown = (rows ?? []).filter(r => !q || `${r.base} ${r.codigo} ${r.nome} ${r.cnpj ?? ''}`.toLowerCase().includes(q.toLowerCase()));
  return <>
    <div><p className="sect">Cadastro de fornecedores</p><h2 className="ptitle">Fornecedores da equipe</h2>
      <p className="lead">O Leitor de NF usa esta lista para preencher fornecedor, código e base. Com o CNPJ cadastrado, a identificação fica certeira.</p></div>
    {write && <div className="two">
      <form className="box form" onSubmit={add} style={{ maxWidth: 'none' }}>
        <p className="sect">Cadastrar um</p>
        <div className="fields" style={{ marginTop: 0 }}>
          <label>Base<input name="base" maxLength={40} placeholder="ex.: GRU" /></label>
          <label>Código<input name="codigo" required maxLength={40} /></label>
          <label>CNPJ<input name="cnpj" maxLength={18} inputMode="numeric" /></label>
        </div>
        <label>Nome<input name="nome" required maxLength={200} /></label>
        <button className="primary">Cadastrar</button>
      </form>
      <div className="box form" style={{ maxWidth: 'none' }}>
        <p className="sect">Colar do Excel</p>
        <label>Uma linha por fornecedor: base, código, nome e (opcional) CNPJ, separados por tabulação<textarea value={paste} onChange={e => setPaste(e.target.value)} style={{ fontFamily: 'var(--mono)', fontSize: 13 }} placeholder={'GRU\t56641PJN\tSERVCATER INTERNACIONAL LTDA'} /></label>
        <button disabled={!paste.trim()} onClick={importar}>Importar</button>
      </div>
    </div>}
    <div className="bar"><input className="search" type="search" placeholder="Procurar" value={q} onChange={e => setQ(e.target.value)} /><span className="count">{shown.length} fornecedores</span></div>
    <div className="tablebox"><table style={{ minWidth: 760 }}>
      <thead><tr><th>Base</th><th>Código</th><th>Nome</th><th>CNPJ</th><th /></tr></thead>
      <tbody>{shown.map(r => <tr key={r.id}>
        {(['base', 'codigo', 'nome', 'cnpj'] as const).map(k => <td key={k}><input aria-label={k} disabled={!write} defaultValue={r[k] ?? ''} key={r[k] ?? ''} onBlur={e => save(r, k, e.target.value.trim())} /></td>)}
        <td>{team.role === 'gestor' && <button className="link" style={{ color: 'var(--err)' }} onClick={async () => { await del(`/api/teams/${team.id}/fornecedores/${r.id}`).catch((x: ApiError) => toast(x.message)); load(); }}>Apagar</button>}</td>
      </tr>)}
        {rows && !shown.length && <tr><td colSpan={5} className="from" style={{ textAlign: 'center', padding: 24 }}>Nenhum fornecedor.</td></tr>}</tbody></table></div>
  </>;
}
