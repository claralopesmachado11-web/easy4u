// PRÉVIA: só entra no build de demonstração (VITE_DEMO=1). Substitui o servidor por respostas gravadas
// do sistema real rodando com dados de exemplo. Nada é salvo; ações que dependem do servidor avisam isso.
import data from './data.json';

const D = data as any;
const T = D.team as string;
const clone = <X>(x: X): X => JSON.parse(JSON.stringify(x));
let notas: any[] = clone(D.get[`/api/teams/${T}/notas?status=todas`]);
let demandas: any[] = clone(D.get[`/api/teams/${T}/demandas?view=todas`]);
const OPEN = ['A fazer', 'Aguardando retorno'];
const today = () => new Date().toLocaleDateString('sv-SE');
const AVISO = 'Prévia: esta ação só funciona no sistema publicado (com servidor).';

const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status, headers: { 'content-type': 'application/json' } });
const like = (v: unknown, q: string) => String(v ?? '').toLowerCase().includes(q.toLowerCase());
const bytes = (b64: string) => Uint8Array.from(atob(b64), c => c.charCodeAt(0));

function viewFilter(v: string, d: any) {
  if (v === 'validar') return d.status === 'Para validar';
  if (v === 'abertas') return d.status === 'A fazer';
  if (v === 'retorno') return d.status === 'Aguardando retorno';
  if (v === 'concluidas') return d.status === 'Concluída';
  if (v === 'descartadas') return d.status === 'Descartada';
  if (v === 'atrasadas') return OPEN.includes(d.status) && d.prazo && d.prazo < today();
  if (v === 'fin') return d.categoria !== '' && ['Para validar', ...OPEN].includes(d.status);
  return true;
}
function painel() {
  const p = clone(D.get[`/api/teams/${T}/painel`]);
  const c = p.counts;
  c.validar = demandas.filter(d => d.status === 'Para validar').length;
  c.fin = demandas.filter(d => viewFilter('fin', d)).length;
  c.atrasadas = demandas.filter(d => viewFilter('atrasadas', d)).length;
  c.retorno = demandas.filter(d => d.status === 'Aguardando retorno').length;
  c.alta = demandas.filter(d => d.prioridade === 'alta' && ['Para validar', ...OPEN].includes(d.status)).length;
  return p;
}
const brNum = (v: unknown) => { const t = String(v).replace(/[R$\s]/g, ''); const n = Number(/,\d{1,2}$/.test(t) ? t.replace(/\./g, '').replace(',', '.') : t.replace(/,/g, '')); return Number.isFinite(n) ? n.toFixed(2) : null; };

async function handle(method: string, url: URL, body: any): Promise<Response> {
  const p = url.pathname, q = url.searchParams;
  if (method === 'GET') {
    if (p === '/api/auth/me') return json(D.me);
    if (p === `/api/teams/${T}/painel`) return json(painel());
    if (p === `/api/teams/${T}/demandas`) {
      const s = q.get('sender'), t = q.get('q');
      return json(demandas.filter(d => viewFilter(s ? 'todas' : q.get('view') ?? 'validar', d)).filter(d => !s || d.sender_email === s).filter(d => !t || like(d.subject, t) || like(d.sender_name, t)));
    }
    if (p === `/api/teams/${T}/notas`) {
      const st = q.get('status') ?? 'todas', t = q.get('q');
      return json(notas.filter(n => st === 'todas' || (st === 'conferir' ? n.conferir : n.status === st))
        .filter(n => !t || [n.fornecedor, n.numero_nf, n.po, n.codigo].some(v => like(v, t))));
    }
    const m = p.match(/^\/api\/teams\/[^/]+\/anexos\/([^/]+)$/);
    if (m) { const f = D.files[m[1]]; if (!f) return json({ error: 'Arquivo não encontrado.' }, 404); return new Response(bytes(f), { status: 200 }); }
    if (p.match(/\/demandas\/[^/]+\/historico$/)) return json([]);
    const rec = D.get[p];
    if (rec !== undefined) return json(clone(rec));
    return json([]);
  }
  if (method === 'PATCH') {
    let m = p.match(/^\/api\/teams\/[^/]+\/notas\/([^/]+)$/);
    if (m) {
      const n = notas.find(x => x.id === m![1]); if (!n) return json({ error: 'Nota não encontrada.' }, 404);
      for (const [k, v] of Object.entries(body ?? {})) n[k] = k === 'valor' && v != null ? brNum(v) : k === 'cnpj' && v ? String(v).replace(/\D/g, '') : v;
      return json({ ok: true });
    }
    m = p.match(/^\/api\/teams\/[^/]+\/demandas\/([^/]+)$/);
    if (m) { const d = demandas.find(x => x.id === m![1]); if (d) Object.assign(d, body, { nova_msg: false }); return json({ ok: true }); }
  }
  if (p === `/api/teams/${T}/sync`) return json({ error: 'Prévia: a leitura da caixa só funciona no sistema publicado. Os e-mails desta prévia já foram lidos pelo sistema real com dados de exemplo.' }, 503);
  if (p === '/api/auth/logout') return json({ ok: true });
  return json({ error: AVISO }, 403);
}

const real = window.fetch.bind(window);
window.fetch = async (input: RequestInfo | URL, init?: RequestInit) => {
  const url = new URL(typeof input === 'string' ? input : input instanceof URL ? input.href : input.url, location.href);
  if (!url.pathname.startsWith('/api/')) return real(input, init);
  let body: any = null;
  if (typeof init?.body === 'string') { try { body = JSON.parse(init.body); } catch { /* sem corpo */ } }
  await new Promise(r => setTimeout(r, 120));
  return handle((init?.method ?? 'GET').toUpperCase(), url, body);
};

// faixa fixa avisando que é prévia
const bar = document.createElement('div');
bar.className = 'demo-bar';
bar.textContent = 'Prévia com dados de exemplo (notas fictícias, sem valor fiscal). Nada é salvo; a leitura da caixa e o envio de arquivos só funcionam no sistema publicado.';
document.body.prepend(bar);
