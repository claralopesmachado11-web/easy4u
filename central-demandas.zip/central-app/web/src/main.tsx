import React from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter, HashRouter } from 'react-router-dom';
import App from './App';
import '@fontsource/ibm-plex-sans/latin-400.css';
import '@fontsource/ibm-plex-sans/latin-500.css';
import '@fontsource/ibm-plex-sans/latin-600.css';
import '@fontsource/ibm-plex-mono/latin-400.css';
import '@fontsource/sora/latin-600.css';
import '@fontsource/sora/latin-700.css';
import './styles.css';
// Prévia (VITE_DEMO=1): servidor simulado com dados de exemplo; no build normal este trecho é removido.
const DEMO = import.meta.env.VITE_DEMO === '1';
const Router = DEMO ? HashRouter : BrowserRouter;
(DEMO ? import('./demo/mock') : Promise.resolve()).then(() =>
  createRoot(document.getElementById('root')!).render(<React.StrictMode><Router><App /></Router></React.StrictMode>));
