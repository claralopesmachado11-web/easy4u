// Comunicação com o servidor: cookie de sessão (HttpOnly, invisível ao JavaScript) + token CSRF no cabeçalho.
let csrf = '';
export const setCsrf = (t?: string) => { if (t) csrf = t; };

export class ApiError extends Error { constructor(public status: number, message: string, public code?: string, public fields?: { path: string; message: string }[]) { super(message); } }

export async function api<T = any>(method: string, url: string, body?: unknown): Promise<T> {
  const headers: Record<string, string> = {};
  if (body !== undefined) headers['content-type'] = 'application/json';
  if (method !== 'GET' && csrf) headers['x-csrf-token'] = csrf;
  let res: Response;
  try { res = await fetch(url, { method, headers, body: body === undefined ? undefined : JSON.stringify(body), credentials: 'same-origin' }); }
  catch { throw new ApiError(0, 'Sem conexão com o servidor. Confira a internet e tente de novo.'); }
  const data = await res.json().catch(() => ({}));
  if (data && typeof data.csrf === 'string') setCsrf(data.csrf);
  if (res.status === 401 && data?.code !== 'mfa_required' && !url.startsWith('/api/auth/')) window.dispatchEvent(new Event('session-expired'));
  if (!res.ok) throw new ApiError(res.status, data?.error || 'Algo deu errado.', data?.code, data?.fields);
  return data as T;
}
// Envia um arquivo (PDF/XML) cru, com o mesmo cookie e token CSRF.
export async function upload<T = any>(url: string, file: Blob, name: string): Promise<T> {
  const type = file.type === 'application/pdf' || /\.pdf$/i.test(name) ? 'application/pdf' : 'application/xml';
  let res: Response;
  try { res = await fetch(url, { method: 'POST', headers: { 'content-type': type, 'x-file-name': encodeURIComponent(name), 'x-csrf-token': csrf }, body: file, credentials: 'same-origin' }); }
  catch { throw new ApiError(0, 'Sem conexão com o servidor.'); }
  const data = await res.json().catch(() => ({}));
  if (res.status === 401) window.dispatchEvent(new Event('session-expired'));
  if (!res.ok) throw new ApiError(res.status, data?.error || 'Não consegui enviar o arquivo.');
  return data as T;
}
// Baixa um arquivo para mostrar dentro do site (não abre download).
export async function getBytes(url: string): Promise<ArrayBuffer> {
  let res: Response;
  try { res = await fetch(url, { credentials: 'same-origin' }); } catch { throw new ApiError(0, 'Sem conexão com o servidor.'); }
  if (res.status === 401) window.dispatchEvent(new Event('session-expired'));
  if (!res.ok) { const d = await res.json().catch(() => ({})); throw new ApiError(res.status, d?.error || 'Não consegui abrir o arquivo.'); }
  return res.arrayBuffer();
}
export const get = <T = any>(u: string) => api<T>('GET', u);
export const post = <T = any>(u: string, b: unknown = {}) => api<T>('POST', u, b);
export const patch = <T = any>(u: string, b: unknown) => api<T>('PATCH', u, b);
export const put = <T = any>(u: string, b: unknown) => api<T>('PUT', u, b);
export const del = <T = any>(u: string) => api<T>('DELETE', u);

export const pad = (n: number) => String(n).padStart(2, '0');
export const fmtDate = (s?: string | null) => { if (!s) return ''; const [y, m, d] = s.slice(0, 10).split('-'); return `${d}/${m}/${y}`; };
export const fmtDT = (s?: string | null) => { if (!s) return ''; const d = new Date(s); return `${pad(d.getDate())}/${pad(d.getMonth() + 1)} ${pad(d.getHours())}:${pad(d.getMinutes())}`; };
export const brl = (v?: string | number | null) => v == null || v === '' ? '' : Number(v).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
