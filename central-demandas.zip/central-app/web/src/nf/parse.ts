// A mesma lógica de leitura é usada no navegador (Leitor de NF) e no servidor (anexos de e-mail).
export * from '../../../server/src/nf/parse';
