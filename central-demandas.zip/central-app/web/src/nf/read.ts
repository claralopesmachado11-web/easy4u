import { parseText, parseXML, pdfText, type Extracted } from './parse';

// Leitura acontece no navegador: o arquivo da nota nunca é enviado ao servidor.
let pdfLib: typeof import('pdfjs-dist') | null = null;
export async function pdfjs() {
  if (!pdfLib) {
    pdfLib = await import('pdfjs-dist');
    const worker = (await import('pdfjs-dist/build/pdf.worker.min.mjs?url')).default;
    pdfLib.GlobalWorkerOptions.workerSrc = worker;
  }
  return pdfLib;
}
let ocrWorker: Promise<any> | null = null;
function getOCR() {
  if (!ocrWorker) ocrWorker = import('tesseract.js').then(t => t.createWorker('por', 1, {
    workerPath: '/ocr/worker.min.js', corePath: '/ocr/', langPath: '/ocr', gzip: true, workerBlobURL: false, cacheMethod: 'none',
  })).catch(e => { ocrWorker = null; throw new Error('Não consegui iniciar o leitor de imagem. ' + (e?.message ?? '')); });
  return ocrWorker;
}
async function ocr(img: HTMLCanvasElement | File) { const w = await getOCR(); const r = await w.recognize(img); return (r.data.text as string) || ''; }

async function fromPDF(file: File): Promise<Extracted> {
  const lib = await pdfjs();
  const pdf = await lib.getDocument({ data: new Uint8Array(await file.arrayBuffer()), isEvalSupported: false }).promise;
  const text = await pdfText(pdf);
  if (text.replace(/\s/g, '').length < 80) { // escaneado: OCR das primeiras páginas
    let ocrText = '';
    for (let p = 1; p <= Math.min(pdf.numPages, 2); p++) {
      const page = await pdf.getPage(p); const vp = page.getViewport({ scale: 2.5 });
      const cv = document.createElement('canvas'); cv.width = vp.width; cv.height = vp.height;
      const ctx = cv.getContext('2d')!; ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, cv.width, cv.height);
      await page.render({ canvasContext: ctx, viewport: vp }).promise;
      ocrText += (await ocr(cv)) + '\n';
    }
    const o = parseText(text + '\n' + ocrText); o.ocr = true; if (ocrText.replace(/\s/g, '').length < 40) o.scanned = true; return o;
  }
  const out = parseText(text);
  try { const md = await pdf.getMetadata(); out.title = (md?.info as any)?.Title || ''; } catch { /* sem metadados */ }
  return out;
}

export async function readFile(file: File): Promise<Extracted> {
  if (file.size > 15 * 1024 * 1024) throw new Error('Arquivo maior que 15 MB.');
  const name = file.name.toLowerCase();
  if (name.endsWith('.xml') || file.type.includes('xml')) return parseXML(await file.text());
  if (name.endsWith('.pdf') || file.type === 'application/pdf') {
    try { return await fromPDF(file); }
    catch (e: any) { throw new Error(e?.name === 'PasswordException' ? 'PDF protegido por senha. Salve sem senha e envie de novo.' : e?.message || 'Não consegui ler o PDF.'); }
  }
  if (file.type.startsWith('image/') || /\.(jpe?g|png|webp|bmp|tiff?)$/.test(name)) {
    const t = await ocr(file);
    if (t.replace(/\s/g, '').length < 40) throw new Error('Não consegui ler texto nessa imagem. Tente uma foto mais nítida e reta.');
    const o = parseText(t); o.ocr = true; return o;
  }
  throw new Error('Tipo de arquivo não suportado. Use PDF, XML ou imagem.');
}
