import { useCallback, useEffect, useState } from 'react';
import { Navigate, Route, Routes, useLocation, useNavigate } from 'react-router-dom';
import { get, post } from './api';
import { AppCtx, type Team, type User, useToast } from './ctx';
import Shell from './Shell';
import { Login, Convite, Esqueci, Redefinir } from './pages/Auth';
import Fila from './pages/Fila';
import Remetentes from './pages/Remetentes';
import Numeros from './pages/Numeros';
import Leitor from './pages/Leitor';
import Notas from './pages/Notas';
import Fornecedores from './pages/Fornecedores';
import Conta from './pages/Conta';
import Admin from './pages/Admin';

export default function App() {
  const [state, setState] = useState<{ loading: boolean; user: User | null; teams: Team[]; mfa: boolean }>({ loading: true, user: null, teams: [], mfa: false });
  const [teamId, setTeamIdState] = useState<string>(() => { try { return localStorage.getItem('teamId') || ''; } catch { return ''; } });
  const { msg, toast } = useToast();
  const nav = useNavigate();
  const loc = useLocation();

  const refresh = useCallback(async () => {
    try {
      const me = await get('/api/auth/me');
      setState({ loading: false, user: me.user, teams: me.teams ?? [], mfa: !!me.mfaRequired });
    } catch { setState({ loading: false, user: null, teams: [], mfa: false }); }
  }, []);
  useEffect(() => { refresh(); }, [refresh]);
  useEffect(() => {
    const h = () => { setState(s => ({ ...s, user: null })); toast('Sua sessão terminou. Entre de novo.'); };
    window.addEventListener('session-expired', h);
    return () => window.removeEventListener('session-expired', h);
  }, []);

  const setTeamId = (id: string) => { setTeamIdState(id); try { localStorage.setItem('teamId', id); } catch { /* sem armazenamento */ } };
  const logout = async () => { try { await post('/api/auth/logout'); } catch { /* já saiu */ } setState({ loading: false, user: null, teams: [], mfa: false }); nav('/entrar'); };

  if (state.loading) return <div className="auth"><div /><p style={{ textAlign: 'center' }}>Carregando…</p></div>;
  const publicPaths = ['/entrar', '/convite', '/esqueci-senha', '/redefinir-senha'];
  if (!state.user) {
    return <>
      <Routes>
        <Route path="/entrar" element={<Login onDone={refresh} mfa={state.mfa} />} />
        <Route path="/convite" element={<Convite onDone={refresh} />} />
        <Route path="/esqueci-senha" element={<Esqueci />} />
        <Route path="/redefinir-senha" element={<Redefinir />} />
        <Route path="*" element={<Navigate to="/entrar" replace state={{ from: publicPaths.includes(loc.pathname) ? '/' : loc.pathname }} />} />
      </Routes>
      {msg && <div className="toast" role="status">{msg}</div>}
    </>;
  }
  const team = state.teams.find(t => t.id === teamId) ?? state.teams[0] ?? null;
  return (
    <AppCtx.Provider value={{ user: state.user, teams: state.teams, team, setTeamId, refresh, toast, logout }}>
      <Shell>
        <Routes>
          <Route path="/" element={<Fila mode="fila" />} />
          <Route path="/financeiro" element={<Fila mode="fin" />} />
          <Route path="/remetentes" element={<Remetentes />} />
          <Route path="/numeros" element={<Numeros />} />
          <Route path="/leitor" element={<Leitor />} />
          <Route path="/notas" element={<Notas />} />
          <Route path="/fornecedores" element={<Fornecedores />} />
          <Route path="/conta" element={<Conta />} />
          <Route path="/admin" element={state.user.role === 'admin' ? <Admin /> : <Navigate to="/" />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </Shell>
      {msg && <div className="toast" role="status">{msg}</div>}
    </AppCtx.Provider>
  );
}
