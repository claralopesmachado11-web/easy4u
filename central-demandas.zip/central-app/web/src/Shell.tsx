import { useEffect, useRef, useState, type ReactNode } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import { useApp } from './ctx';

const TITLES: Record<string, [string, string]> = {
  '/': ['Central de ', 'Demandas'], '/financeiro': ['Notas, pagamentos e ', 'fornecedores'], '/remetentes': ['Quem mais ', 'pede'],
  '/numeros': ['Números da ', 'caixa'], '/leitor': ['Leitor de ', 'NF'], '/notas': ['Notas ', 'salvas'], '/fornecedores': ['Cadastro de ', 'fornecedores'],
  '/conta': ['Minha ', 'conta'], '/admin': ['Adminis', 'tração'],
};

export default function Shell({ children }: { children: ReactNode }) {
  const { user, teams, team, setTeamId, logout } = useApp();
  const [open, setOpen] = useState(false);
  const loc = useLocation();
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => { setOpen(false); }, [loc.pathname]);
  useEffect(() => {
    const h = (e: MouseEvent) => { if (open && ref.current && !ref.current.contains(e.target as Node)) setOpen(false); };
    const k = (e: KeyboardEvent) => { if (e.key === 'Escape') setOpen(false); };
    document.addEventListener('click', h); document.addEventListener('keydown', k);
    return () => { document.removeEventListener('click', h); document.removeEventListener('keydown', k); };
  }, [open]);
  const [a, b] = TITLES[loc.pathname] ?? TITLES['/'];
  const h = new Date().getHours();
  const item = (to: string, icon: string, label: string) => <NavLink to={to} end className={({ isActive }) => isActive ? 'active' : ''}><span className="mi">{icon}</span>{label}</NavLink>;

  return <>
    <header className="band">
      <div className="band-in">
        <div className="brand">
          <div className="menuwrap" ref={ref}>
            <button className="mark" aria-haspopup="true" aria-expanded={open} aria-label="Abrir menu" onClick={() => setOpen(o => !o)}>CD
              <span className="badge"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M21 15.5v-2l-8-5V3.5a1.5 1.5 0 0 0-3 0V8.5l-8 5v2l8-2.5V18l-2 1.5V21l3.5-1 3.5 1v-1.5L13 18v-5z" /></svg></span>
            </button>
            {open && <nav className="menu" aria-label="Menu principal">
              <p className="menu-hi">{h < 12 ? 'Bom dia' : h < 18 ? 'Boa tarde' : 'Boa noite'}, {user.name.split(' ')[0]}!</p>
              {item('/', '✉', 'Fila de demandas')}
              {item('/financeiro', '$', 'Notas, pagamentos e fornecedores')}
              {item('/remetentes', '≡', 'Quem mais pede')}
              {item('/numeros', '▤', 'Números da caixa')}
              <div className="menu-sep" />
              {item('/leitor', '↧', 'Leitor de NF')}
              {item('/notas', '✓', 'Notas salvas')}
              {item('/fornecedores', '⌂', 'Cadastro de fornecedores')}
              <div className="menu-sep" />
              {item('/conta', '☺', 'Minha conta')}
              {user.role === 'admin' && item('/admin', '⚙', 'Administração')}
              <a href="#sair" onClick={e => { e.preventDefault(); logout(); }}><span className="mi">⏻</span>Sair</a>
            </nav>}
          </div>
          <div>
            <h1>{a}<span>{b}</span></h1>
            <p className="sub">{team ? `Equipe ${team.name} · seu nível: ${team.role}` : 'Você ainda não faz parte de nenhuma equipe. Peça acesso a um administrador.'}</p>
          </div>
        </div>
        {teams.length > 1 && <div className="actions">
          <label style={{ color: '#b9b9b9' }}>Equipe
            <select value={team?.id ?? ''} onChange={e => setTeamId(e.target.value)}>{teams.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}</select>
          </label>
        </div>}
      </div>
    </header>
    <main className="wrap">{children}</main>
    <footer className="indep">Projeto independente, desenvolvido por fora da empresa. Não é uma ferramenta ou sistema oficial da organização.</footer>
  </>;
}
