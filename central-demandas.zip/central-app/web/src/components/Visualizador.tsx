import { useCallback, useEffect, useLayoutEffect, useRef, useState, type ReactNode } from 'react';
import { getBytes, ApiError } from '../api';
import { pdfjs } from '../nf/read';

// Visualizador de notas dentro do site: PDF desenhado página a página pelo pdf.js (sem plugin, funciona no celular)
// e XML mostrado como texto. Nada do arquivo é executado: só a imagem das páginas é desenhada.

export interface Arquivo { id: string; nome: string; tipo: 'pdf' | 'xml'; tamanho: number }
interface Props { teamId: string; arquivos: Arquivo[]; titulo: string; onClose: () => void; painel?: ReactNode }

const ZOOMS = [0.5, 0.75, 1, 1.25, 1.5, 2, 3];
const kb = (n: number) => n > 1048576 ? `${(n / 1048576).toFixed(1).replace('.', ',')} MB` : `${Math.max(1, Math.round(n / 1024))} KB`;

export default function Visualizador({ teamId, arquivos, titulo, onClose, painel }: Props) {
  const dlg = useRef<HTMLDialogElement>(null);
  const [atual, setAtual] = useState<Arquivo | null>(arquivos.find(a => a.tipo === 'pdf') ?? arquivos[0] ?? null);
  const [bytes, setBytes] = useState<ArrayBuffer | null>(null);
  const [erro, setErro] = useState('');
  const [verPainel, setVerPainel] = useState(true);

  useEffect(() => { const d = dlg.current!; d.showModal(); return () => d.close(); }, []);
  useEffect(() => {
    if (!atual) return;
    let vivo = true; setBytes(null); setErro('');
    getBytes(`/api/teams/${teamId}/anexos/${atual.id}`).then(b => vivo && setBytes(b)).catch((e: ApiError) => vivo && setErro(e.message));
    return () => { vivo = false; };
  }, [teamId, atual]);

  const baixar = () => {
    if (!bytes || !atual) return;
    const url = URL.createObjectURL(new Blob([bytes], { type: atual.tipo === 'pdf' ? 'application/pdf' : 'application/xml' }));
    const a = document.createElement('a'); a.href = url; a.download = atual.nome; a.click(); setTimeout(() => URL.revokeObjectURL(url), 1000);
  };

  return <dialog ref={dlg} className="viewer" aria-labelledby="vw-title" onCancel={e => { e.preventDefault(); onClose(); }}>
    <header className="vw-top">
      <div className="vw-name"><p className="sect" style={{ margin: 0 }}>Nota fiscal</p><h3 id="vw-title">{titulo}</h3></div>
      {arquivos.length > 1 && <div className="tabs vw-files" role="tablist" aria-label="Arquivos da nota">
        {arquivos.map(a => <button key={a.id} role="tab" aria-selected={atual?.id === a.id} onClick={() => setAtual(a)}>{a.tipo.toUpperCase()}</button>)}</div>}
      <div className="vw-actions">
        {painel && <button onClick={() => setVerPainel(v => !v)} aria-pressed={verPainel}>{verPainel ? 'Esconder dados' : 'Mostrar dados'}</button>}
        <button onClick={baixar} disabled={!bytes} title={atual ? `${atual.nome} · ${kb(atual.tamanho)}` : ''}>Baixar</button>
        <button className="primary" onClick={onClose} autoFocus aria-label="Fechar visualizador">Fechar</button>
      </div>
    </header>
    <div className={`vw-body${painel && verPainel ? ' com-painel' : ''}`}>
      <section className="vw-doc" aria-label={atual ? `Documento ${atual.nome}` : 'Documento'}>
        {!atual && <div className="empty">Esta nota não tem arquivo.</div>}
        {erro && <div className="empty" role="alert">{erro}</div>}
        {atual && !erro && !bytes && <div className="empty" aria-live="polite">Abrindo {atual.nome}…</div>}
        {atual?.tipo === 'pdf' && bytes && <PDF key={atual.id} data={bytes} />}
        {atual?.tipo === 'xml' && bytes && <XML data={bytes} />}
      </section>
      {painel && verPainel && <aside className="vw-side">{painel}</aside>}
    </div>
  </dialog>;
}

// ---------- PDF ----------
function PDF({ data }: { data: ArrayBuffer }) {
  const box = useRef<HTMLDivElement>(null);
  const [doc, setDoc] = useState<any>(null);
  const [sizes, setSizes] = useState<{ w: number; h: number }[]>([]);
  const [erro, setErro] = useState('');
  const [zoom, setZoom] = useState<number | 'largura'>('largura');
  const [largura, setLargura] = useState(800);
  const [pagina, setPagina] = useState(1);
  const [ir, setIr] = useState('');

  useEffect(() => {
    let vivo = true, d: any = null;
    (async () => {
      try {
        const lib = await pdfjs();
        d = await lib.getDocument({ data: new Uint8Array(data.slice(0)), isEvalSupported: false, enableXfa: false }).promise;
        const s: { w: number; h: number }[] = [];
        for (let i = 1; i <= d.numPages; i++) { const v = (await d.getPage(i)).getViewport({ scale: 1 }); s.push({ w: v.width, h: v.height }); }
        if (vivo) { setDoc(d); setSizes(s); }
      } catch (e: any) { if (vivo) setErro(e?.name === 'PasswordException' ? 'Este PDF está protegido por senha. Use o botão Baixar para abrir no computador.' : 'Não consegui abrir este PDF.'); }
    })();
    return () => { vivo = false; d?.destroy?.(); };
  }, [data]);

  useLayoutEffect(() => {
    const el = box.current; if (!el) return;
    const ro = new ResizeObserver(() => setLargura(el.clientWidth)); ro.observe(el); setLargura(el.clientWidth);
    return () => ro.disconnect();
  }, [doc]);

  const maxW = sizes.reduce((m, s) => Math.max(m, s.w), 1);
  const escala = zoom === 'largura' ? Math.max(0.3, Math.min(3, (largura - 32) / maxW)) : zoom;

  // página atual = a que ocupa o meio da área visível
  const onScroll = useCallback(() => {
    const el = box.current; if (!el) return;
    const meio = el.scrollTop + el.clientHeight / 3;
    const pags = el.querySelectorAll<HTMLElement>('.vw-page');
    let p = 1; pags.forEach((n, i) => { if (n.offsetTop <= meio) p = i + 1; });
    setPagina(p);
  }, []);
  const irPara = (n: number) => {
    const total = sizes.length; if (!total) return;
    const alvo = Math.min(total, Math.max(1, n));
    box.current?.querySelectorAll<HTMLElement>('.vw-page')[alvo - 1]?.scrollIntoView({ block: 'start' });
    setPagina(alvo);
  };
  const zoomPasso = (dir: 1 | -1) => {
    const atual = escala;
    const prox = dir > 0 ? ZOOMS.find(z => z > atual + 0.01) : [...ZOOMS].reverse().find(z => z < atual - 0.01);
    if (prox) setZoom(prox);
  };
  const onKey = (e: React.KeyboardEvent) => {
    if ((e.target as HTMLElement).tagName === 'INPUT') return;
    if (e.key === 'PageDown' || e.key === 'ArrowRight') { e.preventDefault(); irPara(pagina + 1); }
    else if (e.key === 'PageUp' || e.key === 'ArrowLeft') { e.preventDefault(); irPara(pagina - 1); }
    else if (e.key === '+' || e.key === '=') zoomPasso(1);
    else if (e.key === '-') zoomPasso(-1);
  };

  if (erro) return <div className="empty" role="alert">{erro}</div>;
  if (!doc) return <div className="empty" aria-live="polite">Preparando as páginas…</div>;
  return <div className="vw-pdf" onKeyDown={onKey}>
    <div className="vw-bar" role="toolbar" aria-label="Navegação do PDF">
      <button onClick={() => irPara(pagina - 1)} disabled={pagina <= 1} aria-label="Página anterior">‹</button>
      <form onSubmit={e => { e.preventDefault(); irPara(Number(ir)); setIr(''); }} className="vw-goto">
        <label><span className="sr">Ir para a página</span>
          <input inputMode="numeric" value={ir} placeholder={String(pagina)} onChange={e => setIr(e.target.value.replace(/\D/g, ''))} aria-label="Ir para a página" /></label>
        <span aria-live="polite">de {sizes.length}</span>
      </form>
      <button onClick={() => irPara(pagina + 1)} disabled={pagina >= sizes.length} aria-label="Próxima página">›</button>
      <span className="vw-sep" />
      <button onClick={() => zoomPasso(-1)} disabled={escala <= ZOOMS[0]} aria-label="Diminuir zoom">−</button>
      <span className="vw-zoom" aria-live="polite">{Math.round(escala * 100)}%</span>
      <button onClick={() => zoomPasso(1)} disabled={escala >= ZOOMS[ZOOMS.length - 1]} aria-label="Aumentar zoom">+</button>
      <button onClick={() => setZoom('largura')} aria-pressed={zoom === 'largura'}>Ajustar à largura</button>
    </div>
    <div className="vw-pages" ref={box} onScroll={onScroll} tabIndex={0} aria-label={`PDF com ${sizes.length} página${sizes.length > 1 ? 's' : ''}`}>
      {sizes.map((s, i) => <Pagina key={i} doc={doc} n={i + 1} w={s.w * escala} h={s.h * escala} escala={escala} root={box} />)}
    </div>
  </div>;
}

// Cada página só é desenhada quando chega perto da tela (PDFs grandes não travam o celular).
function Pagina({ doc, n, w, h, escala, root }: { doc: any; n: number; w: number; h: number; escala: number; root: React.RefObject<HTMLDivElement> }) {
  const wrap = useRef<HTMLDivElement>(null), cv = useRef<HTMLCanvasElement>(null);
  const [visivel, setVisivel] = useState(n <= 2);
  const [pronta, setPronta] = useState(false);
  useEffect(() => {
    const io = new IntersectionObserver(es => es.forEach(e => e.isIntersecting && setVisivel(true)), { root: root.current, rootMargin: '800px 0px' });
    if (wrap.current) io.observe(wrap.current);
    return () => io.disconnect();
  }, [root]);
  useEffect(() => {
    if (!visivel) return;
    let task: any = null, vivo = true;
    (async () => {
      const page = await doc.getPage(n);
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const fator = Math.min(dpr, 4096 / Math.max(w, h)); // limite de tamanho do canvas no celular
      const vp = page.getViewport({ scale: escala * fator });
      const c = cv.current; if (!c || !vivo) return;
      const tmp = document.createElement('canvas'); tmp.width = Math.floor(vp.width); tmp.height = Math.floor(vp.height);
      const ctx = tmp.getContext('2d')!; ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, tmp.width, tmp.height);
      task = page.render({ canvasContext: ctx, viewport: vp, annotationMode: 0 });
      try {
        await task.promise;
        if (!vivo) return;
        c.width = tmp.width; c.height = tmp.height; c.getContext('2d')!.drawImage(tmp, 0, 0); setPronta(true);
      } catch { /* cancelado por mudança de zoom */ }
    })();
    return () => { vivo = false; task?.cancel?.(); };
  }, [visivel, doc, n, escala, w, h]);
  return <div className="vw-page" ref={wrap} style={{ width: w, height: h }} aria-label={`Página ${n}`} role="img">
    <canvas ref={cv} style={{ width: w, height: h }} />
    {!pronta && <span className="vw-load">Página {n}</span>}
  </div>;
}

// ---------- XML ----------
function XML({ data }: { data: ArrayBuffer }) {
  const texto = new TextDecoder().decode(data);
  return <div className="vw-xml">
    <p className="from" style={{ margin: '0 0 10px' }}>Esta nota veio em XML (o arquivo oficial da Receita). Os dados principais estão no painel; abaixo, o conteúdo completo.</p>
    <pre>{bonito(texto)}</pre>
  </div>;
}
function bonito(xml: string) {
  if (xml.length > 400_000) return xml;
  let nivel = 0;
  return xml.replace(/>\s*</g, '><').replace(/(<[^>]+>)/g, '\n$1\n').split('\n').map(s => s.trim()).filter(Boolean).map(s => {
    if (/^<\//.test(s)) nivel = Math.max(0, nivel - 1);
    const linha = '  '.repeat(nivel) + s;
    if (/^<[^!?/][^>]*[^/]>$/.test(s) || /^<[^!?/]>$/.test(s)) nivel++;
    return linha;
  }).join('\n').replace(/(<([\w:]+)[^>]*>)\n\s*([^<\n]+)\n\s*(<\/\2>)/g, '$1$3$4');
}
