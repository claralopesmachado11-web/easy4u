import { createContext, useContext, useEffect, useRef, useState } from 'react';
export interface User { id: string; name: string; email: string; role: 'admin' | 'user'; mfaEnabled: boolean }
export interface Team { id: string; name: string; role: 'gestor' | 'operador' | 'leitor' }
export interface Ctx { user: User; teams: Team[]; team: Team | null; setTeamId: (id: string) => void; refresh: () => Promise<void>; toast: (t: string) => void; logout: () => Promise<void> }
export const AppCtx = createContext<Ctx>(null as unknown as Ctx);
export const useApp = () => useContext(AppCtx);
export const canWrite = (t: Team | null) => !!t && (t.role === 'gestor' || t.role === 'operador');

export function useToast() {
  const [msg, setMsg] = useState('');
  const timer = useRef<number>();
  const toast = (t: string) => { setMsg(t); clearTimeout(timer.current); timer.current = window.setTimeout(() => setMsg(''), 2600); };
  useEffect(() => () => clearTimeout(timer.current), []);
  return { msg, toast };
}
