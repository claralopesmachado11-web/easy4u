# Publicação — Central de Demandas

Guia para colocar o sistema no ar. Os exemplos usam Azure (região Brazil South), mas qualquer hospedagem com contêiner + PostgreSQL gerenciado serve (Azure, Render, Railway, Fly.io, AWS).

> **Projeto independente.** Este sistema foi desenvolvido por fora da empresa e não é uma ferramenta oficial da organização.
> Mesmo assim, para ler a caixa compartilhada ele precisa de uma autorização que **só o administrador do Microsoft 365 da empresa pode dar** (registro do app com `Mail.Read`).
> Os e-mails e as notas fiscais (com CNPJ, valores e dados de fornecedores) passam a ficar guardados no servidor onde o sistema for publicado.
> Antes de ligar a leitura da caixa, tenha a autorização por escrito do responsável pela caixa, da TI/segurança e do DPO da empresa.
> Sem essa autorização, use o sistema só com o Leitor de NF (arquivos enviados à mão), sem cadastrar a caixa.

## 1. O que é preciso (antes de tudo)

| # | Pedido | Para quê |
|---|---|---|
| 1 | **Azure Database for PostgreSQL – Flexible Server** (versão 16), região Brazil South, com backup automático de **35 dias** e backup com redundância geográfica | Banco de dados e cópias de segurança |
| 2 | **App Service (Linux) para contêiner**, **Azure Container Apps** ou outro serviço de contêiner, com HTTPS obrigatório e TLS 1.2+ | Rodar o sistema |
| 3 | **Azure Key Vault** com os segredos da seção 3 (o App Service lê com identidade gerenciada) | Nenhuma senha no código |
| 4 | **Domínio** próprio e certificado HTTPS gerenciado | Endereço com HTTPS |
| 5 | **Registro do app no Microsoft Entra ID** com permissão de aplicativo `Mail.Read` (consentimento de administrador) **restrita só à caixa compartilhada** usando *RBAC for Applications* no Exchange Online (ou *Application Access Policy*) | Ler a caixa sem acessar nenhuma outra |
| 6 | Conta de envio de e-mail (SMTP autenticado no Microsoft 365 ou serviço aprovado) | Convites e recuperação de senha |
| 7 | **Application Insights** + teste de disponibilidade em `https://SEU_DOMINIO/health` a cada 5 minutos, com alerta por e-mail | Saber se o sistema caiu |
| 8 | (Opcional) **Azure OpenAI** com um modelo implantado | Classificação com IA; sem ele, o sistema usa regras |
| 9 | Aprovação do **DPO** (base legal, RIPD, tempo de guarda) | LGPD |

Comando de referência para o administrador do Microsoft 365 restringir o app à caixa (Exchange Online PowerShell):

```powershell
New-ServicePrincipal -AppId <CLIENT_ID> -ObjectId <OBJECT_ID_DO_SERVICE_PRINCIPAL> -DisplayName "Central de Demandas"
New-ManagementScope -Name "Caixa Central" -RecipientRestrictionFilter "PrimarySmtpAddress -eq 'caixa@suaempresa.com.br'"
New-ManagementRoleAssignment -App <OBJECT_ID_DO_SERVICE_PRINCIPAL> -Role "Application Mail.Read" -CustomResourceScope "Caixa Central"
```
(Nesse modelo, a permissão `Mail.Read` **não** é concedida no Entra para o tenant inteiro; ela vale só pelo escopo acima.)

## 2. Banco de dados (TI ou quem administra o PostgreSQL)

1. Gere 4 senhas fortes e guarde no Key Vault.
2. Crie os papéis e o banco (o arquivo não contém senhas):
   ```bash
   psql "$ADMIN_URL" -v owner_pw="$OWNER_PW" -v auth_pw="$AUTH_PW" -v runtime_pw="$RUNTIME_PW" -v worker_pw="$WORKER_PW" -v db=central -f server/migrations/bootstrap-roles.sql
   ```
   No Azure, permita as extensões `citext` e `pgcrypto` (parâmetro `azure.extensions`).
3. Aplique as migrations com o usuário dono:
   ```bash
   DATABASE_URL_OWNER="postgres://app_owner:...@...:5432/central" DB_SSL=require npm run migrate -w server
   ```
4. Libere o acesso ao banco **só pela rede do App Service** (VNet/endpoint privado). Nada de IP público aberto.

## 3. Variáveis de ambiente (Key Vault → App Service)

Veja `.env.example`. Obrigatórias em produção: `APP_URL` (com https), `DB_SSL=require`, `TRUST_PROXY=true`, as três `DATABASE_URL_*`, `ENCRYPTION_KEY` (32 bytes em base64), `SMTP_HOST`, `MAIL_FROM`. O servidor **se recusa a subir** se faltar alguma.

Gerar a chave: `node -e "console.log(require('crypto').randomBytes(32).toString('base64'))"`

## 4. Publicar

```bash
docker build -t central-demandas:1.0.0 .
# enviar ao Azure Container Registry da empresa e apontar o App Service para a imagem
```
O contêiner roda sem usuário root e tem verificação de saúde em `/health`.

**Ordem segura de cada atualização:** testes passando no CI → backup manual → `npm run migrate` → nova imagem → conferir `/health` e entrar no sistema.

## 5. Primeiro acesso

```bash
npm run create-admin -w server -- pessoa@suaempresa.com.br
```
Gera um link de convite de administrador (24 horas, uso único). Não existe usuário ou senha padrão. A pessoa cria a senha, ativa a verificação em duas etapas em **Minha conta** e só então acessa a **Administração**.

## 6. Backups e teste de restauração

- **Automático:** o Flexible Server guarda backups diários com restauração para qualquer ponto dos últimos 35 dias.
- **Teste mensal de restauração (obrigatório):**
  1. No portal: *Restore* → novo servidor `central-restore-AAAAMM` a partir de um ponto de ontem.
  2. Conferir contagens (usuários, demandas, notas, auditoria) e que as regras de acesso existem: `select count(*) from pg_policies where schemaname='app';` (devem ser 56).
  3. Apagar o servidor de teste e anotar data e resultado.
- **Antes de cada atualização:** `pg_dump -Fc` guardado no armazenamento da empresa por 30 dias.

Este procedimento foi testado localmente: backup e restauração devolveram os mesmos registros e as mesmas 56 regras, e o isolamento entre equipes continuou valendo na cópia.

## 7. Monitoramento

- **Disponibilidade:** teste do Application Insights em `/health` (responde 503 se o banco cair).
- **Erros:** logs em JSON do contêiner vão para o Log Analytics. Alerta para qualquer linha com `"level":50`.
- **Segurança:** a tabela `app.audit_log` registra logins, falhas, bloqueios, convites, mudanças de nível e exclusões. Sugestão de alerta: mais de 50 `login.falha` por hora.
- **Anexos:** o tamanho do banco cresce com os PDFs guardados (até 15 MB cada). Acompanhe o espaço e defina com o DPO por quanto tempo guardar.
- **Caixa:** se `app.mailboxes.last_error` ficar preenchido ou `last_sync_at` passar de 30 minutos, a leitura parou.
