# Relatório técnico — Central de Demandas v0.2.0

Projeto independente, desenvolvido por fora da empresa. Não é uma ferramenta ou sistema oficial da organização.

Data: 23/11/2026. Ambiente de testes: Node 22, PostgreSQL 16, Chrome (headless).

## 1. Funcionalidades implementadas e testadas

| Área | O que faz | Como foi testado |
|---|---|---|
| Cadastro por convite | Administrador convida por e-mail; link de uso único que vale 3 dias; não existe cadastro aberto | Automático + navegador |
| Login e sessões | Senha com Argon2id; cookie HttpOnly, SameSite=Strict e Secure (`__Host-`) em produção; sessão de até 10 h, que cai após 2 h parada; logout invalida no servidor | Automático + navegador |
| Recuperação de senha | Link de 1 hora e uso único; mesma resposta exista ou não a conta; troca de senha derruba todas as sessões | Automático |
| Verificação em duas etapas | Código de aplicativo autenticador (TOTP) com QR code; obrigatória para administradores usarem a administração | Automático + navegador |
| Força bruta | 5 erros bloqueiam a conta (15 min, dobrando até 24 h); 20 erros por IP em 15 min bloqueiam o IP; limite geral de 300 requisições por minuto e de 10 por minuto nas rotas de login | Automático |
| Níveis | Administrador (contas e equipes), gestor (tudo na equipe, inclusive apagar), operador (cria e altera), leitor (só consulta) | Automático + navegador |
| Isolamento | Cada equipe só vê os próprios dados; rascunhos do Leitor de NF só o dono vê; o banco impõe isso mesmo que o código erre (RLS forçado, 56 regras) | Automático (inclusive direto no banco) |
| Fila de demandas | Números do dia, abas por situação, busca, confirmar ou descartar, prazo, prioridade, assunto, observação, histórico de alterações com autor | Automático + navegador |
| Notas, pagamentos e fornecedores | Visão própria; esses e-mails nunca são descartados, mesmo vindos de endereços "noreply" | Automático + navegador |
| Leitura da caixa | Microsoft Graph com consulta incremental (só o que mudou), paginação, nova tentativa em caso de limite, não duplica, junta mensagens da mesma conversa | Automático contra um simulador do Graph |
| Classificação | Regras de palavras-chave; Azure OpenAI opcional; se a IA falhar ou responder errado, valem as regras | Automático |
| Quem mais pede / Números da caixa | Remetentes com pendências e atrasos; volume diário de 14 dias | Navegador |
| Leitor de NF | Lê XML, PDF com texto e imagem (OCR) no navegador, sem enviar o arquivo; preenche as 13 colunas; copia para o Excel; salva na equipe sem duplicar; rascunhos pessoais | Navegador (XML e PDF reais de teste) |
| Notas salvas e fornecedores | Pendentes ou lançadas, soma de valores, cadastro e importação colando do Excel | Navegador + automático |
| **Notas anexadas aos e-mails** (v0.2) | Na leitura da caixa, baixa só anexos PDF/XML (até 15 MB, até 10 por e-mail, ignora imagens embutidas). O tipo é conferido pelo conteúdo, não pelo nome. Reconhece NF-e/NFS-e em XML e DANFE em PDF; boletos e outros PDFs são ignorados. Extrai os dados com a mesma lógica do Leitor de NF e cria a nota em **Notas salvas**, ligada à demanda. PDF e XML da mesma nota ficam juntos. A mesma nota ou o mesmo arquivo nunca entram duas vezes. E-mail com nota anexada nunca é descartado, mesmo sem palavra-chave no assunto. PDF escaneado vira nota marcada **Conferir** | Automático (6 testes) + navegador |
| **Visualizador de PDF** (v0.2) | Abre o PDF dentro do site, sem baixar: todas as páginas, página anterior/próxima, ir para a página, zoom e ajustar à largura. Os dados da nota ficam ao lado e podem ser editados; botão **Conferida**. Nota com PDF e XML alterna entre os dois. Funciona no celular. O arquivo é servido só a membros da equipe, como download protegido (sandbox), e desenhado pelo pdf.js sem executar nada do PDF | Navegador (desktop, tablet, celular) |
| **Leitor guarda o arquivo** (v0.2) | Ao salvar na equipe, o PDF/XML original vai junto com a nota (pode desligar). Também há o botão **Anexar** em notas sem arquivo | Automático + navegador |
| Auditoria | Logins, falhas, bloqueios, convites, mudanças de nível e exclusões; o próprio app não consegue alterar nem apagar | Automático |

## 2. Testes realizados

- **46 testes automáticos** de API contra PostgreSQL real: todos passando (6 novos para anexos: identificação, agrupamento, duplicidade, permissões, CSRF, tipos falsos, isolamento no banco).
- **Teste no navegador dos anexos e do visualizador**, com 17 passos e nenhum erro no console. Cobre: 3 notas criadas a partir de e-mails; PDF de 5 páginas aberto e navegado; zoom; edição ao lado; XML; Leitor salvando com o PDF; celular 390 px e tablet.
- **Teste de ponta a ponta no navegador** com 22 passos: convite → duas etapas → equipe → caixa → leitura → conferência → Leitor de NF → notas → logout/login → segunda pessoa pelo celular. Todos passando.
- **Telas** em celular (390 px), tablet (820 px) e computador (1366 px), sem rolagem lateral.
- **Ataques simulados:** SQL Injection na busca e no id, XSS guardado, CSRF sem token, com token errado e de outro site, atribuição em massa (campos extras), IDOR (id de outra equipe), cookie forjado, convite reutilizado, link vencido, escalonamento de privilégio direto no banco.
- **Cabeçalhos de segurança:** CSP restritiva, `frame-ancestors 'none'`, `nosniff`, HSTS em produção, sem `x-powered-by`.
- **Registros:** nenhuma senha, cookie, token ou conteúdo de e-mail nos logs (verificado em 331 linhas).
- **Backup e restauração:** cópia restaurada com os mesmos dados e as mesmas 56 regras de acesso.
- **Configuração de produção:** o servidor se recusa a subir sem SMTP, sem `https://`, sem SSL no banco ou com chave inválida.
- **Dependências:** `npm audit` de produção com zero vulnerabilidades.

## 3. Vulnerabilidades e falhas encontradas

| # | Gravidade | O que era | Situação |
|---|---|---|---|
| 1 | **Alta** | Um usuário comum conseguia se promover a administrador direto no banco: a trava rodava com a identidade do dono das tabelas e nunca disparava | **Corrigida** (migration 003) e coberta por teste |
| 2 | Média | Biblioteca de rotas da interface (react-router 6) com falha conhecida de redirecionamento aberto | **Corrigida** (atualizada para 7.18.6) |
| 3 | Baixa | O CSP pedia "upgrade para HTTPS" também em desenvolvimento | **Corrigida** (só em produção) |
| 5 | Baixa | Fontes carregadas do Google expunham o IP de quem usa | **Corrigida** (fontes servidas pelo próprio site; CSP sem domínios externos) |
| 4 | Funcional | "Atraso na entrega" era classificado como pagamento; "Boleto vencido - NF 4521" como nota fiscal | **Corrigidas** e cobertas por teste |

## 4. Pendências

### Dependem de autorização da empresa (não dá para fazer daqui)
- [ ] **Por ser um projeto independente**, ler a caixa da empresa e guardar notas fiscais fora dos sistemas dela exige autorização por escrito (responsável pela caixa, TI/segurança e DPO).
- [ ] Registro do app no Microsoft 365, restrito à caixa. **A leitura foi testada só contra um simulador; a caixa real ainda não foi lida.**
- [ ] Servidor de e-mail (SMTP). O envio real de convites e de recuperação de senha **não foi testado**.
- [ ] Ambiente Azure, domínio, certificado HTTPS, Key Vault, backups de 35 dias e alertas do Application Insights (passo a passo em `PUBLICACAO.md`).
- [ ] Aprovação do DPO: base legal, RIPD e tempo de guarda.

### Segurança — recomendadas antes ou logo depois de publicar
- [ ] **Compilar e testar a imagem Docker.** Este ambiente não tem o serviço do Docker; só os passos de build que ela roda foram verificados.
- [ ] **Varredura dinâmica (OWASP ZAP) e teste de invasão por terceiros** no ambiente de homologação. Os ataques foram simulados pelos testes, mas o ZAP não roda aqui.
- [ ] **Recuperação da verificação em duas etapas:** ainda não existe um jeito de um administrador zerar as duas etapas de quem perdeu o celular. Hoje isso exige ajuste direto no banco.
- [ ] **Limite de requisições compartilhado:** fica na memória de cada servidor. Com mais de uma instância, use Redis.
- [ ] **Bloqueio de conta como ataque:** alguém pode errar a senha de propósito para travar outra pessoa por até 24 h. O limite por IP reduz o risco; monitorar `login.falha`.
- [ ] A mensagem de conta bloqueada é diferente da de senha errada, o que revela pouco, mas algo, sobre a existência da conta.

### Funcionalidades ainda não feitas
- [ ] Apagar ou anonimizar dados automaticamente depois do prazo de guarda (aguarda decisão do DPO).
- [ ] **OCR de nota escaneada:** os arquivos estão no sistema, mas o teste no navegador usou só XML e PDF com texto. Testar com uma nota escaneada real.
- [ ] Anexos: PDF escaneado vindo por e-mail não passa por OCR no servidor; vira nota **Conferir** para preencher olhando o documento.
- [ ] Anexos: imagens (JPG/PNG) e arquivos compactados (ZIP) anexados ao e-mail não são lidos.
- [ ] Anexos: a leitura de PDF roda no mesmo processo do servidor (limite de 15 MB e 20 s por arquivo). Com muito volume, mover para um processo separado.
- [ ] As datas das notas que chegam por e-mail usam o padrão de 30 dias para vencimento e 7 para envio. Ainda não há configuração por equipe.
- [ ] A demanda na fila ainda não mostra um atalho para a nota; a ligação existe no banco.
- [ ] Importar dados do Leitor de NF antigo.
