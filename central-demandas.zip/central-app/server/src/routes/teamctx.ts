import { z } from 'zod';
import type { Tx } from '../db/index.js';
import { HttpError } from '../auth/guard.js';

export const uuid = z.string().uuid();
export type Role = 'gestor' | 'operador' | 'leitor';
// Checagem na aplicação (mensagem clara) + RLS no banco (garantia final).
export async function teamRole(trx: Tx, teamId: string, userId: string, need: Role[] = ['gestor', 'operador', 'leitor']): Promise<Role> {
  const m = await trx.selectFrom('app.team_members').select('role').where('team_id', '=', teamId).where('user_id', '=', userId).executeTakeFirst();
  if (!m) throw new HttpError(404, 'Equipe não encontrada.'); // não revela se a equipe existe
  if (!need.includes(m.role)) throw new HttpError(403, 'Seu nível nesta equipe não permite essa ação.');
  return m.role;
}
export const WRITE: Role[] = ['gestor', 'operador'];
