import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { withUser } from '../db/index.js';
import { config } from '../config.js';
import { requireAdmin, HttpError } from '../auth/guard.js';
import { revokeAllSessions } from '../auth/session.js';
import { randomToken, sha256 } from '../lib/crypto.js';
import { sendMail } from '../lib/mailer.js';
import { audit } from '../lib/audit.js';
import { syncTeamNow } from '../services/sync.js';

const uuid = z.string().uuid();
const teamRole = z.enum(['gestor', 'operador', 'leitor']);

export async function adminRoutes(app: FastifyInstance) {
  const pre = { preHandler: requireAdmin };

  app.get('/api/admin/users', pre, async req => withUser(req.auth!.userId, trx =>
    trx.selectFrom('app.users').select(['id', 'email', 'name', 'role', 'is_active', 'mfa_enabled', 'locked_until', 'created_at']).orderBy('name').execute()));

  app.patch('/api/admin/users/:id', pre, async req => {
    const { id } = z.object({ id: uuid }).parse(req.params);
    const b = z.object({ name: z.string().trim().min(1).max(120).optional(), role: z.enum(['admin', 'user']).optional(), is_active: z.boolean().optional() }).strict().parse(req.body);
    const a = req.auth!;
    const r = await withUser(a.userId, trx => trx.updateTable('app.users').set(b).where('id', '=', id).executeTakeFirst());
    if (!r.numUpdatedRows) throw new HttpError(404, 'Usuário não encontrado.');
    if (b.is_active === false) await revokeAllSessions(id);
    await audit({ action: 'admin.usuario_alterado', userId: a.userId, entity: 'user', entityId: id, ip: req.ip, meta: b });
    return { ok: true };
  });

  app.post('/api/admin/users/:id/sessions/revoke', pre, async req => {
    const { id } = z.object({ id: uuid }).parse(req.params);
    await revokeAllSessions(id);
    await audit({ action: 'admin.sessoes_encerradas', userId: req.auth!.userId, entity: 'user', entityId: id, ip: req.ip });
    return { ok: true };
  });

  // ---------- convites ----------
  app.get('/api/admin/invites', pre, async req => withUser(req.auth!.userId, trx =>
    trx.selectFrom('app.invites').select(['id', 'email', 'global_role', 'team_id', 'team_role', 'expires_at', 'used_at', 'created_at']).orderBy('created_at', 'desc').limit(200).execute()));

  app.post('/api/admin/invites', pre, async req => {
    const b = z.object({ email: z.string().trim().toLowerCase().email().max(254), globalRole: z.enum(['admin', 'user']).default('user'),
      teamId: uuid.optional(), teamRole: teamRole.optional() }).refine(v => !v.teamId === !v.teamRole, 'Informe equipe e nível juntos').parse(req.body);
    const token = randomToken(32);
    const a = req.auth!;
    await withUser(a.userId, trx => trx.insertInto('app.invites').values({
      token_hash: sha256(token), email: b.email, global_role: b.globalRole, team_id: b.teamId ?? null, team_role: b.teamRole ?? null,
      invited_by: a.userId, expires_at: new Date(Date.now() + 72 * 3600_000) }).execute());
    const link = `${config.APP_URL}/convite#${token}`;
    let emailed = true;
    try { await sendMail({ to: b.email, subject: 'Convite – Central de Demandas', text: `${a.name} convidou você para a Central de Demandas.\n\nCrie sua senha em até 3 dias:\n${link}` }); }
    catch (err) { emailed = false; req.log.error({ err: (err as Error).message }, 'falha ao enviar convite'); }
    await audit({ action: 'admin.convite_criado', userId: a.userId, ip: req.ip, meta: { email: b.email, globalRole: b.globalRole, teamId: b.teamId } });
    return { link, emailed }; // o link aparece uma única vez para o administrador
  });

  app.delete('/api/admin/invites/:id', pre, async req => {
    const { id } = z.object({ id: uuid }).parse(req.params);
    await withUser(req.auth!.userId, trx => trx.deleteFrom('app.invites').where('id', '=', id).execute());
    return { ok: true };
  });

  // ---------- equipes ----------
  app.get('/api/admin/teams', pre, async req => withUser(req.auth!.userId, async trx => {
    const teams = await trx.selectFrom('app.teams').select(['id', 'name']).orderBy('name').execute();
    const members = await trx.selectFrom('app.team_members as m').innerJoin('app.users as u', 'u.id', 'm.user_id')
      .select(['m.team_id', 'm.user_id', 'm.role', 'u.name', 'u.email']).execute();
    const boxes = await trx.selectFrom('app.mailboxes').select(['id', 'team_id', 'address', 'enabled', 'last_sync_at', 'last_error', 'ignore_senders']).execute();
    return teams.map(t => ({ ...t, members: members.filter(m => m.team_id === t.id), mailboxes: boxes.filter(b => b.team_id === t.id) }));
  }));

  app.post('/api/admin/teams', pre, async req => {
    const b = z.object({ name: z.string().trim().min(1).max(80) }).parse(req.body);
    const t = await withUser(req.auth!.userId, trx => trx.insertInto('app.teams').values({ name: b.name }).returning('id').executeTakeFirstOrThrow());
    await audit({ action: 'admin.equipe_criada', userId: req.auth!.userId, teamId: t.id, ip: req.ip });
    return t;
  });

  app.put('/api/admin/teams/:teamId/members/:userId', pre, async req => {
    const p = z.object({ teamId: uuid, userId: uuid }).parse(req.params);
    const { role } = z.object({ role: teamRole }).parse(req.body);
    await withUser(req.auth!.userId, trx => trx.insertInto('app.team_members').values({ team_id: p.teamId, user_id: p.userId, role })
      .onConflict(oc => oc.columns(['team_id', 'user_id']).doUpdateSet({ role })).execute());
    await audit({ action: 'admin.membro_definido', userId: req.auth!.userId, teamId: p.teamId, entity: 'user', entityId: p.userId, ip: req.ip, meta: { role } });
    return { ok: true };
  });

  app.delete('/api/admin/teams/:teamId/members/:userId', pre, async req => {
    const p = z.object({ teamId: uuid, userId: uuid }).parse(req.params);
    await withUser(req.auth!.userId, trx => trx.deleteFrom('app.team_members').where('team_id', '=', p.teamId).where('user_id', '=', p.userId).execute());
    await audit({ action: 'admin.membro_removido', userId: req.auth!.userId, teamId: p.teamId, entity: 'user', entityId: p.userId, ip: req.ip });
    return { ok: true };
  });

  // ---------- caixas monitoradas ----------
  app.post('/api/admin/teams/:teamId/mailboxes', pre, async req => {
    const { teamId } = z.object({ teamId: uuid }).parse(req.params);
    const b = z.object({ address: z.string().trim().toLowerCase().email().max(254), ignore_senders: z.string().max(2000).optional() }).parse(req.body);
    // admin precisa ser membro da equipe para gravar dados dela (regra do banco); aqui usamos o próprio admin com nível gestor
    const r = await withUser(req.auth!.userId, async trx => {
      const isMember = await trx.selectFrom('app.team_members').select('role').where('team_id', '=', teamId).where('user_id', '=', req.auth!.userId).executeTakeFirst();
      if (!isMember || isMember.role === 'leitor') throw new HttpError(403, 'Entre na equipe como gestor para configurar a caixa dela.');
      return trx.insertInto('app.mailboxes').values({ team_id: teamId, address: b.address, ...(b.ignore_senders ? { ignore_senders: b.ignore_senders } : {}) }).returning('id').executeTakeFirstOrThrow();
    });
    await audit({ action: 'admin.caixa_adicionada', userId: req.auth!.userId, teamId, ip: req.ip, meta: { address: b.address } });
    return r;
  });

  app.post('/api/admin/teams/:teamId/sync', pre, async req => {
    const { teamId } = z.object({ teamId: uuid }).parse(req.params);
    return syncTeamNow(teamId, req.log);
  });

  app.get('/api/admin/audit', pre, async req => {
    const q = z.object({ before: z.coerce.number().int().positive().optional() }).parse(req.query);
    return withUser(req.auth!.userId, trx => {
      let s = trx.selectFrom('app.audit_log').select(['id', 'at', 'user_id', 'team_id', 'action', 'entity', 'entity_id', 'ip', 'meta']).orderBy('id', 'desc').limit(100);
      if (q.before) s = s.where('id', '<', String(q.before));
      return s.execute();
    });
  });
}
