import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { sql } from 'kysely';
import * as otp from 'otplib';
import { authDb, withUser } from '../db/index.js';
import { config } from '../config.js';
import { hashPassword, verifyPassword, burnTime, passwordProblem } from '../auth/password.js';
import { createSession, destroySession, revokeAllSessions } from '../auth/session.js';
import { requireAuth, HttpError } from '../auth/guard.js';
import { randomToken, sha256, encrypt, decrypt } from '../lib/crypto.js';
import { sendMail } from '../lib/mailer.js';
import { audit } from '../lib/audit.js';

const email = z.string().trim().toLowerCase().email().max(254);
const strictLimit = { config: { rateLimit: { max: 10, timeWindow: '1 minute' } } };

const IP_MAX_FAILS = 20, WINDOW_MIN = 15, ACCOUNT_MAX_FAILS = 5;

async function teamsOf(userId: string) {
  return withUser(userId, trx => trx.selectFrom('app.team_members as m').innerJoin('app.teams as t', 't.id', 'm.team_id')
    .select(['t.id', 't.name', 'm.role']).where('m.user_id', '=', userId).orderBy('t.name').execute());
}

export async function authRoutes(app: FastifyInstance) {
  // ---------- login ----------
  app.post('/api/auth/login', strictLimit, async (req, reply) => {
    const body = z.object({ email, password: z.string().min(1).max(200) }).parse(req.body);
    const since = new Date(Date.now() - WINDOW_MIN * 60_000);
    const ipFails = await authDb.selectFrom('app.login_attempts').select(sql<number>`count(*)::int`.as('n'))
      .where('ip', '=', req.ip).where('success', '=', false).where('at', '>', since).executeTakeFirstOrThrow();
    if (ipFails.n >= IP_MAX_FAILS) throw new HttpError(429, 'Muitas tentativas. Aguarde alguns minutos.');

    const user = await authDb.selectFrom('app.users').selectAll().where('email', '=', body.email).executeTakeFirst();
    if (user?.locked_until && new Date(user.locked_until) > new Date()) {
      await burnTime(body.password);
      throw new HttpError(429, 'Muitas tentativas. Aguarde alguns minutos.');
    }
    const ok = user && user.is_active ? await verifyPassword(user.password_hash, body.password) : (await burnTime(body.password), false);
    await authDb.insertInto('app.login_attempts').values({ email: body.email, ip: req.ip, success: !!ok }).execute();
    if (!ok || !user) {
      if (user) {
        const n = user.failed_logins + 1;
        const lock = n >= ACCOUNT_MAX_FAILS ? new Date(Date.now() + Math.min(24 * 60, 15 * 2 ** (n - ACCOUNT_MAX_FAILS)) * 60_000) : null;
        await authDb.updateTable('app.users').set({ failed_logins: n, locked_until: lock }).where('id', '=', user.id).execute();
        await audit({ action: 'login.falha', userId: user.id, ip: req.ip, meta: { tentativas: n, bloqueado: !!lock } });
      }
      throw new HttpError(401, 'E-mail ou senha incorretos.');
    }
    await authDb.updateTable('app.users').set({ failed_logins: 0, locked_until: null }).where('id', '=', user.id).execute();
    const csrf = await createSession(reply, req, user.id, user.mfa_enabled);
    await audit({ action: 'login.sucesso', userId: user.id, ip: req.ip });
    return { csrf, mfaRequired: user.mfa_enabled, user: user.mfa_enabled ? null : { id: user.id, name: user.name, email: user.email, role: user.role, mfaEnabled: user.mfa_enabled } };
  });

  app.post('/api/auth/mfa/verify', strictLimit, async (req) => {
    if (!req.auth?.mfaPending) throw new HttpError(400, 'Nada para confirmar.');
    const { code } = z.object({ code: z.string().regex(/^\d{6}$/) }).parse(req.body);
    const u = await authDb.selectFrom('app.users').select(['mfa_secret']).where('id', '=', req.auth.userId).executeTakeFirstOrThrow();
    const valid = u.mfa_secret && (await otp.verify({ secret: decrypt(u.mfa_secret), token: code })).valid;
    if (!valid) { await audit({ action: 'mfa.falha', userId: req.auth.userId, ip: req.ip }); throw new HttpError(401, 'Código inválido.'); }
    await authDb.updateTable('app.sessions').set({ mfa_pending: false }).where('id', '=', req.auth.sessionId).execute();
    return { ok: true };
  });

  app.post('/api/auth/logout', async (req, reply) => {
    await destroySession(reply, req.auth?.sessionId);
    if (req.auth) await audit({ action: 'logout', userId: req.auth.userId, ip: req.ip });
    return { ok: true };
  });

  app.get('/api/auth/me', async (req) => {
    if (!req.auth) return { user: null };
    if (req.auth.mfaPending) return { user: null, mfaRequired: true, csrf: req.auth.csrf };
    const a = req.auth;
    return { csrf: a.csrf, user: { id: a.userId, name: a.name, email: a.email, role: a.role, mfaEnabled: a.mfaEnabled }, teams: await teamsOf(a.userId) };
  });

  // ---------- convites ----------
  app.get('/api/auth/invite/:token', strictLimit, async (req) => {
    const { token } = z.object({ token: z.string().min(20).max(100) }).parse(req.params);
    const inv = await authDb.selectFrom('app.invites').select(['email', 'expires_at', 'used_at']).where('token_hash', '=', sha256(token)).executeTakeFirst();
    if (!inv || inv.used_at || new Date(inv.expires_at) < new Date()) throw new HttpError(404, 'Convite inválido ou expirado.');
    return { email: inv.email };
  });

  app.post('/api/auth/invite/accept', strictLimit, async (req, reply) => {
    const b = z.object({ token: z.string().min(20).max(100), name: z.string().trim().min(1).max(120), password: z.string().max(200) }).parse(req.body);
    const inv = await authDb.selectFrom('app.invites').selectAll().where('token_hash', '=', sha256(b.token)).executeTakeFirst();
    if (!inv || inv.used_at || new Date(inv.expires_at) < new Date()) throw new HttpError(404, 'Convite inválido ou expirado.');
    const problem = passwordProblem(b.password, inv.email);
    if (problem) throw new HttpError(400, problem);
    const hash = await hashPassword(b.password);
    const userId = await authDb.transaction().execute(async trx => {
      // marca o convite como usado primeiro: dois envios ao mesmo tempo não criam duas contas
      const used = await trx.updateTable('app.invites').set({ used_at: new Date() }).where('id', '=', inv.id).where('used_at', 'is', null).executeTakeFirst();
      if (!used.numUpdatedRows) throw new HttpError(409, 'Convite já usado.');
      const exists = await trx.selectFrom('app.users').select('id').where('email', '=', inv.email).executeTakeFirst();
      if (exists) throw new HttpError(409, 'Já existe uma conta com esse e-mail. Use "Esqueci minha senha".');
      const u = await trx.insertInto('app.users').values({ email: inv.email, name: b.name, password_hash: hash, role: inv.global_role }).returning('id').executeTakeFirstOrThrow();
      if (inv.team_id && inv.team_role) await trx.insertInto('app.team_members').values({ team_id: inv.team_id, user_id: u.id, role: inv.team_role }).execute();
      return u.id;
    });
    await audit({ action: 'conta.criada', userId, ip: req.ip, meta: { via: 'convite' } });
    const csrf = await createSession(reply, req, userId, false);
    return { csrf };
  });

  // ---------- recuperação de senha ----------
  app.post('/api/auth/forgot', strictLimit, async (req, reply) => {
    const { email: e } = z.object({ email }).parse(req.body);
    const user = await authDb.selectFrom('app.users').select(['id', 'name', 'is_active']).where('email', '=', e).executeTakeFirst();
    if (user?.is_active) {
      const token = randomToken(32);
      await authDb.deleteFrom('app.password_resets').where('user_id', '=', user.id).where('used_at', 'is', null).execute();
      await authDb.insertInto('app.password_resets').values({ user_id: user.id, token_hash: sha256(token), expires_at: new Date(Date.now() + 3600_000) }).execute();
      try {
        await sendMail({ to: e, subject: 'Redefinir sua senha – Central de Demandas', text:
          `Olá, ${user.name}.\n\nPara criar uma nova senha, abra o link abaixo em até 1 hora:\n${config.APP_URL}/redefinir-senha#${token}\n\nSe não foi você, ignore este e-mail. Sua senha atual continua valendo.` });
      } catch (err) { req.log.error({ err: (err as Error).message }, 'falha ao enviar e-mail de redefinição'); }
      await audit({ action: 'senha.pedido_redefinicao', userId: user.id, ip: req.ip });
    }
    // mesma resposta exista ou não a conta: não revela quem tem cadastro
    reply.code(202);
    return { ok: true, message: 'Se o e-mail estiver cadastrado, enviamos um link para redefinir a senha.' };
  });

  app.post('/api/auth/reset', strictLimit, async (req) => {
    const b = z.object({ token: z.string().min(20).max(100), password: z.string().max(200) }).parse(req.body);
    const r = await authDb.selectFrom('app.password_resets as r').innerJoin('app.users as u', 'u.id', 'r.user_id')
      .select(['r.id', 'r.user_id', 'r.expires_at', 'r.used_at', 'u.email']).where('r.token_hash', '=', sha256(b.token)).executeTakeFirst();
    if (!r || r.used_at || new Date(r.expires_at) < new Date()) throw new HttpError(400, 'Link inválido ou expirado. Peça um novo.');
    const problem = passwordProblem(b.password, r.email);
    if (problem) throw new HttpError(400, problem);
    const hash = await hashPassword(b.password);
    const used = await authDb.updateTable('app.password_resets').set({ used_at: new Date() }).where('id', '=', r.id).where('used_at', 'is', null).executeTakeFirst();
    if (!used.numUpdatedRows) throw new HttpError(400, 'Link já usado.');
    await authDb.updateTable('app.users').set({ password_hash: hash, password_changed_at: new Date(), failed_logins: 0, locked_until: null }).where('id', '=', r.user_id).execute();
    await revokeAllSessions(r.user_id); // derruba sessões antigas, inclusive de quem roubou a senha
    await audit({ action: 'senha.redefinida', userId: r.user_id, ip: req.ip });
    return { ok: true };
  });

  // ---------- conta logada ----------
  app.post('/api/auth/password', { preHandler: requireAuth, ...strictLimit }, async (req) => {
    const b = z.object({ current: z.string().max(200), password: z.string().max(200) }).parse(req.body);
    const a = req.auth!;
    const u = await authDb.selectFrom('app.users').select(['password_hash']).where('id', '=', a.userId).executeTakeFirstOrThrow();
    if (!(await verifyPassword(u.password_hash, b.current))) throw new HttpError(400, 'Senha atual incorreta.');
    const problem = passwordProblem(b.password, a.email);
    if (problem) throw new HttpError(400, problem);
    await authDb.updateTable('app.users').set({ password_hash: await hashPassword(b.password), password_changed_at: new Date() }).where('id', '=', a.userId).execute();
    await revokeAllSessions(a.userId, a.sessionId);
    await audit({ action: 'senha.alterada', userId: a.userId, ip: req.ip });
    return { ok: true };
  });

  app.post('/api/auth/mfa/setup', { preHandler: requireAuth }, async (req) => {
    const a = req.auth!;
    if (a.mfaEnabled) throw new HttpError(400, 'A verificação em duas etapas já está ativa.');
    const secret = otp.generateSecret();
    await authDb.updateTable('app.users').set({ mfa_secret: encrypt(secret) }).where('id', '=', a.userId).execute();
    return { secret, uri: otp.generateURI({ issuer: 'Central de Demandas', label: a.email, secret }) };
  });

  app.post('/api/auth/mfa/enable', { preHandler: requireAuth, ...strictLimit }, async (req) => {
    const { code } = z.object({ code: z.string().regex(/^\d{6}$/) }).parse(req.body);
    const a = req.auth!;
    const u = await authDb.selectFrom('app.users').select(['mfa_secret']).where('id', '=', a.userId).executeTakeFirstOrThrow();
    if (!u.mfa_secret || !(await otp.verify({ secret: decrypt(u.mfa_secret), token: code })).valid) throw new HttpError(400, 'Código inválido. Confira o horário do celular e tente de novo.');
    await authDb.updateTable('app.users').set({ mfa_enabled: true }).where('id', '=', a.userId).execute();
    await audit({ action: 'mfa.ativada', userId: a.userId, ip: req.ip });
    return { ok: true };
  });
}
