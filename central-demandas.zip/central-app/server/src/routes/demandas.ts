import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { sql } from 'kysely';
import { withUser } from '../db/index.js';
import { requireAuth, HttpError } from '../auth/guard.js';
import { audit } from '../lib/audit.js';
import { syncTeamNow } from '../services/sync.js';
import { teamRole, uuid, WRITE } from './teamctx.js';

const STATUS = ['Para validar', 'A fazer', 'Aguardando retorno', 'Concluída', 'Descartada'] as const;
const OPEN = ['A fazer', 'Aguardando retorno'];
const CAT = z.enum(['', 'nota fiscal', 'pagamento', 'fornecedor']);
const date = z.string().regex(/^\d{4}-\d{2}-\d{2}$/).refine(v => !Number.isNaN(Date.parse(v)), 'data inválida');
const today = () => new Date().toLocaleDateString('sv-SE', { timeZone: 'America/Sao_Paulo' });
const COLS = ['id', 'origem', 'subject', 'sender_email', 'sender_name', 'received_at', 'web_link', 'categoria', 'tipo', 'resumo', 'acao',
  'prazo', 'prioridade', 'status', 'obs', 'suspeito', 'nova_msg', 'decisao_ia', 'updated_at'] as const;

export async function demandaRoutes(app: FastifyInstance) {
  const pre = { preHandler: requireAuth };

  app.get('/api/teams', pre, async req => withUser(req.auth!.userId, trx =>
    trx.selectFrom('app.team_members as m').innerJoin('app.teams as t', 't.id', 'm.team_id').select(['t.id', 't.name', 'm.role'])
      .where('m.user_id', '=', req.auth!.userId).orderBy('t.name').execute()));

  app.get('/api/teams/:teamId/demandas', pre, async req => {
    const { teamId } = z.object({ teamId: uuid }).parse(req.params);
    const q = z.object({ view: z.enum(['validar', 'abertas', 'retorno', 'concluidas', 'descartadas', 'todas', 'atrasadas', 'fin']).default('validar'),
      q: z.string().max(100).optional(), sender: z.string().max(254).optional() }).parse(req.query);
    return withUser(req.auth!.userId, async trx => {
      await teamRole(trx, teamId, req.auth!.userId);
      let s = trx.selectFrom('app.demandas').select([...COLS]).where('team_id', '=', teamId);
      const v = q.view;
      if (v === 'validar') s = s.where('status', '=', 'Para validar');
      if (v === 'abertas') s = s.where('status', 'in', OPEN);
      if (v === 'retorno') s = s.where('status', '=', 'Aguardando retorno');
      if (v === 'concluidas') s = s.where('status', '=', 'Concluída');
      if (v === 'descartadas') s = s.where('status', '=', 'Descartada');
      if (v === 'atrasadas') s = s.where('status', 'in', OPEN).where('prazo', '<', today());
      if (v === 'fin') s = s.where('categoria', '!=', '').where('status', 'in', ['Para validar', ...OPEN]);
      if (q.sender) s = s.where('sender_email', '=', q.sender.toLowerCase());
      if (q.q) { const like = `%${q.q.replace(/[\\%_]/g, m => '\\' + m)}%`; s = s.where(eb => eb.or([eb('subject', 'ilike', like), eb('sender_name', 'ilike', like), eb('resumo', 'ilike', like), eb('obs', 'ilike', like)])); }
      return s.orderBy(sql`prazo asc nulls last`).orderBy('received_at', 'desc').limit(500).execute();
    });
  });

  app.get('/api/teams/:teamId/painel', pre, async req => {
    const { teamId } = z.object({ teamId: uuid }).parse(req.params);
    return withUser(req.auth!.userId, async trx => {
      const role = await teamRole(trx, teamId, req.auth!.userId);
      const t = today(), tm = new Date(Date.now() + 864e5).toLocaleDateString('sv-SE', { timeZone: 'America/Sao_Paulo' });
      const c = await trx.selectFrom('app.demandas').where('team_id', '=', teamId).select([
        sql<number>`count(*) filter (where status = 'Para validar')::int`.as('validar'),
        sql<number>`count(*) filter (where categoria <> '' and status in ('Para validar','A fazer','Aguardando retorno'))::int`.as('fin'),
        sql<number>`count(*) filter (where prioridade = 'alta' and status in ('Para validar','A fazer','Aguardando retorno'))::int`.as('alta'),
        sql<number>`count(*) filter (where prazo < ${t}::date and status in ('A fazer','Aguardando retorno'))::int`.as('atrasadas'),
        sql<number>`count(*) filter (where prazo in (${t}::date, ${tm}::date) and status in ('A fazer','Aguardando retorno'))::int`.as('vence'),
        sql<number>`count(*) filter (where status = 'Aguardando retorno')::int`.as('retorno'),
        sql<number>`count(*) filter (where status = 'Concluída' and updated_at > now() - interval '7 days')::int`.as('concluidas7'),
      ]).executeTakeFirstOrThrow();
      const boxes = await trx.selectFrom('app.mailboxes').select(['address', 'last_sync_at', 'last_error']).where('team_id', '=', teamId).execute();
      return { role, counts: c, mailboxes: boxes };
    });
  });

  app.post('/api/teams/:teamId/demandas', pre, async req => {
    const { teamId } = z.object({ teamId: uuid }).parse(req.params);
    const b = z.object({ subject: z.string().trim().min(1).max(300), sender_name: z.string().trim().max(200).optional(), acao: z.string().trim().max(300).default(''),
      prazo: date.nullable().optional(), prioridade: z.enum(['alta', 'media', 'baixa']).default('media'), categoria: CAT.default('') }).parse(req.body);
    const a = req.auth!;
    return withUser(a.userId, async trx => {
      await teamRole(trx, teamId, a.userId, WRITE);
      const r = await trx.insertInto('app.demandas').values({ team_id: teamId, origem: 'manual', subject: b.subject, sender_name: b.sender_name || null, acao: b.acao,
        prazo: b.prazo ?? null, prioridade: b.prioridade, categoria: b.categoria, status: 'A fazer', created_by: a.userId }).returning('id').executeTakeFirstOrThrow();
      await audit({ action: 'demanda.criada', userId: a.userId, teamId, entity: 'demanda', entityId: r.id, ip: req.ip }, trx);
      return r;
    });
  });

  app.patch('/api/teams/:teamId/demandas/:id', pre, async req => {
    const p = z.object({ teamId: uuid, id: uuid }).parse(req.params);
    const b = z.object({ status: z.enum(STATUS).optional(), prioridade: z.enum(['alta', 'media', 'baixa']).optional(), prazo: date.nullable().optional(),
      categoria: CAT.optional(), obs: z.string().max(500).optional(), acao: z.string().max(300).optional() }).strict().parse(req.body);
    if (!Object.keys(b).length) throw new HttpError(400, 'Nada para alterar.');
    const a = req.auth!;
    return withUser(a.userId, async trx => {
      await teamRole(trx, p.teamId, a.userId, WRITE);
      const old = await trx.selectFrom('app.demandas').select(['status', 'prioridade', 'prazo', 'categoria', 'obs', 'acao']).where('id', '=', p.id).where('team_id', '=', p.teamId).forUpdate().executeTakeFirst();
      if (!old) throw new HttpError(404, 'Demanda não encontrada.');
      const set: Record<string, unknown> = { ...b, updated_at: new Date() };
      if (b.status) set.nova_msg = false;
      await trx.updateTable('app.demandas').set(set).where('id', '=', p.id).where('team_id', '=', p.teamId).execute();
      const changes = Object.entries(b).filter(([k, v]) => String((old as Record<string, unknown>)[k] ?? '') !== String(v ?? ''));
      if (changes.length) await trx.insertInto('app.demanda_eventos').values(changes.map(([k, v]) => ({ demanda_id: p.id, team_id: p.teamId, user_id: a.userId,
        campo: k, de: String((old as Record<string, unknown>)[k] ?? '').slice(0, 500), para: String(v ?? '').slice(0, 500) }))).execute();
      return { ok: true };
    });
  });

  app.delete('/api/teams/:teamId/demandas/:id', pre, async req => {
    const p = z.object({ teamId: uuid, id: uuid }).parse(req.params);
    const a = req.auth!;
    return withUser(a.userId, async trx => {
      await teamRole(trx, p.teamId, a.userId, ['gestor']);
      const r = await trx.deleteFrom('app.demandas').where('id', '=', p.id).where('team_id', '=', p.teamId).executeTakeFirst();
      if (!Number(r.numDeletedRows)) throw new HttpError(404, 'Demanda não encontrada.');
      await audit({ action: 'demanda.apagada', userId: a.userId, teamId: p.teamId, entity: 'demanda', entityId: p.id, ip: req.ip }, trx);
      return { ok: true };
    });
  });

  app.get('/api/teams/:teamId/demandas/:id/historico', pre, async req => {
    const p = z.object({ teamId: uuid, id: uuid }).parse(req.params);
    return withUser(req.auth!.userId, async trx => {
      await teamRole(trx, p.teamId, req.auth!.userId);
      return trx.selectFrom('app.demanda_eventos as e').leftJoin('app.users as u', 'u.id', 'e.user_id')
        .select(['e.campo', 'e.de', 'e.para', 'e.at', 'u.name']).where('e.demanda_id', '=', p.id).where('e.team_id', '=', p.teamId).orderBy('e.at', 'desc').limit(100).execute();
    });
  });

  app.get('/api/teams/:teamId/numeros', pre, async req => {
    const { teamId } = z.object({ teamId: uuid }).parse(req.params);
    return withUser(req.auth!.userId, async trx => {
      await teamRole(trx, teamId, req.auth!.userId);
      return trx.selectFrom('app.stats_diarios').select(['dia', 'recebidos', 'regra', 'info', 'novas']).where('team_id', '=', teamId).orderBy('dia', 'desc').limit(14).execute();
    });
  });

  app.get('/api/teams/:teamId/remetentes', pre, async req => {
    const { teamId } = z.object({ teamId: uuid }).parse(req.params);
    return withUser(req.auth!.userId, async trx => {
      await teamRole(trx, teamId, req.auth!.userId);
      const t = today();
      return trx.selectFrom('app.demandas').where('team_id', '=', teamId).where('status', '!=', 'Descartada')
        .select([sql<string>`coalesce(sender_email::text, '')`.as('email'), sql<string>`max(coalesce(sender_name, sender_email::text, 'Sem remetente'))`.as('nome'),
          sql<number>`count(*) filter (where status in ('Para validar','A fazer','Aguardando retorno'))::int`.as('aberto'),
          sql<number>`count(*) filter (where prazo < ${t}::date and status in ('A fazer','Aguardando retorno'))::int`.as('atrasadas'),
          sql<number>`count(*) filter (where categoria <> '' and status in ('Para validar','A fazer','Aguardando retorno'))::int`.as('fin'),
          sql<number>`count(*)::int`.as('total'), sql<string>`max(received_at)`.as('ultimo')])
        .groupBy(sql`coalesce(sender_email::text, '')`).orderBy('atrasadas', 'desc').orderBy('aberto', 'desc').limit(200).execute();
    });
  });

  app.post('/api/teams/:teamId/sync', { preHandler: requireAuth, config: { rateLimit: { max: 6, timeWindow: '1 minute' } } }, async req => {
    const { teamId } = z.object({ teamId: uuid }).parse(req.params);
    await withUser(req.auth!.userId, trx => teamRole(trx, teamId, req.auth!.userId, WRITE));
    return syncTeamNow(teamId, req.log);
  });
}
