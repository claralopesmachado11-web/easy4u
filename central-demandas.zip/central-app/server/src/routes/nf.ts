import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { withUser } from '../db/index.js';
import { requireAuth, HttpError } from '../auth/guard.js';
import { audit } from '../lib/audit.js';
import { teamRole, uuid, WRITE } from './teamctx.js';
import { sql } from 'kysely';
import { abrirPDF, sniff, sha256hex, MAX_ANEXO } from '../nf/analisar.js';

const s = (max: number) => z.string().trim().max(max).transform(v => v || null).nullable().optional();
const date = z.string().regex(/^\d{4}-\d{2}-\d{2}$/).refine(v => !Number.isNaN(Date.parse(v)), 'data inválida').nullable().optional();
const cnpj = z.string().transform(v => v.replace(/\D/g, '')).refine(v => v === '' || v.length === 14, 'CNPJ precisa ter 14 dígitos').transform(v => v || null).nullable().optional();
const valor = z.union([z.number(), z.string()]).transform(v => {
  if (typeof v === 'number') return v;
  const t = v.replace(/[R$\s]/g, '');
  return Number(/,\d{1,2}$/.test(t) ? t.replace(/\./g, '').replace(',', '.') : t.replace(/,/g, ''));
}).refine(v => Number.isFinite(v) && v >= 0 && v < 1e12, 'valor inválido').nullable().optional();

const nota = z.object({ mes: s(20), qz: s(10), base: s(40), codigo: s(40), fornecedor: s(200), cnpj, rc: s(40), po: s(40), migo: s(40),
  numero_nf: z.string().trim().min(1).max(40), valor, emissao: date, vencimento: date, envio_central: date });
const fornecedor = z.object({ codigo: z.string().trim().min(1).max(40), nome: z.string().trim().min(1).max(200), cnpj, base: s(40), obs: z.string().max(500).default('') });
const NOTA_COLS = ['id', 'mes', 'qz', 'base', 'codigo', 'fornecedor', 'cnpj', 'rc', 'po', 'migo', 'numero_nf', 'valor', 'emissao', 'vencimento', 'envio_central', 'status', 'created_at', 'origem', 'avisos', 'conferir', 'demanda_id'] as const;

export async function nfRoutes(app: FastifyInstance) {
  const pre = { preHandler: requireAuth };

  // ---------- notas da equipe ----------
  app.get('/api/teams/:teamId/notas', pre, async req => {
    const { teamId } = z.object({ teamId: uuid }).parse(req.params);
    const q = z.object({ status: z.enum(['pendente', 'lancada', 'conferir', 'todas']).default('todas'), q: z.string().max(100).optional() }).parse(req.query);
    return withUser(req.auth!.userId, async trx => {
      await teamRole(trx, teamId, req.auth!.userId);
      let sel = trx.selectFrom('app.notas').select([...NOTA_COLS])
        .select(sql<{ id: string; nome: string; tipo: string; tamanho: number }[]>`coalesce((select json_agg(json_build_object('id', a.id, 'nome', a.nome, 'tipo', a.tipo, 'tamanho', a.tamanho) order by a.tipo, a.created_at) from app.anexos a where a.nota_id = app.notas.id), '[]'::json)`.as('anexos'))
        .where('team_id', '=', teamId);
      if (q.status === 'conferir') sel = sel.where('conferir', '=', true);
      else if (q.status !== 'todas') sel = sel.where('status', '=', q.status);
      if (q.q) { const like = `%${q.q.replace(/[\\%_]/g, m => '\\' + m)}%`; sel = sel.where(eb => eb.or([eb('fornecedor', 'ilike', like), eb('numero_nf', 'ilike', like), eb('po', 'ilike', like), eb('codigo', 'ilike', like)])); }
      return sel.orderBy('created_at', 'desc').limit(1000).execute();
    });
  });

  // grava as linhas lidas pelo leitor; notas repetidas (mesmo fornecedor + número) não entram de novo
  app.post('/api/teams/:teamId/notas', { preHandler: requireAuth, bodyLimit: 2_000_000 }, async req => {
    const { teamId } = z.object({ teamId: uuid }).parse(req.params);
    const { notas } = z.object({ notas: z.array(nota).min(1).max(300) }).parse(req.body);
    const a = req.auth!;
    return withUser(a.userId, async trx => {
      await teamRole(trx, teamId, a.userId, WRITE);
      const created: string[] = [], duplicadas: string[] = [], ids: (string | null)[] = [];
      for (const n of notas) {
        const key = n.cnpj ?? n.fornecedor ?? '';
        const dup = await trx.selectFrom('app.notas').select('id').where('team_id', '=', teamId).where('numero_nf', '=', n.numero_nf)
          .where(eb => eb.fn.coalesce('cnpj', 'fornecedor', eb.val('')), '=', key).executeTakeFirst();
        if (dup) { duplicadas.push(n.numero_nf); ids.push(null); continue; }
        const r = await trx.insertInto('app.notas').values({ ...n, valor: n.valor == null ? null : n.valor.toFixed(2), team_id: teamId, created_by: a.userId } as never).returning('id').executeTakeFirstOrThrow();
        created.push(r.id); ids.push(r.id);
      }
      await audit({ action: 'notas.importadas', userId: a.userId, teamId, ip: req.ip, meta: { novas: created.length, duplicadas: duplicadas.length } }, trx);
      return { criadas: created.length, duplicadas, ids };
    });
  });

  app.patch('/api/teams/:teamId/notas/:id', pre, async req => {
    const p = z.object({ teamId: uuid, id: uuid }).parse(req.params);
    const b = nota.partial().extend({ status: z.enum(['pendente', 'lancada']).optional(), conferir: z.literal(false).optional() }).strict().parse(req.body);
    const a = req.auth!;
    return withUser(a.userId, async trx => {
      await teamRole(trx, p.teamId, a.userId, WRITE);
      const set: Record<string, unknown> = { ...b, updated_at: new Date() };
      if (b.valor !== undefined) set.valor = b.valor == null ? null : b.valor.toFixed(2);
      const r = await trx.updateTable('app.notas').set(set).where('id', '=', p.id).where('team_id', '=', p.teamId).executeTakeFirst();
      if (!Number(r.numUpdatedRows)) throw new HttpError(404, 'Nota não encontrada.');
      return { ok: true };
    });
  });

  app.delete('/api/teams/:teamId/notas/:id', pre, async req => {
    const p = z.object({ teamId: uuid, id: uuid }).parse(req.params);
    const a = req.auth!;
    return withUser(a.userId, async trx => {
      await teamRole(trx, p.teamId, a.userId, ['gestor']);
      const r = await trx.deleteFrom('app.notas').where('id', '=', p.id).where('team_id', '=', p.teamId).executeTakeFirst();
      if (!Number(r.numDeletedRows)) throw new HttpError(404, 'Nota não encontrada.');
      await audit({ action: 'nota.apagada', userId: a.userId, teamId: p.teamId, entity: 'nota', entityId: p.id, ip: req.ip }, trx);
      return { ok: true };
    });
  });

  // ---------- arquivos das notas (PDF e XML) ----------
  // Abre o arquivo para o visualizador do site. Só membros da equipe (o banco confere de novo pelo RLS).
  app.get('/api/teams/:teamId/anexos/:id', pre, async (req, reply) => {
    const p = z.object({ teamId: uuid, id: uuid }).parse(req.params);
    const f = await withUser(req.auth!.userId, async trx => {
      await teamRole(trx, p.teamId, req.auth!.userId);
      return trx.selectFrom('app.anexos').select(['nome', 'tipo', 'conteudo']).where('id', '=', p.id).where('team_id', '=', p.teamId).executeTakeFirst();
    });
    if (!f) throw new HttpError(404, 'Arquivo não encontrado.');
    return reply
      .header('content-type', f.tipo === 'pdf' ? 'application/pdf' : 'application/xml; charset=utf-8')
      .header('content-disposition', `attachment; filename*=UTF-8''${encodeURIComponent(f.nome)}`)
      .header('content-security-policy', "sandbox; default-src 'none'")
      .header('cache-control', 'private, no-store')
      .send(f.conteudo);
  });

  // Anexa o PDF/XML a uma nota (usado pelo Leitor de NF ao salvar, ou pelo botão "Anexar arquivo").
  const RAW = ['application/pdf', 'application/xml', 'text/xml'];
  app.addContentTypeParser(RAW, { parseAs: 'buffer', bodyLimit: MAX_ANEXO }, (_req, body, done) => done(null, body));
  app.post('/api/teams/:teamId/notas/:id/anexos', { preHandler: requireAuth, bodyLimit: MAX_ANEXO, config: { rateLimit: { max: 60, timeWindow: '1 minute' } } }, async (req, reply) => {
    const p = z.object({ teamId: uuid, id: uuid }).parse(req.params);
    const ct = String(req.headers['content-type'] ?? '').split(';')[0].trim().toLowerCase();
    const buf = req.body;
    if (!RAW.includes(ct) || !Buffer.isBuffer(buf) || !buf.length) throw new HttpError(415, 'Envie um PDF ou XML.');
    let nome = 'nota';
    try { nome = decodeURIComponent(String(req.headers['x-file-name'] ?? 'nota')); } catch { /* nome inválido: usa o padrão */ }
    nome = nome.replace(/[\u0000-\u001f\\/]/g, '_').trim().slice(0, 200) || 'nota';
    const tipo = sniff(buf);
    if (!tipo || (tipo === 'pdf') !== (ct === 'application/pdf')) throw new HttpError(415, 'O conteúdo do arquivo não é um PDF ou XML válido.');
    if (tipo === 'pdf') { try { const d = await abrirPDF(buf); await d.destroy?.(); } catch { throw new HttpError(415, 'Não consegui abrir esse PDF. Ele pode estar corrompido ou protegido por senha.'); } }
    const a = req.auth!;
    const r = await withUser(a.userId, async trx => {
      await teamRole(trx, p.teamId, a.userId, WRITE);
      const nota = await trx.selectFrom('app.notas').select('id').where('id', '=', p.id).where('team_id', '=', p.teamId).executeTakeFirst();
      if (!nota) throw new HttpError(404, 'Nota não encontrada.');
      const qtd = await trx.selectFrom('app.anexos').select(eb => eb.fn.countAll<string>().as('n')).where('nota_id', '=', p.id).executeTakeFirstOrThrow();
      if (Number(qtd.n) >= 5) throw new HttpError(400, 'Essa nota já tem 5 arquivos.');
      const igual = await trx.selectFrom('app.anexos').select('nota_id').where('team_id', '=', p.teamId).where('sha256', '=', sha256hex(buf)).executeTakeFirst();
      if (igual) throw new HttpError(409, igual.nota_id === p.id ? 'Esse arquivo já está nesta nota.' : 'Esse mesmo arquivo já está guardado em outra nota da equipe.');
      const ins = await trx.insertInto('app.anexos').values({ team_id: p.teamId, nota_id: p.id, origem: 'leitor', nome, tipo, tamanho: buf.length,
        sha256: sha256hex(buf), conteudo: buf, created_by: a.userId }).returning('id').executeTakeFirstOrThrow();
      await audit({ action: 'anexo.enviado', userId: a.userId, teamId: p.teamId, entity: 'nota', entityId: p.id, ip: req.ip, meta: { tipo, tamanho: buf.length } }, trx);
      return ins;
    });
    return reply.code(201).send({ id: r.id, tipo });
  });

  app.delete('/api/teams/:teamId/anexos/:id', pre, async req => {
    const p = z.object({ teamId: uuid, id: uuid }).parse(req.params);
    const a = req.auth!;
    return withUser(a.userId, async trx => {
      await teamRole(trx, p.teamId, a.userId, ['gestor']);
      const r = await trx.deleteFrom('app.anexos').where('id', '=', p.id).where('team_id', '=', p.teamId).executeTakeFirst();
      if (!Number(r.numDeletedRows)) throw new HttpError(404, 'Arquivo não encontrado.');
      await audit({ action: 'anexo.apagado', userId: a.userId, teamId: p.teamId, entity: 'anexo', entityId: p.id, ip: req.ip }, trx);
      return { ok: true };
    });
  });

  // ---------- fornecedores ----------
  app.get('/api/teams/:teamId/fornecedores', pre, async req => {
    const { teamId } = z.object({ teamId: uuid }).parse(req.params);
    return withUser(req.auth!.userId, async trx => {
      await teamRole(trx, teamId, req.auth!.userId);
      return trx.selectFrom('app.fornecedores').select(['id', 'codigo', 'nome', 'cnpj', 'base', 'obs']).where('team_id', '=', teamId).orderBy('nome').limit(2000).execute();
    });
  });
  app.post('/api/teams/:teamId/fornecedores', pre, async req => {
    const { teamId } = z.object({ teamId: uuid }).parse(req.params);
    const b = fornecedor.parse(req.body);
    return withUser(req.auth!.userId, async trx => {
      await teamRole(trx, teamId, req.auth!.userId, WRITE);
      return trx.insertInto('app.fornecedores').values({ ...b, cnpj: b.cnpj ?? null, base: b.base ?? null, team_id: teamId }).returning('id').executeTakeFirstOrThrow();
    });
  });
  app.patch('/api/teams/:teamId/fornecedores/:id', pre, async req => {
    const p = z.object({ teamId: uuid, id: uuid }).parse(req.params);
    const b = fornecedor.partial().strict().parse(req.body);
    return withUser(req.auth!.userId, async trx => {
      await teamRole(trx, p.teamId, req.auth!.userId, WRITE);
      const r = await trx.updateTable('app.fornecedores').set({ ...b, updated_at: new Date() } as never).where('id', '=', p.id).where('team_id', '=', p.teamId).executeTakeFirst();
      if (!Number(r.numUpdatedRows)) throw new HttpError(404, 'Fornecedor não encontrado.');
      return { ok: true };
    });
  });
  app.delete('/api/teams/:teamId/fornecedores/:id', pre, async req => {
    const p = z.object({ teamId: uuid, id: uuid }).parse(req.params);
    return withUser(req.auth!.userId, async trx => {
      await teamRole(trx, p.teamId, req.auth!.userId, ['gestor']);
      const r = await trx.deleteFrom('app.fornecedores').where('id', '=', p.id).where('team_id', '=', p.teamId).executeTakeFirst();
      if (!Number(r.numDeletedRows)) throw new HttpError(404, 'Fornecedor não encontrado.');
      return { ok: true };
    });
  });

  // ---------- rascunhos pessoais do leitor (só o próprio usuário vê) ----------
  app.get('/api/rascunhos', pre, async req => withUser(req.auth!.userId, trx =>
    trx.selectFrom('app.rascunhos_nf').select(['id', 'nome', 'linhas', 'updated_at']).where('user_id', '=', req.auth!.userId).orderBy('updated_at', 'desc').limit(50).execute()));
  app.put('/api/rascunhos/:id', { preHandler: requireAuth, bodyLimit: 600_000 }, async req => {
    const { id } = z.object({ id: uuid }).parse(req.params);
    const b = z.object({ nome: z.string().trim().min(1).max(120), linhas: z.array(z.record(z.string(), z.union([z.string().max(300), z.number(), z.null()]))).max(500) }).parse(req.body);
    const uid = req.auth!.userId;
    return withUser(uid, async trx => {
      await trx.insertInto('app.rascunhos_nf').values({ id, user_id: uid, nome: b.nome, linhas: JSON.stringify(b.linhas) })
        .onConflict(oc => oc.column('id').doUpdateSet({ nome: b.nome, linhas: JSON.stringify(b.linhas), updated_at: new Date() }).where('app.rascunhos_nf.user_id', '=', uid)).execute();
      return { ok: true };
    });
  });
  app.delete('/api/rascunhos/:id', pre, async req => {
    const { id } = z.object({ id: uuid }).parse(req.params);
    await withUser(req.auth!.userId, trx => trx.deleteFrom('app.rascunhos_nf').where('id', '=', id).execute());
    return { ok: true };
  });
}
