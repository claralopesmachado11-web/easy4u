import type { ColumnType, Generated } from 'kysely';

type Ts = ColumnType<Date, Date | string | undefined, Date | string>;
type TsNull = ColumnType<Date | null, Date | string | null | undefined, Date | string | null>;

export interface UsersTable {
  id: Generated<string>; email: string; name: string; password_hash: string;
  role: Generated<'admin' | 'user'>; is_active: Generated<boolean>; failed_logins: Generated<number>;
  locked_until: TsNull; mfa_secret: string | null; mfa_enabled: Generated<boolean>;
  password_changed_at: Ts; created_at: Ts; updated_at: Ts;
}
export interface SessionsTable {
  id: string; user_id: string; csrf_token: string; mfa_pending: Generated<boolean>;
  ip: string | null; user_agent: string | null; created_at: Ts; last_seen_at: Ts; expires_at: Ts;
}
export interface TeamsTable { id: Generated<string>; name: string; created_at: Ts; }
export interface TeamMembersTable { team_id: string; user_id: string; role: 'gestor' | 'operador' | 'leitor'; created_at: Ts; }
export interface InvitesTable {
  id: Generated<string>; token_hash: string; email: string; global_role: Generated<'admin' | 'user'>;
  team_id: string | null; team_role: 'gestor' | 'operador' | 'leitor' | null; invited_by: string | null;
  expires_at: Ts; used_at: TsNull; created_at: Ts;
}
export interface PasswordResetsTable { id: Generated<string>; user_id: string; token_hash: string; expires_at: Ts; used_at: TsNull; created_at: Ts; }
export interface LoginAttemptsTable { id: Generated<string>; email: string | null; ip: string | null; success: boolean; at: Ts; }
export interface MailboxesTable {
  id: Generated<string>; team_id: string; address: string; ignore_senders: Generated<string>;
  delta_link: string | null; enabled: Generated<boolean>; last_sync_at: TsNull; last_error: string | null; created_at: Ts;
}
export interface DemandasTable {
  id: Generated<string>; team_id: string; origem: 'email' | 'manual'; message_id: string | null; conversation_id: string | null;
  subject: string; sender_email: string | null; sender_name: string | null; received_at: Ts; web_link: string | null;
  categoria: Generated<string>; tipo: Generated<string>; resumo: Generated<string>; acao: Generated<string>;
  prazo: string | null; prioridade: Generated<string>; status: Generated<string>; obs: Generated<string>;
  suspeito: Generated<boolean>; nova_msg: Generated<boolean>; decisao_ia: Generated<string>;
  created_by: string | null; created_at: Ts; updated_at: Ts;
}
export interface DemandaEventosTable { id: Generated<string>; demanda_id: string; team_id: string; user_id: string | null; campo: string; de: string | null; para: string | null; at: Ts; }
export interface StatsDiariosTable { team_id: string; dia: string; recebidos: Generated<number>; regra: Generated<number>; info: Generated<number>; novas: Generated<number>; }
export interface FornecedoresTable { id: Generated<string>; team_id: string; codigo: string; nome: string; cnpj: string | null; base: string | null; obs: Generated<string>; created_at: Ts; updated_at: Ts; }
export interface NotasTable {
  id: Generated<string>; team_id: string; mes: string | null; qz: string | null; base: string | null; codigo: string | null;
  fornecedor: string | null; cnpj: string | null; rc: string | null; po: string | null; migo: string | null; numero_nf: string | null;
  valor: string | null; emissao: string | null; vencimento: string | null; envio_central: string | null;
  status: Generated<'pendente' | 'lancada'>; created_by: string | null; created_at: Ts; updated_at: Ts;
  origem: Generated<'leitor' | 'email'>; demanda_id: string | null; avisos: Generated<string>; conferir: Generated<boolean>;
}
export interface AnexosTable {
  id: Generated<string>; team_id: string; nota_id: string; origem: 'leitor' | 'email'; message_id: string | null; nome: string;
  tipo: 'pdf' | 'xml'; tamanho: number; sha256: string; conteudo: Buffer; created_by: string | null; created_at: Ts;
}
export interface RascunhosTable { id: Generated<string>; user_id: string; nome: string; linhas: ColumnType<unknown[], string, string>; updated_at: Ts; }
export interface AuditTable { id: Generated<string>; at: Ts; user_id: string | null; team_id: string | null; action: string; entity: string | null; entity_id: string | null; ip: string | null; meta: ColumnType<unknown, string | undefined, string>; }

export interface DB {
  'app.users': UsersTable; 'app.sessions': SessionsTable; 'app.teams': TeamsTable; 'app.team_members': TeamMembersTable;
  'app.invites': InvitesTable; 'app.password_resets': PasswordResetsTable; 'app.login_attempts': LoginAttemptsTable;
  'app.mailboxes': MailboxesTable; 'app.demandas': DemandasTable; 'app.demanda_eventos': DemandaEventosTable;
  'app.stats_diarios': StatsDiariosTable; 'app.fornecedores': FornecedoresTable; 'app.notas': NotasTable;
  'app.rascunhos_nf': RascunhosTable; 'app.audit_log': AuditTable; 'app.anexos': AnexosTable;
}
