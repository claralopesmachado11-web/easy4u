// Aplica as migrations em ordem, cada uma numa transação, registrando o que já rodou.
// Uso: DATABASE_URL_OWNER=... npm run migrate
import { readdirSync, readFileSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
import pg from 'pg';

const dir = join(dirname(fileURLToPath(import.meta.url)), '..', '..', 'migrations');

export async function migrate(connectionString: string, log = console.log) {
  const client = new pg.Client({ connectionString, ssl: process.env.DB_SSL === 'require' ? { rejectUnauthorized: true } : undefined });
  await client.connect();
  try {
    await client.query('CREATE TABLE IF NOT EXISTS public.schema_migrations (name text PRIMARY KEY, checksum text NOT NULL, applied_at timestamptz NOT NULL DEFAULT now())');
    const done = new Map((await client.query('SELECT name, checksum FROM public.schema_migrations')).rows.map(r => [r.name, r.checksum]));
    const files = readdirSync(dir).filter(f => /^\d{3}_.+\.sql$/.test(f)).sort();
    for (const f of files) {
      const body = readFileSync(join(dir, f), 'utf8');
      const sum = createHash('sha256').update(body).digest('hex');
      if (done.has(f)) {
        if (done.get(f) !== sum) throw new Error(`Migration ${f} foi alterada depois de aplicada. Crie uma nova migration em vez de editar.`);
        continue;
      }
      await client.query('BEGIN');
      try {
        await client.query(body);
        await client.query('INSERT INTO public.schema_migrations(name, checksum) VALUES ($1, $2)', [f, sum]);
        await client.query('COMMIT');
        log(`aplicada: ${f}`);
      } catch (e) { await client.query('ROLLBACK'); throw e; }
    }
  } finally { await client.end(); }
}

if (process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1]) {
  const url = process.env.DATABASE_URL_OWNER;
  if (!url) { console.error('Defina DATABASE_URL_OWNER'); process.exit(1); }
  migrate(url).then(() => console.log('migrations em dia')).catch(e => { console.error(e.message); process.exit(1); });
}
