import pg from 'pg';
import { Kysely, PostgresDialect, sql, type Transaction } from 'kysely';
import { config } from '../config.js';
import type { DB } from './types.js';

// datas (date) chegam como texto 'AAAA-MM-DD', sem conversão de fuso
pg.types.setTypeParser(1082, v => v);
// numeric chega como texto para não perder precisão de dinheiro
pg.types.setTypeParser(1700, v => v);

function make(url: string, max: number) {
  const pool = new pg.Pool({
    connectionString: url, max, idleTimeoutMillis: 30_000, statement_timeout: 15_000,
    ssl: config.DB_SSL === 'require' ? { rejectUnauthorized: true } : undefined,
  });
  return new Kysely<DB>({ dialect: new PostgresDialect({ pool }) });
}

export const authDb = make(config.DATABASE_URL_AUTH, 5);
export const runtimeDb = make(config.DATABASE_URL_RUNTIME, 10);
export const workerDb = make(config.DATABASE_URL_WORKER, 3);

export type Tx = Transaction<DB>;

// Toda leitura/escrita de dados de negócio passa por aqui: o banco aplica as regras de acesso
// (RLS) para o usuário informado, dentro de uma transação.
export async function withUser<T>(userId: string, fn: (trx: Tx) => Promise<T>): Promise<T> {
  return runtimeDb.transaction().execute(async trx => {
    await sql`select set_config('app.user_id', ${userId}, true)`.execute(trx);
    return fn(trx);
  });
}

export async function closeAll() {
  await Promise.all([authDb.destroy(), runtimeDb.destroy(), workerDb.destroy()]);
}
