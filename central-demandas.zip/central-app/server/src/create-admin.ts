// Cria o primeiro convite de administrador. Não existe usuário ou senha padrão.
// Uso: npm run create-admin -- pessoa@empresa.com.br
import { authDb, closeAll } from './db/index.js';
import { config } from './config.js';
import { randomToken, sha256 } from './lib/crypto.js';

const email = (process.argv[2] ?? '').trim().toLowerCase();
if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) { console.error('Informe um e-mail válido.'); process.exit(1); }
const token = randomToken(32);
await authDb.insertInto('app.invites').values({ token_hash: sha256(token), email, global_role: 'admin', expires_at: new Date(Date.now() + 24 * 3600_000) }).execute();
await authDb.insertInto('app.audit_log').values({ action: 'admin.convite_inicial', meta: JSON.stringify({ email }) }).execute();
console.log(`Convite de administrador (vale 24 horas, uso único):\n${config.APP_URL}/convite#${token}`);
await closeAll();
