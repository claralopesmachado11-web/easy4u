import type { FastifyReply, FastifyRequest } from 'fastify';
import { sql } from 'kysely';
import { authDb } from '../db/index.js';
import { config, isProd } from '../config.js';
import { randomToken, sha256 } from '../lib/crypto.js';

// __Host- obriga Secure, Path=/ e nenhum Domain: o cookie não vaza para subdomínios.
export const COOKIE = isProd ? '__Host-sid' : 'sid';
const IDLE_MINUTES = 120;

export interface AuthInfo {
  userId: string; email: string; name: string; role: 'admin' | 'user'; mfaEnabled: boolean;
  sessionId: string; csrf: string; mfaPending: boolean;
}

export async function createSession(reply: FastifyReply, req: FastifyRequest, userId: string, mfaPending: boolean) {
  const token = randomToken(32), csrf = randomToken(24);
  const expires = new Date(Date.now() + config.SESSION_HOURS * 3600_000);
  await authDb.insertInto('app.sessions').values({
    id: sha256(token), user_id: userId, csrf_token: csrf, mfa_pending: mfaPending,
    ip: req.ip ?? null, user_agent: String(req.headers['user-agent'] ?? '').slice(0, 300), expires_at: expires,
  }).execute();
  reply.setCookie(COOKIE, token, { httpOnly: true, secure: isProd, sameSite: 'strict', path: '/', expires });
  return csrf;
}

export async function loadSession(req: FastifyRequest): Promise<AuthInfo | null> {
  const token = req.cookies[COOKIE];
  if (!token || token.length > 100) return null;
  const id = sha256(token);
  const row = await authDb.selectFrom('app.sessions as s').innerJoin('app.users as u', 'u.id', 's.user_id')
    .select(['s.id', 's.csrf_token', 's.mfa_pending', 's.last_seen_at', 'u.id as user_id', 'u.email', 'u.name', 'u.role', 'u.mfa_enabled'])
    .where('s.id', '=', id).where('s.expires_at', '>', new Date()).where('u.is_active', '=', true)
    .where('s.last_seen_at', '>', new Date(Date.now() - IDLE_MINUTES * 60_000))
    .executeTakeFirst();
  if (!row) return null;
  // atualiza "visto por último" no máximo a cada 5 minutos
  if (Date.now() - new Date(row.last_seen_at).getTime() > 5 * 60_000) {
    await authDb.updateTable('app.sessions').set({ last_seen_at: sql`now()` as unknown as Date }).where('id', '=', id).execute();
  }
  return { userId: row.user_id, email: row.email, name: row.name, role: row.role, mfaEnabled: row.mfa_enabled, sessionId: row.id, csrf: row.csrf_token, mfaPending: row.mfa_pending };
}

export async function destroySession(reply: FastifyReply, sessionId?: string) {
  if (sessionId) await authDb.deleteFrom('app.sessions').where('id', '=', sessionId).execute();
  reply.clearCookie(COOKIE, { path: '/', httpOnly: true, secure: isProd, sameSite: 'strict' });
}
export const revokeAllSessions = (userId: string, exceptId?: string) => {
  let q = authDb.deleteFrom('app.sessions').where('user_id', '=', userId);
  if (exceptId) q = q.where('id', '!=', exceptId);
  return q.execute();
};
