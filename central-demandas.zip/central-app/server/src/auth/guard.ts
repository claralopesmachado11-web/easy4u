import type { FastifyInstance, FastifyReply, FastifyRequest } from 'fastify';
import { config } from '../config.js';
import { loadSession, type AuthInfo } from './session.js';
import { safeEqual } from '../lib/crypto.js';

declare module 'fastify' { interface FastifyRequest { auth: AuthInfo | null } }

export class HttpError extends Error { constructor(public status: number, message: string, public code?: string) { super(message); } }

const appOrigin = new URL(config.APP_URL).origin;
const SAFE = new Set(['GET', 'HEAD', 'OPTIONS']);

export function registerGuard(app: FastifyInstance) {
  app.decorateRequest('auth', null);
  app.addHook('onRequest', async (req) => {
    if (!req.url.startsWith('/api/')) return;
    // 1) Origem: pedidos que mudam algo só valem se vierem do próprio site (defesa contra CSRF).
    if (!SAFE.has(req.method)) {
      const origin = req.headers.origin ?? (req.headers.referer ? new URL(req.headers.referer).origin : undefined);
      if (origin !== appOrigin) throw new HttpError(403, 'Origem não permitida.');
    }
    req.auth = await loadSession(req);
    // 2) Token CSRF por sessão, enviado no cabeçalho X-CSRF-Token em toda alteração autenticada.
    if (req.auth && !SAFE.has(req.method)) {
      const h = req.headers['x-csrf-token'];
      if (typeof h !== 'string' || !safeEqual(h, req.auth.csrf)) throw new HttpError(403, 'Token de segurança inválido. Recarregue a página.');
    }
  });
}

export async function requireAuth(req: FastifyRequest, _r: FastifyReply) {
  if (!req.auth) throw new HttpError(401, 'Faça login para continuar.');
  if (req.auth.mfaPending) throw new HttpError(401, 'Confirme o código de verificação.', 'mfa_required');
}
export async function requireAdmin(req: FastifyRequest, r: FastifyReply) {
  await requireAuth(req, r);
  if (req.auth!.role !== 'admin') throw new HttpError(403, 'Acesso restrito a administradores.');
  if (!req.auth!.mfaEnabled) throw new HttpError(403, 'Ative a verificação em duas etapas para usar a administração.', 'mfa_setup_required');
}
