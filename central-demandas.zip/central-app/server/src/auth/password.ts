import argon2 from 'argon2';

// Parâmetros mínimos recomendados pela OWASP para Argon2id (19 MiB, 2 iterações).
const OPTS = { type: argon2.argon2id, memoryCost: 19456, timeCost: 2, parallelism: 1 } as const;
export const hashPassword = (p: string) => argon2.hash(p, OPTS);
export async function verifyPassword(hash: string, p: string) {
  try { return await argon2.verify(hash, p); } catch { return false; }
}
// Hash fixo usado quando o e-mail não existe, para o tempo de resposta não revelar se a conta existe.
let dummy: string | null = null;
export async function burnTime(p: string) { dummy ??= await hashPassword('nao-existe-' + Math.random()); await verifyPassword(dummy, p); }

const COMMON = new Set(['123456789012', 'senha1234567', 'password1234', 'qwertyuiop12', '12345678910', 'senhasenha12', 'aaaaaaaaaaaa']);
// Política: 12 a 128 caracteres, sem senhas óbvias, sem conter o próprio e-mail.
export function passwordProblem(p: string, email?: string): string | null {
  if (p.length < 12) return 'A senha precisa ter pelo menos 12 caracteres.';
  if (p.length > 128) return 'A senha pode ter no máximo 128 caracteres.';
  if (COMMON.has(p.toLowerCase()) || /^(.)\1+$/.test(p)) return 'Essa senha é fácil demais de adivinhar.';
  const local = email?.split('@')[0]?.toLowerCase();
  if (local && local.length >= 4 && p.toLowerCase().includes(local)) return 'A senha não pode conter o seu e-mail.';
  if (new Set(p).size < 6) return 'Use mais variedade de caracteres.';
  return null;
}
