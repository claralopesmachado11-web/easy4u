import { buildApp } from './app.js';
import { config } from './config.js';
import { startScheduler, stopScheduler } from './services/scheduler.js';
import { closeAll } from './db/index.js';

const app = await buildApp();
await app.listen({ port: config.PORT, host: '0.0.0.0' });
startScheduler(app.log);
for (const sig of ['SIGTERM', 'SIGINT'] as const) {
  process.on(sig, async () => { app.log.info('encerrando'); stopScheduler(); await app.close(); await closeAll(); process.exit(0); });
}
