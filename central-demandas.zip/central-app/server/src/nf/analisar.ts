import { createHash } from 'node:crypto';
import { createRequire } from 'node:module';
import { pathToFileURL } from 'node:url';
import { DOMParser } from '@xmldom/xmldom';
import { parseText, parseXML, pdfText, looksLikeNF, xmlIsNF, toRow, nfFromFileName, onlyDigits, brToISO, type Extracted, type Supplier } from './parse.js';

// Identifica se um anexo (PDF ou XML) é uma nota fiscal e extrai os dados dela.
// Roda no servidor, sobre arquivos vindos de e-mails: tudo é tratado como não confiável.

export const MAX_ANEXO = 15 * 1024 * 1024;
export type Tipo = 'pdf' | 'xml';

// O tipo é decidido pelo conteúdo do arquivo, não pelo nome nem pelo que o remetente declarou.
export function sniff(buf: Buffer): Tipo | null {
  if (buf.subarray(0, 5).toString('latin1') === '%PDF-') return 'pdf';
  const head = buf.subarray(0, 512).toString('utf8').replace(/^﻿/, '').trimStart();
  return head.startsWith('<') ? 'xml' : null;
}
export const sha256hex = (b: Buffer) => createHash('sha256').update(b).digest('hex');

let lib: any = null;
async function pdfjs() {
  if (!lib) {
    lib = await import('pdfjs-dist/legacy/build/pdf.mjs');
    lib.GlobalWorkerOptions.workerSrc = pathToFileURL(createRequire(import.meta.url).resolve('pdfjs-dist/legacy/build/pdf.worker.mjs')).href;
  }
  return lib;
}

const withTimeout = <T>(p: Promise<T>, ms: number) => Promise.race([p, new Promise<never>((_, rej) => setTimeout(() => rej(new Error('tempo esgotado ao ler o PDF')), ms))]);

// Abre o PDF sem executar nada dele (sem eval, sem fontes do sistema). Lança erro se não for um PDF válido.
export async function abrirPDF(buf: Buffer) {
  const L = await pdfjs();
  const task = L.getDocument({ data: new Uint8Array(buf), isEvalSupported: false, disableFontFace: true, useSystemFonts: false, verbosity: 0 });
  try { return await withTimeout(task.promise, 20_000) as any; }
  catch (e) { task.destroy?.(); throw e; }
}

export interface Analise { nf: boolean; tipo: Tipo; dados?: Extracted; semTexto?: boolean; erro?: string }

const PISTA = /(nota[\s_-]*fiscal|\bnf-?e\b|\bnfs-?e\b|danfe|\bnf[\s_-]*\d)/i;

// contexto = assunto + início do e-mail; ajuda a decidir quando o PDF é uma imagem sem texto
export async function analisar(buf: Buffer, nome: string, contexto = ''): Promise<Analise | null> {
  const tipo = sniff(buf);
  if (!tipo) return null;
  const pista = PISTA.test(nome) || PISTA.test(contexto);
  if (tipo === 'xml') {
    const text = buf.toString('utf8');
    if (!xmlIsNF(text)) return { nf: false, tipo };
    try { return { nf: true, tipo, dados: parseXML(text, DOMParser as never) }; }
    catch (e) { return { nf: true, tipo, erro: (e as Error).message }; }
  }
  let pdf: any;
  try { pdf = await abrirPDF(buf); }
  catch (e) {
    const msg = (e as Error).name === 'PasswordException' ? 'PDF protegido por senha' : 'PDF que não consegui abrir';
    return pista ? { nf: true, tipo, semTexto: true, erro: msg } : { nf: false, tipo };
  }
  try {
    const text = await withTimeout(pdfText(pdf), 20_000);
    if (text.replace(/\s/g, '').length < 80) return pista ? { nf: true, tipo, semTexto: true } : { nf: false, tipo }; // escaneado
    if (!looksLikeNF(text)) return { nf: false, tipo };
    const dados = parseText(text);
    try { const md = await pdf.getMetadata(); dados.title = md?.info?.Title || ''; } catch { /* sem metadados */ }
    return { nf: true, tipo, dados };
  } finally { await pdf.destroy?.(); }
}

const cut = (v: unknown, n: number) => { const s = String(v ?? '').trim(); return s ? s.slice(0, n) : null; };
const valorNum = (v: string) => { if (!v) return null; const n = Number(v.replace(/\./g, '').replace(',', '.')); return Number.isFinite(n) && n >= 0 && n < 1e12 ? n.toFixed(2) : null; };

// Converte o que foi lido na linha da tabela de notas, com os mesmos cálculos do Leitor de NF.
export function paraNota(nome: string, a: Analise, sup: Supplier[], prefs = { venc: 30, dias: 7 }) {
  const avisos: string[] = [];
  let r: ReturnType<typeof toRow> = {};
  if (a.dados) r = toRow(nome, a.dados, sup, prefs);
  avisos.push(...(r.warn ?? []));
  if (a.semTexto) avisos.push('PDF sem texto (escaneado ou protegido): preencha os dados olhando o documento.');
  if (a.erro && !a.semTexto) avisos.push(`Não consegui ler tudo: ${a.erro}`);
  const numero = cut(r.nf || nfFromFileName(nome), 40);
  if (!numero) avisos.push('Número da nota não encontrado.');
  const conferir = avisos.length > 0 || !a.dados || !numero;
  if (a.dados) avisos.push(`Datas calculadas com vencimento ${prefs.venc} dias após a emissão e envio ${prefs.dias} dias antes.`);
  const cnpj = onlyDigits(r.cnpj ?? '');
  return {
    mes: cut(r.mes, 20), qz: cut(r.qz, 10), base: cut(r.base, 40), codigo: cut(r.codigo, 40), fornecedor: cut(r.fornecedor, 200),
    cnpj: cnpj.length === 14 ? cnpj : null, rc: cut(r.rc, 40), po: cut(r.po, 40), numero_nf: numero,
    valor: valorNum(r.valor ?? ''), emissao: r.emissao ? brToISO(r.emissao) : null, vencimento: r.venc ? brToISO(r.venc) : null,
    envio_central: r.envio ? brToISO(r.envio) : null,
    avisos: avisos.join(' · ').slice(0, 1000), conferir,
  };
}
