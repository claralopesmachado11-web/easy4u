// Extração de dados de notas fiscais (NF-e, NFS-e, DANFE). Lógica trazida do Leitor de NF original.
export interface Extracted { fornecedor: string; cnpj: string; numero_nf: string; valor_total: number | ''; data_emissao: string; vencimento: string; po: string; rc: string;
  destText: string; fullText: string; title?: string; ocr?: boolean; scanned?: boolean }
export interface Supplier { id?: string; base: string | null; codigo: string; nome: string; cnpj: string | null }
export interface Row { id: string; file: string; status: 'load' | 'ok' | 'err'; msg?: string; warn: string[];
  mes: string; qz: string; base: string; codigo: string; fornecedor: string; cnpj: string; rc: string; po: string; migo: string; nf: string; valor: string; emissao: string; venc: string; envio: string }

export const pad = (n: number | string) => String(n).padStart(2, '0');
export const onlyDigits = (s: unknown) => String(s ?? '').replace(/\D/g, '');
export const NORM = (s: unknown) => String(s ?? '').normalize('NFD').replace(/[̀-ͯ]/g, '').toUpperCase();
const KEY = (s: unknown) => NORM(s).replace(/[^A-Z0-9]/g, '');
const U = (s: unknown) => String(s ?? '').trim().toUpperCase();

export function toBR(s: unknown) {
  if (!s) return ''; const t = String(s).trim();
  let m = t.match(/^(\d{4})-(\d{2})-(\d{2})/); if (m) return `${m[3]}/${m[2]}/${m[1]}`;
  m = t.match(/^(\d{1,2})[/.-](\d{1,2})[/.-](\d{2,4})$/); if (m) { const y = m[3].length === 2 ? '20' + m[3] : m[3]; return `${pad(m[1])}/${pad(m[2])}/${y}`; }
  return t;
}
export const parseBR = (s: string) => { const m = String(s || '').match(/^(\d{2})\/(\d{2})\/(\d{4})$/); return m ? new Date(+m[3], +m[2] - 1, +m[1]) : null; };
export const brToISO = (s: string) => { const d = parseBR(s); return d && d.getDate() === Number(s.slice(0, 2)) ? `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}` : null; };
const fmt = (d: Date) => `${pad(d.getDate())}/${pad(d.getMonth() + 1)}/${d.getFullYear()}`;
export const addDays = (br: string, n: number) => { const d = parseBR(br); if (!d) return ''; d.setDate(d.getDate() + n); return fmt(d); };
export function money(v: unknown) {
  if (v == null || v === '') return '';
  const n = typeof v === 'number' ? v : Number(String(v).replace(/[^\d,.-]/g, '').replace(/\.(?=\d{3}(\D|$))/g, '').replace(',', '.'));
  return Number.isNaN(n) ? String(v) : n.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}
const num = (s: string) => Number(String(s).replace(/\./g, '').replace(',', '.'));

export function nfFromLabel(s: string) {
  const m = String(s || '').match(/(?:^|[^A-Za-z])NF(?:S?\s?-?\s?e)?(?![A-Za-z])\s*(?:N[º°o]\.?|N[uú]m(?:ero|\.)?)?\s*[:.#\-–_]?\s*(\d{1,3}(?:\.\d{3}){1,3}|\d{1,9})(?![\d/])/i);
  return m ? String(+onlyDigits(m[1])) : '';
}
export function nfFromFileName(name: string) {
  const b = String(name || '').replace(/\.[a-z0-9]+$/i, '');
  return nfFromLabel(b.replace(/_/g, ' ')) || (/^\s*\d{3,9}\s*$/.test(b) ? String(+b) : '');
}
const stripKey = (t: string) => String(t || '').replace(/(?:\d{4} ?){10}\d{4}/g, ' ');
export function findPO(t: string) {
  const T = stripKey(t);
  let m = T.match(/(?<![A-Za-zÀ-ú])P\s?\.?\s?O\s?\.?\s*(?:N[º°o]\.?\s*)?[:#\-–]?\s*(\d[\d.]{2,16}\d)/i); if (m) return onlyDigits(m[1]);
  const C = T.replace(/[ \t ]+/g, '');
  m = C.match(/(?<![A-Za-zÀ-ú])P\.?O\.?(?:N[º°o]\.?)?[:#\-–]\n?(\d[\d.]{2,16}\d)/i) || C.match(/(?<!TI)P\.?O\.?[:#](\d[\d.]{2,16}\d)/i); if (m) return onlyDigits(m[1]);
  m = T.match(/(?<!\d)45\d{8}(?!\d)/); if (m) return m[0];
  m = T.match(/(?<!\d)4\s?5(?:[\s.]?\d){8}(?!\d)/); if (m) return onlyDigits(m[0]);
  m = T.match(/(?:PEDIDO(?:\s+DE\s+COMPRAS?)?|N[º°o.]?\s*PED(?:IDO)?|(?<![A-Z])P\.?\s?O(?![A-Z])|ORDEM\s+DE\s+COMPRA|(?<![A-Z])OC(?![A-Z])|xPed)[^\d]{0,25}((?:\d[.\-/]?){6,12})/i);
  return m ? onlyDigits(m[1]) : '';
}
export function findRC(t: string) {
  const m = stripKey(t).match(/(?:(?<![A-Z])RC(?![A-Z])|REQUISI[CÇ][AÃ]O(?:\s+DE\s+COMPRAS?)?|(?<![A-Z])REQ(?![A-Z]))[^\d\n]{0,15}(\d{6,12})/i);
  return m ? m[1] : '';
}
// quinzena de referência = os 15 dias anteriores à emissão
export function refPeriod(emissao: string) {
  const d = parseBR(emissao); if (!d) return { mes: '', qz: '' };
  if (d.getDate() >= 16) return { mes: String(d.getMonth() + 1), qz: '1' };
  const p = new Date(d.getFullYear(), d.getMonth() - 1, 1); return { mes: String(p.getMonth() + 1), qz: '2' };
}
const AIRPORTS: Record<string, string> = { 'SANTOS DUMONT': 'SDU', GALEAO: 'GIG', 'TOM JOBIM': 'GIG', CONGONHAS: 'CGH', GUARULHOS: 'GRU', CUMBICA: 'GRU', VIRACOPOS: 'VCP', CONFINS: 'CNF', 'TANCREDO NEVES': 'CNF', PAMPULHA: 'PLU', 'JUSCELINO KUBITSCHEK': 'BSB', 'PORTO ALEGRE': 'POA', 'AFONSO PENA': 'CWB', 'SAO JOSE DOS PINHAIS': 'CWB', 'HERCILIO LUZ': 'FLN', GUARARAPES: 'REC', 'GILBERTO FREYRE': 'REC', 'LUIS EDUARDO MAGALHAES': 'SSA', 'DOIS DE JULHO': 'SSA', 'PINTO MARTINS': 'FOR', 'VAL DE CANS': 'BEL', 'MARECHAL RONDON': 'CGB', 'SANTA GENOVEVA': 'GYN', 'EURICO DE AGUIAR SALLES': 'VIX', 'ALUIZIO ALVES': 'NAT', 'ZUMBI DOS PALMARES': 'MCZ', 'CUNHA MACHADO': 'SLZ', 'PETRONIO PORTELLA': 'THE', 'CASTRO PINTO': 'JPA', 'VICTOR KONDER': 'NVT', CATARATAS: 'IGU', 'PORTO VELHO': 'PVH', 'JORGE TEIXEIRA': 'PVH', 'PORTO SEGURO': 'BPS', FORTALEZA: 'FOR', CUIABA: 'CGB', 'VARZEA GRANDE': 'CGB', GOIANIA: 'GYN', 'SAO LUIS': 'SLZ', MANAUS: 'MAO', MACEIO: 'MCZ', ARACAJU: 'AJU', BELEM: 'BEL', FLORIANOPOLIS: 'FLN', VITORIA: 'VIX', SALVADOR: 'SSA', NATAL: 'NAT', 'SAO GONCALO DO AMARANTE': 'NAT', 'JOAO PESSOA': 'JPA', BAYEUX: 'JPA', RECIFE: 'REC', BRASILIA: 'BSB' };
const SAFE_CODES = ['SDU', 'GIG', 'CGH', 'GRU', 'VCP', 'CNF', 'PLU', 'BSB', 'POA', 'CWB', 'FLN', 'SSA', 'MAO', 'CGB', 'GYN', 'VIX', 'MCZ', 'SLZ', 'JPA', 'AJU', 'NVT', 'IGU', 'PVH', 'BPS'];
const ALL_CODES = [...new Set([...SAFE_CODES, ...Object.values(AIRPORTS)])];
export function baseFromText(section: string, full: string) {
  const F = NORM(full), S = NORM(section);
  const m = F.match(/\bBASE\s*[:-]?\s*([A-Z]{3})\b/); if (m && ALL_CODES.includes(m[1])) return m[1];
  for (const k in AIRPORTS) if (S.includes(k)) return AIRPORTS[k];
  for (const c of SAFE_CODES) if (new RegExp('\\b' + c + '\\b').test(S)) return c;
  for (const a of F.match(/AEROPORTO[^\n]{0,70}/g) || []) for (const k in AIRPORTS) if (a.includes(k)) return AIRPORTS[k];
  return '';
}
export function baseFromName(name: string, sup: Supplier[]) {
  const b = ' ' + NORM(String(name || '').replace(/\.[a-z0-9]+$/i, '')).replace(/[_\-.]+/g, ' ') + ' ';
  const full = [...sup].filter(x => x.base).sort((x, y) => y.base!.length - x.base!.length).find(x => b.includes(' ' + NORM(x.base) + ' ')); if (full) return full.base!;
  return ALL_CODES.find(c => b.includes(' ' + c + ' ')) || '';
}
export function sameName(a: string, b: string) {
  const x = KEY(a), y = KEY(b); if (!x || !y) return false;
  if (x.startsWith(y) || y.startsWith(x)) return Math.min(x.length, y.length) >= 8;
  return x.length >= 18 && y.length >= 18 && x.slice(0, 18) === y.slice(0, 18);
}

export function parseText(raw: string): Extracted {
  const T = raw.replace(/[ \t ]+/g, ' ');
  const out: Extracted = { fornecedor: '', cnpj: '', numero_nf: '', valor_total: '', data_emissao: '', vencimento: '', po: '', rc: '', destText: '', fullText: T };
  let key = '', keyNF = '';
  for (const c of T.match(/(?:\d{4}\s?){10}\d{4}|\d{44}/g) || []) { const k = onlyDigits(c); if (k.length === 44 && /^(55|65)$/.test(k.slice(20, 22))) { key = k; break; } }
  if (key) { out.cnpj = key.slice(6, 20); keyNF = String(+key.slice(25, 34)); }
  let f = (T.match(/RECEBEMOS DE\s+(.+?)\s+OS\s+(?:PRODUTOS|SERVI)/i) || [])[1];
  if (!f) { const i = T.search(/PRESTADOR/i); const part = i >= 0 ? T.slice(i, i + 800) : T;
    f = (part.match(/(?:Nome\s*\/\s*)?Raz[aã]o\s+Social[^:\n]{0,20}:?\s*\n?\s*([^\n]+?)(?=\s{2,}|\n|\bCNPJ|\bCPF|Inscri|Nome Fantasia|E-?mail|Endere|$)/i) || [])[1]; }
  if (!f) f = (T.match(/IDENTIFICA[CÇ][AÃ]O\s+DO\s+EMITENTE\s*\n?\s*([^\n]+?)(?=\s{2,}|\n|$)/i) || [])[1];
  out.fornecedor = (f || '').trim();
  const di = T.search(/DESTINAT[AÁ]RIO|TOMADOR/i);
  out.destText = di >= 0 ? T.slice(di, di + 700) : '';
  if (!out.cnpj) { const i = T.search(/PRESTADOR|EMITENTE/i); const c = T.slice(Math.max(i, 0)).match(/\d{2}\.?\d{3}\.?\d{3}\/?\d{4}-?\d{2}/); if (c) out.cnpj = onlyDigits(c[0]); }
  const danfe = (T.match(/N[º°o]\.?\s*:?\s*(\d{3}\.\d{3}\.\d{3})(?!\d)/) || [])[1];
  out.numero_nf = keyNF || (danfe ? String(+onlyDigits(danfe)) : '') || nfFromLabel(T);
  if (!out.numero_nf) { const n = after(T, /N[uú]mero\s+da\s+(?:NFS-?e|Nota(?:\s+Fiscal)?)|NFS-?e\s*N[º°o.]?|N[º°]\s*(?:da\s+nota)?/, /:?\s*([\d.]{1,15})/, 30); out.numero_nf = n ? String(+onlyDigits(n)) : ''; }
  const MONEY = /(\d{1,3}(?:\.\d{3})*,\d{2})/, DATE = /(\d{2}\/\d{2}\/\d{4})/;
  let v = after(T, /VALOR\s+TOTAL\s+DA\s+NOTA/, MONEY, 120) || after(T, /VALOR\s+(?:TOTAL\s+)?(?:L[IÍ]QUIDO(?:\s+DA\s+(?:NFS-?e|NOTA))?|DO\s+SERVI[CÇ]O|DOS\s+SERVI[CÇ]OS|DA\s+NFS-?e)/, MONEY, 120);
  if (!v) v = [...T.matchAll(/\d{1,3}(?:\.\d{3})*,\d{2}/g)].map(x => x[0]).sort((a, b) => num(b) - num(a))[0] || '';
  out.valor_total = v ? num(v) : '';
  out.data_emissao = after(T, /DATA\s+(?:DA\s+|DE\s+)?EMISS[AÃ]O|Data\s+e\s+Hora\s+(?:da\s+)?Emiss[aã]o|EMITIDA\s+EM|DT\.?\s*EMISS[AÃ]O/, DATE, 120) || ((T.match(DATE) || [])[1] || '');
  out.vencimento = after(T, /VENC(?:IMENTO|TO|\.)?/, DATE, 80) || (() => { const i = T.search(/FATURA|DUPLICATA/i); if (i < 0) return '';
    return [...T.slice(i, i + 400).matchAll(/\d{2}\/\d{2}\/\d{4}/g)].map(x => x[0]).filter(d => d !== out.data_emissao)[0] || ''; })();
  out.po = findPO(T); out.rc = findRC(T);
  return out;
}
function after(T: string, label: RegExp, val: RegExp, win = 250) {
  const re = new RegExp(label.source, 'gi'); let m: RegExpExecArray | null;
  while ((m = re.exec(T))) { const v = T.slice(m.index + m[0].length, m.index + m[0].length + win).match(val); if (v) return v[1]; }
  return '';
}

// Funciona no navegador (DOMParser nativo) e no servidor (@xmldom/xmldom), por isso os tipos são mínimos.
type XNode = { textContent: string | null; getElementsByTagNameNS(ns: string, n: string): { length: number; item(i: number): XNode | null } };
type XDoc = XNode & { documentElement: XNode | null; getElementsByTagName(n: string): { length: number } };
export type XmlParser = new () => { parseFromString(t: string, type: string): unknown };

export function parseXML(text: string, Parser: XmlParser = (globalThis as any).DOMParser): Extracted {
  let doc: XDoc;
  try { doc = new Parser().parseFromString(text, 'application/xml') as XDoc; } catch { throw new Error('XML inválido.'); }
  if (!doc?.documentElement || doc.getElementsByTagName('parsererror').length) throw new Error('XML inválido.');
  const all = (name: string, root: XNode = doc) => { const l = root.getElementsByTagNameNS('*', name); return Array.from({ length: l.length }, (_, i) => l.item(i)!); };
  const g = (names: string[], root: XNode = doc) => { for (const n of names) { const v = all(n, root)[0]?.textContent?.trim(); if (v) return v; } return ''; };
  const firstOf = (names: string[]) => { for (const n of names) { const e = all(n)[0]; if (e) return e; } return null; };
  const emit = firstOf(['emit', 'PrestadorServico', 'Prestador', 'prest']);
  const dest = firstOf(['dest', 'TomadorServico', 'Tomador', 'toma']);
  const nNF = g(['nNF', 'nNFSe', 'Numero', 'NumeroNfse']);
  if (!nNF) throw new Error('Não achei o número da nota nesse XML.');
  const inf = g(['infCpl']) + ' ' + g(['infAdFisco']) + ' ' + g(['Discriminacao', 'xDescServ', 'OutrasInformacoes', 'xInfComp']);
  const xPed = g(['xPed']);
  const fullText = doc.documentElement!.textContent ?? '';
  return { fornecedor: emit ? g(['xNome', 'RazaoSocial'], emit) : '', cnpj: emit ? g(['CNPJ', 'Cnpj'], emit) : '', numero_nf: nNF,
    valor_total: Number(g(['vNF', 'vLiq', 'ValorLiquidoNfse', 'ValorServicos', 'vServ'])), data_emissao: g(['dhEmi', 'dEmi', 'DataEmissao', 'dCompet', 'Competencia']).slice(0, 10),
    vencimento: all('dVenc').map(n => n.textContent!.trim()).sort()[0] || '', po: findPO(xPed) || onlyDigits(xPed) || findPO(inf) || findPO(fullText), rc: findRC(inf) || findRC(fullText),
    destText: dest?.textContent ?? '', fullText };
}

// Monta a linha da planilha a partir do que foi lido + cadastro de fornecedores da equipe.
export function toRow(file: string, d: Extracted, sup: Supplier[], prefs: { venc: number; dias: number }): Partial<Row> {
  const warn: string[] = [];
  const cnpj = onlyDigits(d.cnpj);
  const lido = (d.fornecedor || '').toUpperCase().replace(/\s+/g, ' ').trim();
  const detected = baseFromName(file, sup) || baseFromText(d.destText, d.fullText);
  let pick = cnpj ? sup.filter(s => s.cnpj && s.cnpj === cnpj) : [];
  if (!pick.length) pick = sup.filter(s => s.nome && sameName(s.nome, lido));
  if (pick.length > 1 && detected) { const f = pick.filter(e => U(e.base).slice(0, 3) === detected.slice(0, 3)); if (f.length) pick = f; }
  let base = detected, codigo = '', fornecedor = lido;
  if (pick.length) {
    const e = pick[0]; base = e.base || detected; codigo = e.codigo; fornecedor = e.nome;
    if (pick.length > 1) warn.push(`Base: escolhi ${e.base} entre ${pick.map(x => x.base).join(', ')}. Confira.`);
  } else if (lido) warn.push('Fornecedor fora do cadastro: confira código e base.');
  if (!base) warn.push('Base não identificada.');
  const nfDoc = onlyDigits(d.numero_nf).replace(/^0+(?=\d)/, '');
  const nfName = nfFromFileName(file) || nfFromLabel(d.title || '');
  if (nfName && nfDoc && nfName !== nfDoc) warn.push(`Nº NF: arquivo diz ${nfName}, nota diz ${nfDoc}.`);
  const emissao = toBR(d.data_emissao);
  const venc = addDays(emissao, prefs.venc) || toBR(d.vencimento);
  const per = refPeriod(emissao);
  if (d.scanned) warn.push('Nota escaneada com pouco texto: confira tudo.');
  else if (d.ocr) warn.push('Lida de imagem: confira os números.');
  return { mes: per.mes, qz: per.qz, base, codigo, fornecedor, cnpj, rc: onlyDigits(d.rc), po: onlyDigits(d.po), migo: '', nf: nfName || nfDoc,
    valor: money(d.valor_total), emissao, venc, envio: addDays(venc, -prefs.dias), warn, status: 'ok' };
}

// ---------- usado também pela leitura de anexos de e-mail ----------

// Monta o texto de um PDF já aberto pelo pdf.js, mantendo as quebras de linha da página.
export async function pdfText(pdf: { numPages: number; getPage(n: number): Promise<any> }, maxPages = 6) {
  let text = '';
  for (let p = 1; p <= Math.min(pdf.numPages, maxPages); p++) {
    const page = await pdf.getPage(p);
    const c = await page.getTextContent();
    let prev: { y: number; end: number } | null = null;
    for (const i of c.items as any[]) {
      if (!('str' in i)) continue;
      const x = i.transform[4], y = i.transform[5], h = Math.abs(i.transform[3]) || 10;
      if (prev) { if (Math.abs(y - prev.y) > h * 0.5) text += '\n'; else text += x - prev.end > h * 0.1 ? ' ' : ''; }
      text += i.str; prev = { y, end: x + (i.width || 0) };
      if (i.hasEOL) { text += '\n'; prev = null; }
    }
    text += '\n';
  }
  return text;
}

// O texto parece de uma nota fiscal? (DANFE, NFS-e, chave de acesso de 44 dígitos)
export function looksLikeNF(text: string) {
  const t = NORM(text);
  return /\bDANFE\b|DOCUMENTO AUXILIAR DA NOTA FISCAL|NOTA FISCAL (ELETRONICA|DE SERVICOS?|FATURA)|\bNFS-?E\b|NOTA FISCAL DE SERVICO/.test(t)
    || /(?:\d{4} ?){10}\d{4}/.test(text) && /CHAVE DE ACESSO/.test(t);
}
// O XML é de nota fiscal (NF-e ou NFS-e)?
export function xmlIsNF(text: string) {
  return /<(?:\w+:)?(nfeProc|NFe|infNFe|CompNfse|Nfse|NFSe|infNFSe|ConsultarNfseResposta)\b/.test(text.slice(0, 4000));
}
