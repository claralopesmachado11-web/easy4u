import { z } from 'zod';

// Toda configuração vem de variáveis de ambiente (em produção: Azure Key Vault referenciado pelo App Service).
// Nada sensível fica no código. O servidor não sobe se algo obrigatório faltar.
const schema = z.object({
  NODE_ENV: z.enum(['development', 'test', 'production']).default('development'),
  PORT: z.coerce.number().int().default(3000),
  APP_URL: z.string().url(),
  DATABASE_URL_AUTH: z.string().min(1),
  DATABASE_URL_RUNTIME: z.string().min(1),
  DATABASE_URL_WORKER: z.string().min(1),
  DATABASE_URL_OWNER: z.string().optional(), // só para rodar migrations
  DB_SSL: z.enum(['require', 'off']).default('off'),
  // chave de 32 bytes em base64 para cifrar segredos de MFA
  ENCRYPTION_KEY: z.string().refine(v => Buffer.from(v, 'base64').length === 32, 'ENCRYPTION_KEY precisa ter 32 bytes em base64'),
  SESSION_HOURS: z.coerce.number().int().min(1).max(72).default(10),
  TRUST_PROXY: z.enum(['true', 'false']).default('false'),
  // e-mail
  SMTP_HOST: z.string().optional(),
  SMTP_PORT: z.coerce.number().int().default(587),
  SMTP_USER: z.string().optional(),
  SMTP_PASS: z.string().optional(),
  MAIL_FROM: z.string().optional(),
  // Microsoft Graph (registro do app no Microsoft 365, autorizado pelo administrador do tenant)
  GRAPH_TENANT_ID: z.string().optional(),
  GRAPH_CLIENT_ID: z.string().optional(),
  GRAPH_CLIENT_SECRET: z.string().optional(),
  GRAPH_BASE_URL: z.string().url().default('https://graph.microsoft.com/v1.0'),
  GRAPH_LOGIN_URL: z.string().url().default('https://login.microsoftonline.com'),
  SYNC_INTERVAL_MINUTES: z.coerce.number().int().min(1).max(120).default(5),
  // classificador com IA (opcional): Azure OpenAI
  AZURE_OPENAI_ENDPOINT: z.string().url().optional(),
  AZURE_OPENAI_DEPLOYMENT: z.string().optional(),
  AZURE_OPENAI_KEY: z.string().optional(),
  AZURE_OPENAI_API_VERSION: z.string().default('2024-10-21'),
});

const parsed = schema.safeParse(process.env);
if (!parsed.success) {
  // mostra só os nomes das variáveis com problema, nunca os valores
  console.error('Configuração inválida:', parsed.error.issues.map(i => i.path.join('.') + ': ' + i.message).join('; '));
  process.exit(1);
}
export const config = parsed.data;
export const isProd = config.NODE_ENV === 'production';

if (isProd) {
  const missing = ['SMTP_HOST', 'MAIL_FROM'].filter(k => !(config as Record<string, unknown>)[k]);
  if (missing.length) { console.error('Produção exige: ' + missing.join(', ')); process.exit(1); }
  if (!config.APP_URL.startsWith('https://')) { console.error('Produção exige APP_URL com https://'); process.exit(1); }
  if (config.DB_SSL !== 'require') { console.error('Produção exige DB_SSL=require'); process.exit(1); }
}
export const graphEnabled = !!(config.GRAPH_TENANT_ID && config.GRAPH_CLIENT_ID && config.GRAPH_CLIENT_SECRET);
export const aiEnabled = !!(config.AZURE_OPENAI_ENDPOINT && config.AZURE_OPENAI_DEPLOYMENT && config.AZURE_OPENAI_KEY);
