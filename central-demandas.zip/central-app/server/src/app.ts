import Fastify, { type FastifyError } from 'fastify';
import cookie from '@fastify/cookie';
import helmet from '@fastify/helmet';
import rateLimit from '@fastify/rate-limit';
import fastifyStatic from '@fastify/static';
import { existsSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { ZodError } from 'zod';
import { sql } from 'kysely';
import { config, isProd } from './config.js';
import { registerGuard, HttpError } from './auth/guard.js';
import { authRoutes } from './routes/auth.js';
import { adminRoutes } from './routes/admin.js';
import { demandaRoutes } from './routes/demandas.js';
import { nfRoutes } from './routes/nf.js';
import { authDb } from './db/index.js';

export async function buildApp() {
  const app = Fastify({
    trustProxy: config.TRUST_PROXY === 'true',
    bodyLimit: 1_000_000,
    logger: config.NODE_ENV === 'test' ? false : {
      level: isProd ? 'info' : 'debug',
      // nada sensível vai para os logs
      redact: ['req.headers.cookie', 'req.headers.authorization', 'req.headers["x-csrf-token"]', 'res.headers["set-cookie"]', '*.password', '*.token'],
    },
  });

  await app.register(helmet, {
    contentSecurityPolicy: { directives: {
      defaultSrc: ["'self'"], scriptSrc: ["'self'", "'wasm-unsafe-eval'"], styleSrc: ["'self'"],
      fontSrc: ["'self'"], imgSrc: ["'self'", 'data:', 'blob:'], connectSrc: ["'self'"],
      workerSrc: ["'self'", 'blob:'], upgradeInsecureRequests: isProd ? [] : null, objectSrc: ["'none'"], frameAncestors: ["'none'"], baseUri: ["'self'"], formAction: ["'self'"],
    } },
    hsts: isProd ? { maxAge: 31536000, includeSubDomains: true } : false,
    crossOriginEmbedderPolicy: false,
    referrerPolicy: { policy: 'no-referrer' },
  });
  await app.register(cookie);
  // limite geral por IP; rotas de login têm limite mais apertado
  await app.register(rateLimit, { global: true, max: 300, timeWindow: '1 minute', allowList: [] });
  registerGuard(app);

  app.setErrorHandler((err: FastifyError & { code?: string }, req, reply) => {
    if (err instanceof HttpError) return reply.code(err.status).send({ error: err.message, code: err.code });
    if (err instanceof ZodError) return reply.code(400).send({ error: 'Dados inválidos.', fields: err.issues.map(i => ({ path: i.path.join('.'), message: i.message })) });
    if (err.statusCode === 429) return reply.code(429).send({ error: 'Muitas requisições. Aguarde um pouco.' });
    if (err.statusCode && err.statusCode < 500) return reply.code(err.statusCode).send({ error: 'Requisição inválida.' });
    const pgCode = (err as { code?: string }).code;
    if (pgCode === '42501') return reply.code(403).send({ error: 'Você não tem permissão para isso.' });
    if (pgCode === '23505') return reply.code(409).send({ error: 'Esse registro já existe.' });
    if (pgCode === '23514' || pgCode === '22P02' || pgCode === '22007' || pgCode === '22008') return reply.code(400).send({ error: 'Dados inválidos.' });
    req.log.error({ err }, 'erro inesperado');
    return reply.code(500).send({ error: 'Erro interno. Tente novamente.' }); // nunca mostra detalhes ao usuário
  });

  // saúde: usado pelo monitoramento de disponibilidade
  app.get('/health', { config: { rateLimit: false } }, async (_req, reply) => {
    try { await sql`select 1`.execute(authDb); return { status: 'ok' }; }
    catch { return reply.code(503).send({ status: 'db_unavailable' }); }
  });

  await app.register(authRoutes);
  await app.register(adminRoutes);
  await app.register(demandaRoutes);
  await app.register(nfRoutes);

  // frontend compilado
  const web = join(dirname(fileURLToPath(import.meta.url)), '..', '..', 'web', 'dist');
  if (existsSync(web)) {
    await app.register(fastifyStatic, { root: web, index: 'index.html', maxAge: isProd ? '1h' : 0 });
    app.setNotFoundHandler((req, reply) => {
      if (req.url.startsWith('/api/')) return reply.code(404).send({ error: 'Não encontrado.' });
      return reply.sendFile('index.html');
    });
  }
  return app;
}
