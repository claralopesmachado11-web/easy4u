import { config } from '../config.js';

// Cliente mínimo do Microsoft Graph com credenciais do aplicativo (client credentials).
// A TI deve restringir o app à caixa compartilhada (RBAC for Applications / Application Access Policy).
let cached: { token: string; exp: number } | null = null;

async function token(): Promise<string> {
  if (cached && cached.exp > Date.now() + 60_000) return cached.token;
  const res = await fetch(`${config.GRAPH_LOGIN_URL}/${encodeURIComponent(config.GRAPH_TENANT_ID!)}/oauth2/v2.0/token`, {
    method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({ client_id: config.GRAPH_CLIENT_ID!, client_secret: config.GRAPH_CLIENT_SECRET!, scope: 'https://graph.microsoft.com/.default', grant_type: 'client_credentials' }),
    signal: AbortSignal.timeout(15_000),
  });
  if (!res.ok) throw new Error(`Falha ao autenticar no Microsoft 365 (${res.status})`);
  const j = await res.json() as { access_token: string; expires_in: number };
  cached = { token: j.access_token, exp: Date.now() + j.expires_in * 1000 };
  return j.access_token;
}
export const resetGraphToken = () => { cached = null; };

export interface GraphMessage {
  id: string; subject?: string; receivedDateTime?: string; bodyPreview?: string; importance?: string; webLink?: string;
  conversationId?: string; hasAttachments?: boolean; from?: { emailAddress?: { address?: string; name?: string } }; '@removed'?: unknown;
}

async function request(url: string, attempt = 0): Promise<Response> {
  // só segue links do próprio Graph (o nextLink/deltaLink vem da resposta)
  if (!url.startsWith(config.GRAPH_BASE_URL)) throw new Error('Link do Graph fora do domínio esperado');
  const res = await fetch(url, { headers: { authorization: `Bearer ${await token()}`, prefer: 'odata.maxpagesize=50' }, signal: AbortSignal.timeout(60_000), redirect: 'error' });
  if (res.status === 401 && attempt === 0) { resetGraphToken(); return request(url, 1); }
  if ((res.status === 429 || res.status === 503) && attempt < 2) {
    const wait = Math.min(30, Number(res.headers.get('retry-after') ?? 5)) * 1000;
    await new Promise(r => setTimeout(r, wait));
    return request(url, attempt + 1);
  }
  if (!res.ok) throw new Error(`Microsoft 365 respondeu ${res.status}`);
  return res;
}
async function get(url: string): Promise<Record<string, unknown>> { return (await request(url)).json() as Promise<Record<string, unknown>>; }

// Baixa bytes com limite de tamanho: para de ler se passar do máximo, mesmo que o cabeçalho minta.
async function getBytes(url: string, max: number): Promise<Buffer> {
  const res = await request(url);
  if (Number(res.headers.get('content-length') ?? 0) > max) { await res.body?.cancel(); throw new Error('anexo grande demais'); }
  const chunks: Buffer[] = []; let total = 0;
  for await (const c of res.body as unknown as AsyncIterable<Uint8Array>) {
    total += c.length; if (total > max) throw new Error('anexo grande demais');
    chunks.push(Buffer.from(c));
  }
  return Buffer.concat(chunks);
}

export interface GraphAttachment { id: string; name?: string; contentType?: string; size?: number; isInline?: boolean; '@odata.type'?: string }
const msgUrl = (address: string, messageId: string) => `${config.GRAPH_BASE_URL}/users/${encodeURIComponent(address)}/messages/${encodeURIComponent(messageId)}`;

// Lista os anexos de um e-mail (só metadados; o conteúdo é baixado depois, um a um).
export async function listAttachments(address: string, messageId: string): Promise<GraphAttachment[]> {
  const j = await get(`${msgUrl(address, messageId)}/attachments?$select=id,name,contentType,size,isInline`);
  return ((j.value as GraphAttachment[]) ?? []).slice(0, 30);
}
export function downloadAttachment(address: string, messageId: string, attachmentId: string, max: number) {
  return getBytes(`${msgUrl(address, messageId)}/attachments/${encodeURIComponent(attachmentId)}/$value`, max);
}

// Busca só o que mudou desde a última vez (delta query). Na primeira vez, traz a Caixa de Entrada.
export async function fetchInboxDelta(address: string, deltaLink: string | null, maxPages = 40) {
  const select = 'id,subject,receivedDateTime,bodyPreview,importance,webLink,conversationId,from,hasAttachments';
  let url = deltaLink ?? `${config.GRAPH_BASE_URL}/users/${encodeURIComponent(address)}/mailFolders('inbox')/messages/delta?$select=${select}`;
  const messages: GraphMessage[] = [];
  for (let page = 0; page < maxPages; page++) {
    const j = await get(url);
    messages.push(...((j.value as GraphMessage[]) ?? []).filter(m => !m['@removed']));
    if (typeof j['@odata.nextLink'] === 'string') { url = j['@odata.nextLink']; continue; }
    if (typeof j['@odata.deltaLink'] === 'string') return { messages, deltaLink: j['@odata.deltaLink'] as string, complete: true };
    break;
  }
  return { messages, deltaLink: url, complete: false }; // continua do ponto em que parou na próxima rodada
}
