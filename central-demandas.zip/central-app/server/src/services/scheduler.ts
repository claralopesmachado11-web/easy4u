import type { FastifyBaseLogger } from 'fastify';
import { config, graphEnabled } from '../config.js';
import { syncAll } from './sync.js';
import { authDb } from '../db/index.js';

let timer: NodeJS.Timeout | null = null;
let running = false;

export function startScheduler(log: FastifyBaseLogger) {
  if (!graphEnabled) { log.warn('Microsoft Graph não configurado: leitura automática da caixa desativada.'); }
  const tick = async () => {
    if (running) return;
    running = true;
    try {
      if (graphEnabled) await syncAll(log);
      // limpeza: sessões vencidas, tentativas e links antigos
      await authDb.deleteFrom('app.sessions').where('expires_at', '<', new Date()).execute();
      await authDb.deleteFrom('app.login_attempts').where('at', '<', new Date(Date.now() - 30 * 864e5)).execute();
      await authDb.deleteFrom('app.password_resets').where('expires_at', '<', new Date(Date.now() - 864e5)).execute();
    } catch (e) { log.error({ err: (e as Error).message }, 'falha na rotina agendada'); }
    finally { running = false; }
  };
  timer = setInterval(tick, config.SYNC_INTERVAL_MINUTES * 60_000);
  setTimeout(tick, 10_000);
}
export function stopScheduler() { if (timer) clearInterval(timer); }
