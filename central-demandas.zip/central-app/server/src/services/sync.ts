import type { FastifyBaseLogger } from 'fastify';
import { sql } from 'kysely';
import { workerDb } from '../db/index.js';
import { graphEnabled } from '../config.js';
import { fetchInboxDelta, listAttachments, downloadAttachment, type GraphMessage } from './graph.js';
import { analisar, paraNota, sha256hex, MAX_ANEXO, type Analise } from '../nf/analisar.js';
import { onlyDigits, type Supplier } from '../nf/parse.js';
import { classify, categoriaPorRegra, type MailMeta } from './classifier.js';
import { HttpError } from '../auth/guard.js';

const MEETING = /^(aceito|recusado|cancelado|provis[oó]rio|accepted|declined|canceled|tentative)\s*:/i;
const today = () => new Date().toLocaleDateString('sv-SE', { timeZone: 'America/Sao_Paulo' });

type Box = { id: string; team_id: string; address: string; ignore_senders: string; delta_link: string | null; created_at: Date | string };

export async function syncMailbox(box: Box, log?: FastifyBaseLogger) {
  logRef = log;
  const { messages, deltaLink } = await fetchInboxDelta(box.address, box.delta_link);
  // na primeira leitura, ignora o histórico antigo: só entra o que chegou a partir de 1 dia antes do cadastro da caixa
  const cutoff = new Date(box.created_at).getTime() - 864e5;
  const fresh = messages.filter(m => m.id && m.receivedDateTime && Date.parse(m.receivedDateTime) >= cutoff);
  const ignore = box.ignore_senders.split(',').map(s => s.trim().toLowerCase()).filter(Boolean);
  const st = { recebidos: 0, regra: 0, info: 0, novas: 0, atualizadas: 0, notas: 0, anexos: 0, anexos_erro: 0 };

  // ignora e-mails já processados (o delta pode repetir alterações do mesmo e-mail)
  const known = new Set((await workerDb.selectFrom('app.demandas').select('message_id').where('team_id', '=', box.team_id)
    .where('message_id', 'in', fresh.length ? fresh.map(m => m.id) : ['-']).execute()).map(r => r.message_id));
  const pending = fresh.filter(m => !known.has(m.id));
  st.recebidos = pending.length;

  // anexos: procura notas fiscais (PDF/XML) antes de classificar; e-mail com nota sempre vira demanda
  const nfs = new Map<string, ArquivoNF[]>();
  for (const m of pending) {
    if (!m.hasAttachments) continue;
    try { const f = await coletarNFs(box.address, m); if (f.length) nfs.set(m.id, f); }
    catch (e) { st.anexos_erro++; log?.warn({ mailbox: box.id, err: (e as Error).message.slice(0, 200) }, 'falha ao ler anexos de um e-mail'); }
  }

  const toClassify: { msg: GraphMessage; meta: MailMeta }[] = [];
  for (const m of pending) {
    const meta: MailMeta = { id: m.id, subject: (m.subject ?? '').slice(0, 300), senderEmail: (m.from?.emailAddress?.address ?? '').toLowerCase(),
      senderName: m.from?.emailAddress?.name ?? '', preview: m.bodyPreview ?? '', importance: m.importance, receivedAt: m.receivedDateTime! };
    const forced = nfs.has(m.id) || categoriaPorRegra(`${meta.subject} ${meta.preview}`) !== '';
    if (!forced && (ignore.some(w => meta.senderEmail.includes(w)) || MEETING.test(meta.subject.trim()))) { st.regra++; continue; }
    toClassify.push({ msg: m, meta });
  }

  for (let i = 0; i < toClassify.length; i += 10) {
    const batch = toClassify.slice(i, i + 10);
    const results = await classify(batch.map(b => b.meta));
    for (let j = 0; j < batch.length; j++) {
      const { msg, meta } = batch[j], r = { ...results[j] };
      const arquivos = nfs.get(msg.id);
      if (arquivos) { // tem nota fiscal anexada: nunca é descartado
        if (r.decisao === 'nao') { r.decisao = 'sim'; r.acao = 'Conferir a nota fiscal anexada e lançar.'; }
        if (r.categoria !== 'pagamento') r.categoria = 'nota fiscal';
      }
      if (r.decisao === 'nao') { st.info++; continue; }
      // mesma conversa com demanda em aberto: só avisa que chegou mensagem nova
      if (msg.conversationId) {
        const prev = await workerDb.updateTable('app.demandas').set({ nova_msg: true, updated_at: new Date() })
          .where('team_id', '=', box.team_id).where('conversation_id', '=', msg.conversationId)
          .where('status', 'in', ['Para validar', 'A fazer', 'Aguardando retorno']).returning('id').execute();
        if (prev.length) {
          st.atualizadas++;
          if (arquivos) await contar(st, salvarNotas(box.team_id, prev[0].id, msg.id, arquivos));
          continue;
        }
      }
      const ins = await workerDb.insertInto('app.demandas').values({
        team_id: box.team_id, origem: 'email', message_id: msg.id, conversation_id: msg.conversationId ?? null,
        subject: meta.subject || '(sem assunto)', sender_email: meta.senderEmail || null, sender_name: meta.senderName.slice(0, 200) || null,
        received_at: meta.receivedAt, web_link: msg.webLink?.startsWith('https://') ? msg.webLink : null,
        categoria: r.categoria, tipo: r.tipo, resumo: r.resumo, acao: r.acao, prazo: r.prazo, prioridade: r.prioridade,
        suspeito: r.suspeito, decisao_ia: `${r.motor}: ${r.decisao === 'sim' ? 'pede ação' : 'em dúvida'}`,
      }).onConflict(oc => oc.columns(['team_id', 'message_id']).doNothing()).returning('id').executeTakeFirst();
      if (ins) { st.novas++; if (arquivos) await contar(st, salvarNotas(box.team_id, ins.id, msg.id, arquivos)); }
    }
  }

  await workerDb.insertInto('app.stats_diarios').values({ team_id: box.team_id, dia: today(), recebidos: st.recebidos, regra: st.regra, info: st.info, novas: st.novas })
    .onConflict(oc => oc.columns(['team_id', 'dia']).doUpdateSet({
      recebidos: sql`app.stats_diarios.recebidos + excluded.recebidos`, regra: sql`app.stats_diarios.regra + excluded.regra`,
      info: sql`app.stats_diarios.info + excluded.info`, novas: sql`app.stats_diarios.novas + excluded.novas` })).execute();
  // o ponto de continuação só é salvo depois que tudo foi gravado
  await workerDb.updateTable('app.mailboxes').set({ delta_link: deltaLink, last_sync_at: new Date(), last_error: null }).where('id', '=', box.id).execute();
  log?.info({ mailbox: box.id, ...st }, 'caixa sincronizada');
  return st;
}

// ---------- notas fiscais anexadas ----------
export interface ArquivoNF { nome: string; buf: Buffer; sha: string; analise: Analise }
const CANDIDATO = /\.(pdf|xml)$/i;
const MAX_POR_EMAIL = 10;

// Baixa só anexos que podem ser nota (PDF/XML, até 15 MB, no máximo 10 por e-mail) e guarda os que são nota fiscal.
async function coletarNFs(address: string, m: GraphMessage): Promise<ArquivoNF[]> {
  const lista = (await listAttachments(address, m.id)).filter(a =>
    a.id && !a.isInline && (a['@odata.type'] ?? '#microsoft.graph.fileAttachment') === '#microsoft.graph.fileAttachment'
    && (CANDIDATO.test(a.name ?? '') || /pdf|xml/i.test(a.contentType ?? '')) && (a.size ?? 0) <= MAX_ANEXO + 4096).slice(0, MAX_POR_EMAIL);
  const out: ArquivoNF[] = [];
  const contexto = `${m.subject ?? ''} ${m.bodyPreview ?? ''}`;
  for (const a of lista) {
    const buf = await downloadAttachment(address, m.id, a.id, MAX_ANEXO);
    const nome = (a.name || 'anexo').replace(/[\u0000-\u001f\\/]/g, '_').slice(0, 200);
    const analise = await analisar(buf, nome, contexto);
    if (analise?.nf) out.push({ nome, buf, sha: sha256hex(buf), analise });
  }
  return out;
}

const chaveNF = (n: string | null) => n ? onlyDigits(n).replace(/^0+(?=\d)/, '') : '';

// Agrupa PDF + XML da mesma nota, cria a nota (ou usa a que já existe) e guarda os arquivos.
async function salvarNotas(teamId: string, demandaId: string, messageId: string, arquivos: ArquivoNF[]) {
  return workerDb.transaction().execute(async trx => {
    const sup = await trx.selectFrom('app.fornecedores').select(['base', 'codigo', 'nome', 'cnpj']).where('team_id', '=', teamId).execute() as Supplier[];
    const lidos = arquivos.map(a => ({ a, n: paraNota(a.nome, a.analise, sup) }));
    const grupos = new Map<string, typeof lidos>();
    const semNumero: typeof lidos = [];
    for (const l of lidos) { const k = chaveNF(l.n.numero_nf); if (k) grupos.set(k, [...(grupos.get(k) ?? []), l]); else semNumero.push(l); }
    // arquivo sem número legível no mesmo e-mail de uma única nota: é dessa nota
    if (grupos.size === 1) [...grupos.values()][0].push(...semNumero.splice(0));
    const lista = [...grupos.values(), ...semNumero.map(l => [l])];
    let notas = 0, anexos = 0;
    for (const g of lista) {
      const novos: typeof lidos = [];
      for (const l of g) {
        const ja = await trx.selectFrom('app.anexos').select('id').where('team_id', '=', teamId).where('sha256', '=', l.a.sha).executeTakeFirst();
        if (!ja && !novos.some(x => x.a.sha === l.a.sha)) novos.push(l);
      }
      if (!novos.length) continue;
      const base = (g.find(l => l.a.analise.tipo === 'xml' && l.a.analise.dados) ?? g.find(l => l.a.analise.dados) ?? g[0]).n;
      let notaId: string | undefined;
      if (base.numero_nf) {
        const dup = await trx.selectFrom('app.notas').select(['id', 'demanda_id']).where('team_id', '=', teamId).where('numero_nf', '=', base.numero_nf)
          .where(eb => eb.fn.coalesce('cnpj', 'fornecedor', eb.val('')), '=', base.cnpj ?? base.fornecedor ?? '').executeTakeFirst();
        if (dup) {
          notaId = dup.id;
          if (!dup.demanda_id) await trx.updateTable('app.notas').set({ demanda_id: demandaId, updated_at: new Date() }).where('id', '=', dup.id).execute();
        }
      }
      if (!notaId) {
        notaId = (await trx.insertInto('app.notas').values({ ...base, team_id: teamId, origem: 'email', demanda_id: demandaId, created_by: null })
          .returning('id').executeTakeFirstOrThrow()).id;
        notas++;
      }
      for (const l of novos) {
        await trx.insertInto('app.anexos').values({ team_id: teamId, nota_id: notaId, origem: 'email', message_id: messageId.slice(0, 400),
          nome: l.a.nome, tipo: l.a.analise.tipo, tamanho: l.a.buf.length, sha256: l.a.sha, conteudo: l.a.buf, created_by: null }).execute();
        anexos++;
      }
    }
    return { notas, anexos };
  });
}
// Uma nota que falha ao gravar não trava a leitura da caixa: o e-mail continua virando demanda e o erro vai para o log.
type St = { notas: number; anexos: number; anexos_erro: number };
let logRef: FastifyBaseLogger | undefined;
async function contar(st: St, p: Promise<{ notas: number; anexos: number }>) {
  try { const r = await p; st.notas += r.notas; st.anexos += r.anexos; }
  catch (e) { st.anexos_erro++; logRef?.warn({ err: (e as Error).message.slice(0, 200) }, 'falha ao gravar nota de anexo'); }
}

async function runBoxes(boxes: Box[], log?: FastifyBaseLogger) {
  const out = [];
  for (const b of boxes) {
    try { out.push({ mailbox: b.address, ...(await syncMailbox(b, log)) }); }
    catch (e) {
      const msg = (e as Error).message.slice(0, 300);
      await workerDb.updateTable('app.mailboxes').set({ last_error: msg }).where('id', '=', b.id).execute();
      log?.error({ mailbox: b.id, err: msg }, 'falha ao sincronizar caixa');
      out.push({ mailbox: b.address, error: msg });
    }
  }
  return out;
}

const boxQuery = () => workerDb.selectFrom('app.mailboxes').select(['id', 'team_id', 'address', 'ignore_senders', 'delta_link', 'created_at']).where('enabled', '=', true);

// Uma rodada para todas as caixas. A trava no banco impede duas instâncias rodando ao mesmo tempo.
export async function syncAll(log?: FastifyBaseLogger) {
  if (!graphEnabled) return { skipped: 'graph_not_configured' };
  return workerDb.connection().execute(async conn => {
    const { rows } = await sql<{ ok: boolean }>`select pg_try_advisory_lock(7342001) as ok`.execute(conn);
    if (!rows[0]?.ok) return { skipped: 'already_running' };
    try { return { results: await runBoxes(await boxQuery().execute(), log) }; }
    finally { await sql`select pg_advisory_unlock(7342001)`.execute(conn); }
  });
}

export async function syncTeamNow(teamId: string, log?: FastifyBaseLogger) {
  if (!graphEnabled) throw new HttpError(503, 'A leitura da caixa ainda não foi configurada (falta configurar o acesso ao Microsoft 365).');
  return { results: await runBoxes(await boxQuery().where('team_id', '=', teamId).execute(), log) };
}
