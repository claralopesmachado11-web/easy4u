import { authDb, type Tx } from '../db/index.js';

// Registro de auditoria: quem fez o quê, quando e de onde. Nunca grava senhas, tokens ou conteúdo de e-mail.
export async function audit(e: { action: string; userId?: string | null; teamId?: string | null; entity?: string; entityId?: string; ip?: string | null; meta?: Record<string, unknown> }, trx?: Tx) {
  const row = { action: e.action, user_id: e.userId ?? null, team_id: e.teamId ?? null, entity: e.entity ?? null, entity_id: e.entityId ?? null, ip: e.ip ?? null, meta: JSON.stringify(e.meta ?? {}) };
  if (trx) await trx.insertInto('app.audit_log').values(row).execute();
  else await authDb.insertInto('app.audit_log').values(row).execute();
}
