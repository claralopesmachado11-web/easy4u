import nodemailer from 'nodemailer';
import { config, isProd } from '../config.js';

export interface Mail { to: string; subject: string; text: string }
// Caixa de saída de desenvolvimento/teste: só existe quando não há SMTP configurado.
// Em produção o servidor nem sobe sem SMTP (ver config.ts).
export const devOutbox: Mail[] = [];

const transport = config.SMTP_HOST
  ? nodemailer.createTransport({ host: config.SMTP_HOST, port: config.SMTP_PORT, secure: config.SMTP_PORT === 465, requireTLS: config.SMTP_PORT !== 465,
      auth: config.SMTP_USER ? { user: config.SMTP_USER, pass: config.SMTP_PASS } : undefined })
  : null;

export async function sendMail(m: Mail) {
  if (!transport) {
    if (isProd) throw new Error('SMTP não configurado');
    devOutbox.push(m);
    return;
  }
  await transport.sendMail({ from: config.MAIL_FROM, to: m.to, subject: m.subject, text: m.text });
}
