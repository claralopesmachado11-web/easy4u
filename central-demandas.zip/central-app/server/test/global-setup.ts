import pg from 'pg';
import { migrate } from '../src/db/migrate.js';

export default async function () {
  const admin = new pg.Client({ connectionString: 'postgres://pgadmin:devadminpass@localhost:5432/postgres' });
  await admin.connect();
  await admin.query('DROP DATABASE IF EXISTS central_test WITH (FORCE)');
  await admin.query('CREATE DATABASE central_test OWNER app_owner');
  await admin.end();
  const db = new pg.Client({ connectionString: 'postgres://pgadmin:devadminpass@localhost:5432/central_test' });
  await db.connect();
  await db.query('REVOKE ALL ON DATABASE central_test FROM PUBLIC; GRANT CONNECT ON DATABASE central_test TO app_auth, app_runtime, app_worker; REVOKE CREATE ON SCHEMA public FROM PUBLIC; CREATE EXTENSION IF NOT EXISTS citext; CREATE EXTENSION IF NOT EXISTS pgcrypto;');
  await db.end();
  await migrate('postgres://app_owner:dev_owner@localhost:5432/central_test', () => {});
}
