import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import http from 'node:http';
import { readFileSync } from 'node:fs';
import pg from 'pg';
import { Client, getApp, owner, makeAdmin, makeMember } from './helpers.js';
import { closeAll } from '../src/db/index.js';

// Arquivos de exemplo: NF-e em XML, DANFE em PDF (2 páginas), DANFE de outra nota, PDF escaneado e boleto (não é nota).
const fx = (n: string) => readFileSync(new URL(`./fixtures/${n}`, import.meta.url));
const XML = fx('nfe_98513.xml'), PDF98513 = fx('danfe_98513.pdf'), PDF32567 = fx('danfe_32567.pdf'), SCAN = fx('nf_escaneada_7781.pdf'), BOLETO = fx('boleto.pdf');

const now = Date.now();
type Att = { id: string; name: string; contentType: string; size: number; isInline?: boolean; data: Buffer; '@odata.type'?: string };
let inbox: any[] = []; const atts: Record<string, Att[]> = {}; let downloads = 0;
const att = (id: string, name: string, data: Buffer, contentType = name.endsWith('.xml') ? 'application/xml' : 'application/pdf', extra: Partial<Att> = {}): Att => ({ id, name, contentType, size: data.length, data, ...extra });
const mail = (id: string, subject: string, files: Att[], preview = '') => {
  atts[id] = files;
  return { id, subject, from: { emailAddress: { address: 'nfe@fornecedor.com', name: 'NF-e Fornecedor' } }, bodyPreview: preview,
    receivedDateTime: new Date(now - 60_000).toISOString(), conversationId: 'c-' + id, webLink: `https://outlook.office365.com/owa/?ItemID=${id}`, importance: 'normal', hasAttachments: files.length > 0 };
};

const fake = http.createServer((req, res) => {
  const url = new URL(req.url!, 'http://127.0.0.1:4599');
  const p = decodeURIComponent(url.pathname);
  if (p.endsWith('/oauth2/v2.0/token')) { res.setHeader('content-type', 'application/json'); return res.end(JSON.stringify({ access_token: 't', expires_in: 3600 })); }
  if (p.includes('/messages/delta')) {
    res.setHeader('content-type', 'application/json');
    const value = url.searchParams.get('deltatoken') ? [] : inbox;
    return res.end(JSON.stringify({ value, '@odata.deltaLink': 'http://127.0.0.1:4599/v1.0/users/x/mailFolders(\'inbox\')/messages/delta?deltatoken=z' }));
  }
  let m = p.match(/\/messages\/([^/]+)\/attachments\/([^/]+)\/\$value$/);
  if (m) {
    const a = atts[m[1]]?.find(x => x.id === m![2]);
    if (!a) { res.statusCode = 404; return res.end(); }
    downloads++; res.setHeader('content-type', 'application/octet-stream'); return res.end(a.data);
  }
  m = p.match(/\/messages\/([^/]+)\/attachments$/);
  if (m) { res.setHeader('content-type', 'application/json'); return res.end(JSON.stringify({ value: (atts[m[1]] ?? []).map(({ data, ...meta }) => ({ '@odata.type': '#microsoft.graph.fileAttachment', ...meta })) })); }
  res.statusCode = 404; res.end('{}');
});

let admin: Client, oper: Client, leitor: Client, outro: Client, team: string, team2: string;
beforeAll(async () => {
  await new Promise<void>(r => fake.listen(4599, '127.0.0.1', () => r()));
  ({ c: admin } = await makeAdmin());
  team = (await admin.post('/api/admin/teams', { name: 'Anexos ' + Date.now() })).json.id;
  team2 = (await admin.post('/api/admin/teams', { name: 'Outra ' + Date.now() })).json.id;
  const { rows } = await owner.query("select id from app.users where role='admin' order by created_at desc limit 1");
  await admin.put(`/api/admin/teams/${team}/members/${rows[0].id}`, { role: 'gestor' });
  ({ c: oper } = await makeMember(admin, team, 'operador'));
  ({ c: leitor } = await makeMember(admin, team, 'leitor'));
  ({ c: outro } = await makeMember(admin, team2, 'gestor'));
  await oper.post(`/api/teams/${team}/fornecedores`, { codigo: 'F777', nome: 'SERVCATER INTERNACIONAL LTDA', cnpj: '12345678000190', base: 'GRU' });
  await admin.post(`/api/admin/teams/${team}/mailboxes`, { address: 'caixa@empresa.com.br' });
});
afterAll(async () => { fake.close(); await (await getApp()).close(); await closeAll(); await owner.end(); });

const notas = async (c = leitor) => (await c.get(`/api/teams/${team}/notas`)).json as any[];

describe('notas fiscais anexadas aos e-mails', () => {
  it('identifica NF em XML e PDF, junta os dois na mesma nota, ignora boleto e não descarta o e-mail', async () => {
    inbox = [
      mail('a1', 'Faturamento novembro', [att('x1', 'NFe98513.xml', XML), att('p1', 'DANFE 98513.pdf', PDF98513), att('b1', 'boleto.pdf', BOLETO)], 'Segue em anexo.'),
      mail('a2', 'Documentos', [att('p2', 'documento.pdf', PDF32567)]),                   // assunto não fala em nota, mas o anexo é DANFE
      mail('a3', 'Nota fiscal 7781', [att('s1', 'nf 7781.pdf', SCAN)]),                   // escaneada: sem texto
      mail('a4', 'Boleto do mês', [att('b2', 'boleto.pdf', BOLETO)]),                       // só boleto: não cria nota
      mail('a5', 'Foto', [att('i1', 'assinatura.pdf', PDF32567, 'application/pdf', { isInline: true })]), // inline: ignorado
    ];
    const r = await oper.post(`/api/teams/${team}/sync`);
    expect(r.status).toBe(200);
    expect(r.json.results[0]).toMatchObject({ notas: 3, anexos: 4, anexos_erro: 0 });
    const list = await notas();
    expect(list).toHaveLength(3);
    const n1 = list.find(n => n.numero_nf === '98513');
    expect(n1).toMatchObject({ origem: 'email', fornecedor: 'SERVCATER INTERNACIONAL LTDA', codigo: 'F777', base: 'GRU', cnpj: '12345678000190', valor: '12345.67', emissao: '2026-11-17', po: '4500491234' });
    expect(n1.anexos.map((a: any) => a.tipo).sort()).toEqual(['pdf', 'xml']);
    expect(n1.demanda_id).toBeTruthy();
    const n2 = list.find(n => n.numero_nf === '32567');
    expect(n2).toMatchObject({ fornecedor: 'GATE GOURMET LTDA', valor: '4405.80', conferir: true });
    const n3 = list.find(n => n.numero_nf === '7781');
    expect(n3.conferir).toBe(true); expect(n3.avisos).toMatch(/sem texto/);
    // o e-mail "Documentos" virou demanda de nota fiscal mesmo sem palavra-chave no assunto
    const dem = (await leitor.get(`/api/teams/${team}/demandas?view=validar`)).json as any[];
    expect(dem.find(d => d.subject === 'Documentos')).toMatchObject({ categoria: 'nota fiscal' });
    // a demanda aponta para a nota
    expect(dem.find(d => d.subject === 'Faturamento novembro').id).toBe(n1.demanda_id);
  });

  it('o mesmo anexo reenviado em outro e-mail não cria nota nem arquivo repetidos', async () => {
    await owner.query('update app.mailboxes set delta_link = null where team_id=$1', [team]);
    inbox = [mail('a6', 'Reenvio NF 98513', [att('x2', 'NFe98513.xml', XML)])];
    const r = await oper.post(`/api/teams/${team}/sync`);
    expect(r.json.results[0]).toMatchObject({ notas: 0, anexos: 0 });
    expect(await notas()).toHaveLength(3);
  });

  it('o arquivo abre só para quem é da equipe e nunca é servido para o navegador executar', async () => {
    const n1 = (await notas()).find(n => n.numero_nf === '98513');
    const pdf = n1.anexos.find((a: any) => a.tipo === 'pdf');
    const r = await leitor.get(`/api/teams/${team}/anexos/${pdf.id}`);
    expect(r.status).toBe(200);
    expect(Buffer.compare(r.raw, PDF98513)).toBe(0);
    expect(r.headers['content-type']).toBe('application/pdf');
    expect(r.headers['content-disposition']).toMatch(/^attachment;/);
    expect(r.headers['content-security-policy']).toMatch(/sandbox/);
    expect(r.headers['cache-control']).toMatch(/no-store/);
    expect((await outro.get(`/api/teams/${team}/anexos/${pdf.id}`)).status).toBe(404);   // outra equipe
    expect((await outro.get(`/api/teams/${team2}/anexos/${pdf.id}`)).status).toBe(404); // id de outra equipe pela própria equipe
    expect((await new Client().get(`/api/teams/${team}/anexos/${pdf.id}`)).status).toBe(401);
  });

  it('o leitor de NF anexa o PDF à nota salva; valida tipo, conteúdo, permissão e CSRF', async () => {
    const s = await oper.post(`/api/teams/${team}/notas`, { notas: [{ numero_nf: '32001', fornecedor: 'Fornecedor Beta' }] });
    const id = s.json.ids[0];
    const url = `/api/teams/${team}/notas/${id}/anexos`;
    expect((await oper.upload(url, PDF32567, 'application/pdf', 'nota.pdf')).status).toBe(409);         // mesmo arquivo já guardado em outra nota
    const novo = Buffer.concat([PDF32567, Buffer.from('\n% copia\n')]);
    expect((await oper.upload(url, novo, 'application/pdf', 'NF 32001.pdf', { csrf: null })).status).toBe(403);
    expect((await leitor.upload(url, novo, 'application/pdf', 'NF 32001.pdf')).status).toBe(403);
    expect((await oper.upload(url, Buffer.from('<html><script>alert(1)</script></html>'), 'application/pdf', 'x.pdf')).status).toBe(415);
    expect((await oper.upload(url, Buffer.from('%PDF-1.7 isto não é um pdf'), 'application/pdf', 'x.pdf')).status).toBe(415);
    expect((await oper.upload(url, novo, 'image/png', 'x.png')).status).toBe(415);
    expect((await outro.upload(url, novo, 'application/pdf', 'x.pdf')).status).toBe(404);
    const ok = await oper.upload(url, novo, 'application/pdf', '../../etc/NF 32001.pdf');
    expect(ok.status).toBe(201);
    const n = (await notas()).find(x => x.id === id);
    expect(n.anexos).toHaveLength(1); expect(n.anexos[0].nome).toBe('.._.._etc_NF 32001.pdf');
    const { rows } = await owner.query("select count(*)::int n from app.audit_log where action='anexo.enviado' and entity_id=$1", [id]);
    expect(rows[0].n).toBe(1);
  });

  it('marcar como conferida, apagar arquivo e apagar nota (só gestor; arquivos saem junto)', async () => {
    const n3 = (await notas()).find(n => n.numero_nf === '7781');
    expect((await oper.patch(`/api/teams/${team}/notas/${n3.id}`, { conferir: false, valor: '150,00' })).status).toBe(200);
    expect((await oper.patch(`/api/teams/${team}/notas/${n3.id}`, { conferir: true })).status).toBe(400);
    expect((await notas()).find(n => n.id === n3.id)).toMatchObject({ conferir: false, valor: '150.00' });
    expect((await oper.del(`/api/teams/${team}/anexos/${n3.anexos[0].id}`)).status).toBe(403);
    const n1 = (await notas()).find(n => n.numero_nf === '98513');
    expect((await admin.del(`/api/teams/${team}/notas/${n1.id}`)).status).toBe(200);
    const { rows } = await owner.query('select count(*)::int n from app.anexos where nota_id=$1', [n1.id]);
    expect(rows[0].n).toBe(0);
  });

  it('o banco impede anexo ligado a nota de outra equipe e escrita direta fora das regras', async () => {
    const n = (await notas())[0];
    await expect(owner.query("insert into app.anexos(team_id,nota_id,origem,nome,tipo,tamanho,sha256,conteudo) values ($1,$2,'email','x.pdf','pdf',1,repeat('a',64),'\\x00')", [team2, n.id])).rejects.toThrow(/equipes diferentes/);
    const rt = new pg.Client({ connectionString: 'postgres://app_runtime:dev_runtime@localhost:5432/central_test' });
    await rt.connect();
    try {
      expect((await rt.query('select count(*)::int n from app.anexos')).rows[0].n).toBe(0); // sem usuário logado, nada aparece
      await expect(rt.query('update app.anexos set nome = $1', ['x'])).rejects.toThrow(/permission denied/); // ninguém altera arquivo guardado
    } finally { await rt.end(); }
  });
});
