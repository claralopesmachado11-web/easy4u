import type { FastifyInstance } from 'fastify';
import pg from 'pg';
import * as otp from 'otplib';
import { buildApp } from '../src/app.js';
import { devOutbox } from '../src/lib/mailer.js';

export const ORIGIN = 'http://localhost:5173';
export const owner = new pg.Pool({ connectionString: 'postgres://app_owner:dev_owner@localhost:5432/central_test', max: 2 });
let appP: Promise<FastifyInstance> | null = null;
export const getApp = () => (appP ??= buildApp().then(async a => { await a.ready(); return a; }));

let ipSeq = 10;
// Um "navegador" de teste: guarda o cookie e o token CSRF como o frontend faz.
export class Client {
  cookie = ''; csrf = ''; ip: string;
  constructor(ip?: string) { this.ip = ip ?? `10.0.${Math.floor(ipSeq / 250)}.${(ipSeq++ % 250) + 1}`; }
  async req(method: string, url: string, body?: unknown, opts: { origin?: string | null; csrf?: string | null; raw?: { buf: Buffer; type: string; name?: string } } = {}) {
    const app = await getApp();
    const headers: Record<string, string> = {};
    if (this.cookie) headers.cookie = this.cookie;
    if (opts.origin !== null) headers.origin = opts.origin ?? ORIGIN;
    const csrf = opts.csrf === undefined ? this.csrf : opts.csrf;
    if (csrf) headers['x-csrf-token'] = csrf;
    if (body !== undefined) headers['content-type'] = 'application/json';
    if (opts.raw) { headers['content-type'] = opts.raw.type; if (opts.raw.name) headers['x-file-name'] = encodeURIComponent(opts.raw.name); }
    const payload = opts.raw ? opts.raw.buf : body === undefined ? undefined : JSON.stringify(body);
    const res = await app.inject({ method: method as 'GET', url, headers, payload, remoteAddress: this.ip });
    const set = res.headers['set-cookie'];
    const list = Array.isArray(set) ? set : set ? [set] : [];
    for (const c of list) { const v = c.split(';')[0]; this.cookie = v.endsWith('=') ? '' : v; }
    let json: any = null; try { json = res.json(); } catch { /* sem corpo */ }
    if (json?.csrf) this.csrf = json.csrf;
    return { status: res.statusCode, json, headers: res.headers, raw: res.rawPayload };
  }
  get = (u: string) => this.req('GET', u);
  post = (u: string, b?: unknown) => this.req('POST', u, b ?? {});
  patch = (u: string, b: unknown) => this.req('PATCH', u, b);
  put = (u: string, b: unknown) => this.req('PUT', u, b);
  del = (u: string) => this.req('DELETE', u);
  upload = (u: string, buf: Buffer, type: string, name?: string, opts: { origin?: string | null; csrf?: string | null } = {}) => this.req('POST', u, undefined, { ...opts, raw: { buf, type, name } });
}

export const lastMail = () => devOutbox[devOutbox.length - 1];
export const tokenFromMail = () => lastMail().text.match(/#([A-Za-z0-9_-]{20,})/)![1];

let seq = 0;
export const uniqueEmail = (p = 'u') => `${p}${Date.now()}${seq++}@empresa.com.br`;
export const GOOD_PW = 'Caixa-Compartilhada-2026!';

// Cria administrador com 2 etapas ativa, pronto para usar a administração.
export async function makeAdmin() {
  const email = uniqueEmail('admin');
  const { rows } = await owner.query(`INSERT INTO app.invites(token_hash,email,global_role,expires_at) VALUES (encode(sha256(convert_to($1,'UTF8')),'hex'),$2,'admin',now()+interval '1 hour') RETURNING id`, [`tok-${email}-xxxxxxxxxxxxxxxx`, email]);
  const c = new Client();
  const r = await c.post('/api/auth/invite/accept', { token: `tok-${email}-xxxxxxxxxxxxxxxx`, name: 'Admin Teste', password: GOOD_PW });
  if (r.status !== 200) throw new Error('falha ao criar admin ' + JSON.stringify(r.json) + rows.length);
  const setup = await c.post('/api/auth/mfa/setup');
  const code = await otp.generate({ secret: setup.json.secret });
  const en = await c.post('/api/auth/mfa/enable', { code });
  if (en.status !== 200) throw new Error('mfa ' + JSON.stringify(en.json));
  return { c, email, secret: setup.json.secret as string };
}

// Convida e cria um usuário comum numa equipe.
export async function makeMember(admin: Client, teamId: string, role: 'gestor' | 'operador' | 'leitor') {
  const email = uniqueEmail(role);
  const inv = await admin.post('/api/admin/invites', { email, teamId, teamRole: role });
  if (inv.status !== 200) throw new Error('convite ' + JSON.stringify(inv.json));
  const token = inv.json.link.split('#')[1];
  const c = new Client();
  const r = await c.post('/api/auth/invite/accept', { token, name: `Pessoa ${role}`, password: GOOD_PW });
  if (r.status !== 200) throw new Error('aceite ' + JSON.stringify(r.json));
  await c.get('/api/auth/me');
  return { c, email };
}
