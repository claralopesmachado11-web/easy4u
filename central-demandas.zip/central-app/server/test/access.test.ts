import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import { randomUUID } from 'node:crypto';
import { Client, getApp, owner, makeAdmin, makeMember } from './helpers.js';
import { closeAll } from '../src/db/index.js';

let admin: Client, teamA: string, teamB: string;
let gestorA: Client, operA: Client, leitorA: Client, operB: Client;

beforeAll(async () => {
  ({ c: admin } = await makeAdmin());
  teamA = (await admin.post('/api/admin/teams', { name: 'Equipe A ' + Date.now() })).json.id;
  teamB = (await admin.post('/api/admin/teams', { name: 'Equipe B ' + Date.now() })).json.id;
  ({ c: gestorA } = await makeMember(admin, teamA, 'gestor'));
  ({ c: operA } = await makeMember(admin, teamA, 'operador'));
  ({ c: leitorA } = await makeMember(admin, teamA, 'leitor'));
  ({ c: operB } = await makeMember(admin, teamB, 'operador'));
});
afterAll(async () => { await (await getApp()).close(); await closeAll(); await owner.end(); });

describe('isolamento entre equipes', () => {
  it('cada um só vê as próprias equipes', async () => {
    const a = await operA.get('/api/teams'); const b = await operB.get('/api/teams');
    expect(a.json.map((t: any) => t.id)).toEqual([teamA]);
    expect(b.json.map((t: any) => t.id)).toEqual([teamB]);
  });

  it('não lê, altera nem apaga demandas de outra equipe (nem adivinhando o id)', async () => {
    const d = await operA.post(`/api/teams/${teamA}/demandas`, { subject: 'Pagar fornecedor X', categoria: 'pagamento' });
    expect(d.status).toBe(200);
    expect((await operB.get(`/api/teams/${teamA}/demandas?view=todas`)).status).toBe(404);
    expect((await operB.patch(`/api/teams/${teamA}/demandas/${d.json.id}`, { status: 'Concluída' })).status).toBe(404);
    // tenta pela própria equipe, apontando o id da outra (IDOR)
    expect((await operB.patch(`/api/teams/${teamB}/demandas/${d.json.id}`, { status: 'Concluída' })).status).toBe(404);
    expect((await operB.del(`/api/teams/${teamB}/demandas/${d.json.id}`)).status).toBe(403);
    const { rows } = await owner.query('select status from app.demandas where id=$1', [d.json.id]);
    expect(rows[0].status).toBe('A fazer');
  });

  it('o banco bloqueia mesmo se a aplicação errar (RLS)', async () => {
    const { rows } = await owner.query('select id from app.users where id <> all(select user_id from app.team_members where team_id=$1) limit 1', [teamA]);
    const pg = await import('pg');
    const rt = new pg.default.Client({ connectionString: 'postgres://app_runtime:dev_runtime@localhost:5432/central_test' });
    await rt.connect();
    await rt.query('begin'); await rt.query("select set_config('app.user_id',$1,true)", [rows[0].id]);
    const r = await rt.query('select count(*)::int n from app.demandas where team_id=$1', [teamA]);
    await rt.query('rollback'); await rt.end();
    expect(r.rows[0].n).toBe(0);
  });
});

describe('níveis dentro da equipe', () => {
  it('leitor só lê', async () => {
    expect((await leitorA.get(`/api/teams/${teamA}/demandas?view=todas`)).status).toBe(200);
    expect((await leitorA.post(`/api/teams/${teamA}/demandas`, { subject: 'x' })).status).toBe(403);
    expect((await leitorA.post(`/api/teams/${teamA}/notas`, { notas: [{ numero_nf: '1' }] })).status).toBe(403);
  });
  it('operador altera mas não apaga; gestor apaga', async () => {
    const d = await operA.post(`/api/teams/${teamA}/demandas`, { subject: 'Para apagar' });
    expect((await operA.patch(`/api/teams/${teamA}/demandas/${d.json.id}`, { status: 'Aguardando retorno', obs: 'liguei' })).status).toBe(200);
    expect((await operA.del(`/api/teams/${teamA}/demandas/${d.json.id}`)).status).toBe(403);
    expect((await gestorA.del(`/api/teams/${teamA}/demandas/${d.json.id}`)).status).toBe(200);
  });
  it('alteração fica no histórico com autor', async () => {
    const d = await operA.post(`/api/teams/${teamA}/demandas`, { subject: 'Com histórico' });
    await operA.patch(`/api/teams/${teamA}/demandas/${d.json.id}`, { prioridade: 'alta' });
    const h = await leitorA.get(`/api/teams/${teamA}/demandas/${d.json.id}/historico`);
    expect(h.json[0]).toMatchObject({ campo: 'prioridade', de: 'media', para: 'alta', name: 'Pessoa operador' });
  });
  it('admin que não é membro não vê dados da equipe', async () => {
    expect((await admin.get(`/api/teams/${teamA}/demandas?view=todas`)).status).toBe(404);
  });
});

describe('dados pessoais (rascunhos do leitor)', () => {
  it('rascunho de uma pessoa é invisível e intocável para outra', async () => {
    const id = randomUUID();
    expect((await operA.put(`/api/rascunhos/${id}`, { nome: 'Minhas notas', linhas: [{ numero_nf: '123' }] })).status).toBe(200);
    expect((await operB.get('/api/rascunhos')).json.find((r: any) => r.id === id)).toBeUndefined();
    await operB.put(`/api/rascunhos/${id}`, { nome: 'sequestro', linhas: [] });
    await operB.del(`/api/rascunhos/${id}`);
    const mine = (await operA.get('/api/rascunhos')).json.find((r: any) => r.id === id);
    expect(mine.nome).toBe('Minhas notas');
  });
});

describe('ataques simulados', () => {
  it('SQL Injection na busca é tratado como texto', async () => {
    const r = await operA.get(`/api/teams/${teamA}/demandas?view=todas&q=${encodeURIComponent("' OR 1=1; DROP TABLE app.demandas; --")}`);
    expect(r.status).toBe(200); expect(r.json).toEqual([]);
    const { rows } = await owner.query("select to_regclass('app.demandas') t");
    expect(rows[0].t).toBe('app.demandas');
  });
  it('SQL Injection no id é recusado na validação', async () => {
    expect((await operA.patch(`/api/teams/${teamA}/demandas/1%20OR%201=1`, { status: 'Concluída' })).status).toBe(400);
  });
  it('XSS fica guardado como texto puro, sem ser executado pela API', async () => {
    const payload = '<img src=x onerror=alert(1)>';
    const d = await operA.post(`/api/teams/${teamA}/demandas`, { subject: payload });
    const list = await operA.get(`/api/teams/${teamA}/demandas?view=todas`);
    expect(list.headers['content-type']).toMatch(/application\/json/);
    expect(list.json.find((x: any) => x.id === d.json.id).subject).toBe(payload);
  });
  it('não aceita campos extras (atribuição em massa)', async () => {
    const d = await operA.post(`/api/teams/${teamA}/demandas`, { subject: 'massa' });
    expect((await operA.patch(`/api/teams/${teamA}/demandas/${d.json.id}`, { status: 'A fazer', team_id: teamB })).status).toBe(400);
    expect((await admin.patch(`/api/admin/users/${randomUUID()}`, { password_hash: 'x' })).status).toBe(400);
  });
  it('valida dados: data impossível, prioridade inventada, texto longo demais', async () => {
    const d = await operA.post(`/api/teams/${teamA}/demandas`, { subject: 'val' });
    expect((await operA.patch(`/api/teams/${teamA}/demandas/${d.json.id}`, { prazo: '2026-02-31' })).status).toBe(400);
    expect((await operA.patch(`/api/teams/${teamA}/demandas/${d.json.id}`, { prioridade: 'urgentissima' })).status).toBe(400);
    expect((await operA.post(`/api/teams/${teamA}/demandas`, { subject: 'x'.repeat(301) })).status).toBe(400);
  });
  it('erros não mostram detalhes internos', async () => {
    const r = await operA.patch(`/api/teams/${teamA}/demandas/${randomUUID()}`, { status: 'A fazer' });
    expect(r.status).toBe(404); expect(JSON.stringify(r.json)).not.toMatch(/stack|select|postgres/i);
  });
  it('cabeçalhos de segurança presentes', async () => {
    const r = await operA.get('/api/teams');
    expect(r.headers['content-security-policy']).toMatch(/default-src 'self'/);
    expect(r.headers['x-frame-options']).toBeDefined();
    expect(r.headers['x-content-type-options']).toBe('nosniff');
    expect(r.headers['x-powered-by']).toBeUndefined();
  });
});
