import { describe, it, expect, afterAll } from 'vitest';
import * as otp from 'otplib';
import { Client, getApp, owner, makeAdmin, makeMember, uniqueEmail, GOOD_PW, lastMail, tokenFromMail } from './helpers.js';
import { devOutbox } from '../src/lib/mailer.js';
import { closeAll } from '../src/db/index.js';

afterAll(async () => { await (await getApp()).close(); await closeAll(); await owner.end(); });

describe('convite e cadastro', () => {
  it('cria conta pelo convite, grava hash Argon2id e não a senha', async () => {
    const { c, email } = await makeAdmin();
    const me = await c.get('/api/auth/me');
    expect(me.json.user.email).toBe(email);
    const { rows } = await owner.query('select password_hash from app.users where email=$1', [email]);
    expect(rows[0].password_hash).toMatch(/^\$argon2id\$/);
    expect(rows[0].password_hash).not.toContain(GOOD_PW);
  });

  it('recusa senha fraca, convite usado duas vezes e convite inventado', async () => {
    const { c: admin } = await makeAdmin();
    const email = uniqueEmail();
    const inv = await admin.post('/api/admin/invites', { email });
    const token = inv.json.link.split('#')[1];
    const x = new Client();
    expect((await x.post('/api/auth/invite/accept', { token, name: 'A', password: 'curta' })).status).toBe(400);
    expect((await x.post('/api/auth/invite/accept', { token, name: 'A', password: '123456789012' })).status).toBe(400);
    expect((await x.post('/api/auth/invite/accept', { token, name: 'A', password: GOOD_PW })).status).toBe(200);
    expect((await new Client().post('/api/auth/invite/accept', { token, name: 'B', password: GOOD_PW })).status).toBe(404);
    expect((await new Client().post('/api/auth/invite/accept', { token: 'x'.repeat(43), name: 'B', password: GOOD_PW })).status).toBe(404);
  });

  it('não existe cadastro aberto', async () => {
    const r = await new Client().post('/api/auth/register', { email: uniqueEmail(), password: GOOD_PW });
    expect(r.status).toBe(404);
  });
});

describe('login e sessão', () => {
  it('login certo cria cookie HttpOnly e SameSite=Strict; errado dá mensagem genérica', async () => {
    const { email } = await makeAdmin();
    await owner.query('update app.users set mfa_enabled=false where email=$1', [email]);
    const c = new Client();
    const ok = await c.post('/api/auth/login', { email, password: GOOD_PW });
    expect(ok.status).toBe(200);
    const cookie = String(ok.headers['set-cookie']);
    expect(cookie).toMatch(/HttpOnly/i); expect(cookie).toMatch(/SameSite=Strict/i);
    const wrong = await new Client().post('/api/auth/login', { email, password: 'errada-errada-1' });
    const ghost = await new Client().post('/api/auth/login', { email: uniqueEmail('nao-existe'), password: 'errada-errada-1' });
    expect(wrong.status).toBe(401); expect(ghost.status).toBe(401);
    expect(wrong.json.error).toBe(ghost.json.error); // não revela se a conta existe
  });

  it('bloqueia a conta depois de 5 senhas erradas, mesmo com a senha certa depois', async () => {
    const { email } = await makeAdmin();
    for (let i = 0; i < 5; i++) await new Client().post('/api/auth/login', { email, password: 'errada-errada-' + i });
    const r = await new Client().post('/api/auth/login', { email, password: GOOD_PW });
    expect(r.status).toBe(429);
    const { rows } = await owner.query('select locked_until from app.users where email=$1', [email]);
    expect(new Date(rows[0].locked_until).getTime()).toBeGreaterThan(Date.now());
  });

  it('limita tentativas por IP (força bruta em várias contas)', async () => {
    const c = new Client('10.99.99.99');
    let last = 0;
    for (let i = 0; i < 22; i++) last = (await c.post('/api/auth/login', { email: uniqueEmail(), password: 'qualquer-coisa-1' })).status;
    expect(last).toBe(429);
  });

  it('logout invalida a sessão no servidor', async () => {
    const { c } = await makeAdmin();
    const old = c.cookie;
    expect((await c.post('/api/auth/logout')).status).toBe(200);
    const again = new Client(); again.cookie = old;
    expect((await again.get('/api/auth/me')).json.user).toBeNull();
  });

  it('cookie forjado não dá acesso', async () => {
    const c = new Client(); c.cookie = 'sid=inventado123';
    expect((await c.get('/api/teams')).status).toBe(401);
  });
});

describe('CSRF e origem', () => {
  it('recusa alteração sem token CSRF ou vinda de outro site', async () => {
    const { c } = await makeAdmin();
    expect((await c.req('POST', '/api/admin/teams', { name: 'X' }, { csrf: null })).status).toBe(403);
    expect((await c.req('POST', '/api/admin/teams', { name: 'X' }, { csrf: 'token-errado' })).status).toBe(403);
    expect((await c.req('POST', '/api/admin/teams', { name: 'X' + Date.now() }, { origin: 'https://site-malicioso.com' })).status).toBe(403);
    expect((await c.req('POST', '/api/admin/teams', { name: 'X' + Date.now() }, { origin: null })).status).toBe(403);
    expect((await c.post('/api/admin/teams', { name: 'Equipe ' + Date.now() })).status).toBe(200);
  });
});

describe('recuperação de senha', () => {
  it('mesma resposta para e-mail existente ou não; link troca a senha e derruba sessões antigas', async () => {
    const { c: admin, email } = await makeAdmin();
    await owner.query('update app.users set mfa_enabled=false where email=$1', [email]);
    const before = devOutbox.length;
    const ghost = await new Client().post('/api/auth/forgot', { email: uniqueEmail('ghost') });
    expect(devOutbox.length).toBe(before);
    const real = await new Client().post('/api/auth/forgot', { email });
    expect(ghost.status).toBe(202); expect(real.status).toBe(202); expect(ghost.json).toEqual(real.json);
    expect(lastMail().to).toBe(email);
    const token = tokenFromMail();
    const NEW = 'Outra-Senha-Bem-Forte-77';
    expect((await new Client().post('/api/auth/reset', { token, password: NEW })).status).toBe(200);
    expect((await new Client().post('/api/auth/reset', { token, password: NEW + 'x' })).status).toBe(400); // uso único
    expect((await admin.get('/api/auth/me')).json.user).toBeNull(); // sessão antiga caiu
    expect((await new Client().post('/api/auth/login', { email, password: GOOD_PW })).status).toBe(401);
    expect((await new Client().post('/api/auth/login', { email, password: NEW })).status).toBe(200);
  });

  it('link vencido não funciona', async () => {
    const { email } = await makeAdmin();
    await new Client().post('/api/auth/forgot', { email });
    const token = tokenFromMail();
    await owner.query("update app.password_resets set expires_at = now() - interval '1 minute' where used_at is null");
    expect((await new Client().post('/api/auth/reset', { token, password: 'Mais-Uma-Senha-Forte-9' })).status).toBe(400);
  });
});

describe('verificação em duas etapas e níveis', () => {
  it('admin com 2 etapas precisa do código no login', async () => {
    const { email, secret } = await makeAdmin();
    const c = new Client();
    const r = await c.post('/api/auth/login', { email, password: GOOD_PW });
    expect(r.json.mfaRequired).toBe(true);
    expect((await c.get('/api/admin/users')).status).toBe(401);
    expect((await c.post('/api/auth/mfa/verify', { code: '000000' })).status).toBe(401);
    expect((await c.post('/api/auth/mfa/verify', { code: await otp.generate({ secret }) })).status).toBe(200);
    expect((await c.get('/api/admin/users')).status).toBe(200);
  });

  it('admin sem 2 etapas não usa a administração; usuário comum nunca usa', async () => {
    const { c, email } = await makeAdmin();
    await owner.query('update app.users set mfa_enabled=false where email=$1', [email]);
    const r = await c.get('/api/admin/users');
    expect(r.status).toBe(403); expect(r.json.code).toBe('mfa_setup_required');
    const { c: admin } = await makeAdmin();
    const team = await admin.post('/api/admin/teams', { name: 'T' + Date.now() });
    const { c: user } = await makeMember(admin, team.json.id, 'gestor');
    expect((await user.get('/api/admin/users')).status).toBe(403);
    expect((await user.post('/api/admin/invites', { email: uniqueEmail(), globalRole: 'admin' })).status).toBe(403);
  });

  it('desativar usuário derruba as sessões dele', async () => {
    const { c: admin } = await makeAdmin();
    const team = await admin.post('/api/admin/teams', { name: 'D' + Date.now() });
    const { c: user, email } = await makeMember(admin, team.json.id, 'operador');
    const { rows } = await owner.query('select id from app.users where email=$1', [email]);
    expect((await admin.patch(`/api/admin/users/${rows[0].id}`, { is_active: false })).status).toBe(200);
    expect((await user.get('/api/teams')).status).toBe(401);
  });

  it('administrador não pode se rebaixar ou se desativar', async () => {
    const { c: admin, email } = await makeAdmin();
    const { rows } = await owner.query('select id from app.users where email=$1', [email]);
    expect((await admin.patch(`/api/admin/users/${rows[0].id}`, { role: 'user' })).status).toBe(403);
  });
});
