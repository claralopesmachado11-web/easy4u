import { describe, it, expect, vi } from 'vitest';
vi.hoisted(() => { process.env.AZURE_OPENAI_ENDPOINT = 'https://ia-teste.openai.azure.com'; process.env.AZURE_OPENAI_DEPLOYMENT = 'triagem'; process.env.AZURE_OPENAI_KEY = 'chave-falsa'; });
import { classifyWithAI } from '../src/services/classifier.js';

const base = { senderEmail: 'a@b.com', senderName: 'A', receivedAt: new Date().toISOString() };
const fakeFetch = (content: unknown, status = 200) => (async () => new Response(JSON.stringify({ choices: [{ message: { content: typeof content === 'string' ? content : JSON.stringify(content) } }] }), { status })) as unknown as typeof fetch;

describe('classificação com Azure OpenAI', () => {
  it('usa a resposta da IA, mas nunca descarta nota fiscal', async () => {
    const r = await classifyWithAI([
      { ...base, id: '1', subject: 'Envio NF-e 123', preview: '' },
      { ...base, id: '2', subject: 'Pode revisar a escala?', preview: '' },
    ], fakeFetch({ itens: [
      { i: 0, decisao: 'nao', categoria: 'outro', tipo: 'aviso', resumo: 'nota', acao: '', prazo: '', prioridade: 'baixa', suspeito: false },
      { i: 1, decisao: 'sim', categoria: 'outro', tipo: 'solicitação', resumo: 'Revisar escala', acao: 'Revisar', prazo: '2026-12-01', prioridade: 'media', suspeito: false },
    ] }));
    expect(r[0]).toMatchObject({ decisao: 'duvida', categoria: 'nota fiscal', motor: 'ia' });
    expect(r[1]).toMatchObject({ decisao: 'sim', resumo: 'Revisar escala', prazo: '2026-12-01' });
  });
  it('resposta faltando ou com valores inventados cai nas regras ou em valores seguros', async () => {
    const r = await classifyWithAI([{ ...base, id: '1', subject: 'Boleto vencido', preview: '' }, { ...base, id: '2', subject: 'Oi', preview: '' }],
      fakeFetch({ itens: [{ i: 1, decisao: 'talvez', categoria: 'xyz', prioridade: 'mega', prazo: 'amanhã' }] }));
    expect(r[0]).toMatchObject({ decisao: 'sim', categoria: 'pagamento', motor: 'regras' });
    expect(r[1]).toMatchObject({ decisao: 'duvida', categoria: '', prioridade: 'media', prazo: null });
  });
  it('resposta que não é JSON gera erro (e o sincronizador usa as regras)', async () => {
    await expect(classifyWithAI([{ ...base, id: '1', subject: 'x', preview: '' }], fakeFetch('isto não é json'))).rejects.toThrow();
    await expect(classifyWithAI([{ ...base, id: '1', subject: 'x', preview: '' }], fakeFetch({}, 500))).rejects.toThrow(/500/);
  });
});
