// Ambiente de teste: banco separado, chaves geradas só para teste.
process.env.NODE_ENV = 'test';
process.env.APP_URL = 'http://localhost:5173';
process.env.DATABASE_URL_AUTH = 'postgres://app_auth:dev_auth@localhost:5432/central_test';
process.env.DATABASE_URL_RUNTIME = 'postgres://app_runtime:dev_runtime@localhost:5432/central_test';
process.env.DATABASE_URL_WORKER = 'postgres://app_worker:dev_worker@localhost:5432/central_test';
process.env.ENCRYPTION_KEY = Buffer.alloc(32, 7).toString('base64');
process.env.GRAPH_TENANT_ID = 'tenant-teste';
process.env.GRAPH_CLIENT_ID = 'cliente-teste';
process.env.GRAPH_CLIENT_SECRET = 'segredo-teste';
process.env.GRAPH_BASE_URL = 'http://127.0.0.1:4599/v1.0';
process.env.GRAPH_LOGIN_URL = 'http://127.0.0.1:4599';
