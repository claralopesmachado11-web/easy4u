-- 001: estrutura principal.
-- Roda como app_owner (dono das tabelas). O app nunca usa esse usuário em tempo de execução.

CREATE EXTENSION IF NOT EXISTS citext;
CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE SCHEMA IF NOT EXISTS app;

-- ---------- usuários e acesso ----------
CREATE TABLE app.users (
  id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email            citext NOT NULL UNIQUE CHECK (length(email) <= 254),
  name             text NOT NULL CHECK (length(name) BETWEEN 1 AND 120),
  password_hash    text NOT NULL,
  role             text NOT NULL DEFAULT 'user' CHECK (role IN ('admin','user')),
  is_active        boolean NOT NULL DEFAULT true,
  failed_logins    integer NOT NULL DEFAULT 0,
  locked_until     timestamptz,
  mfa_secret       text,            -- cifrado pela aplicação (AES-256-GCM)
  mfa_enabled      boolean NOT NULL DEFAULT false,
  password_changed_at timestamptz NOT NULL DEFAULT now(),
  created_at       timestamptz NOT NULL DEFAULT now(),
  updated_at       timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE app.sessions (
  id            text PRIMARY KEY,           -- SHA-256 do token; o token em si só existe no cookie
  user_id       uuid NOT NULL REFERENCES app.users(id) ON DELETE CASCADE,
  csrf_token    text NOT NULL,
  mfa_pending   boolean NOT NULL DEFAULT false,
  ip            inet,
  user_agent    text,
  created_at    timestamptz NOT NULL DEFAULT now(),
  last_seen_at  timestamptz NOT NULL DEFAULT now(),
  expires_at    timestamptz NOT NULL
);
CREATE INDEX sessions_user_idx ON app.sessions(user_id);

CREATE TABLE app.teams (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name        text NOT NULL UNIQUE CHECK (length(name) BETWEEN 1 AND 80),
  created_at  timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE app.team_members (
  team_id    uuid NOT NULL REFERENCES app.teams(id) ON DELETE CASCADE,
  user_id    uuid NOT NULL REFERENCES app.users(id) ON DELETE CASCADE,
  role       text NOT NULL CHECK (role IN ('gestor','operador','leitor')),
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (team_id, user_id)
);
CREATE INDEX team_members_user_idx ON app.team_members(user_id);

CREATE TABLE app.invites (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  token_hash  text NOT NULL UNIQUE,
  email       citext NOT NULL,
  global_role text NOT NULL DEFAULT 'user' CHECK (global_role IN ('admin','user')),
  team_id     uuid REFERENCES app.teams(id) ON DELETE CASCADE,
  team_role   text CHECK (team_role IN ('gestor','operador','leitor')),
  invited_by  uuid REFERENCES app.users(id) ON DELETE SET NULL,
  expires_at  timestamptz NOT NULL,
  used_at     timestamptz,
  created_at  timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE app.password_resets (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     uuid NOT NULL REFERENCES app.users(id) ON DELETE CASCADE,
  token_hash  text NOT NULL UNIQUE,
  expires_at  timestamptz NOT NULL,
  used_at     timestamptz,
  created_at  timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE app.login_attempts (
  id       bigserial PRIMARY KEY,
  email    citext,
  ip       inet,
  success  boolean NOT NULL,
  at       timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX login_attempts_ip_idx ON app.login_attempts(ip, at);
CREATE INDEX login_attempts_email_idx ON app.login_attempts(email, at);

-- ---------- Central de Demandas ----------
CREATE TABLE app.mailboxes (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  team_id       uuid NOT NULL REFERENCES app.teams(id) ON DELETE CASCADE,
  address       citext NOT NULL,
  ignore_senders text NOT NULL DEFAULT 'noreply, no-reply, naoresponda, nao-responda, donotreply, mailer-daemon, notification, notificacao, newsletter',
  delta_link    text,
  enabled       boolean NOT NULL DEFAULT true,
  last_sync_at  timestamptz,
  last_error    text,
  created_at    timestamptz NOT NULL DEFAULT now(),
  UNIQUE (team_id, address)
);

CREATE TABLE app.demandas (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  team_id         uuid NOT NULL REFERENCES app.teams(id) ON DELETE CASCADE,
  origem          text NOT NULL CHECK (origem IN ('email','manual')),
  message_id      text,
  conversation_id text,
  subject         text NOT NULL CHECK (length(subject) <= 300),
  sender_email    citext,
  sender_name     text CHECK (length(sender_name) <= 200),
  received_at     timestamptz NOT NULL DEFAULT now(),
  web_link        text CHECK (web_link IS NULL OR web_link ~ '^https://'),
  categoria       text NOT NULL DEFAULT '' CHECK (categoria IN ('','nota fiscal','pagamento','fornecedor')),
  tipo            text NOT NULL DEFAULT 'outro' CHECK (length(tipo) <= 30),
  resumo          text NOT NULL DEFAULT '' CHECK (length(resumo) <= 300),
  acao            text NOT NULL DEFAULT '' CHECK (length(acao) <= 300),
  prazo           date,
  prioridade      text NOT NULL DEFAULT 'media' CHECK (prioridade IN ('alta','media','baixa')),
  status          text NOT NULL DEFAULT 'Para validar' CHECK (status IN ('Para validar','A fazer','Aguardando retorno','Concluída','Descartada')),
  obs             text NOT NULL DEFAULT '' CHECK (length(obs) <= 500),
  suspeito        boolean NOT NULL DEFAULT false,
  nova_msg        boolean NOT NULL DEFAULT false,
  decisao_ia      text NOT NULL DEFAULT '' CHECK (length(decisao_ia) <= 40),
  created_by      uuid REFERENCES app.users(id) ON DELETE SET NULL,
  created_at      timestamptz NOT NULL DEFAULT now(),
  updated_at      timestamptz NOT NULL DEFAULT now(),
  UNIQUE (team_id, message_id)
);
CREATE INDEX demandas_team_status_idx ON app.demandas(team_id, status);
CREATE INDEX demandas_team_conv_idx ON app.demandas(team_id, conversation_id);

CREATE TABLE app.demanda_eventos (
  id          bigserial PRIMARY KEY,
  demanda_id  uuid NOT NULL REFERENCES app.demandas(id) ON DELETE CASCADE,
  team_id     uuid NOT NULL REFERENCES app.teams(id) ON DELETE CASCADE,
  user_id     uuid REFERENCES app.users(id) ON DELETE SET NULL,
  campo       text NOT NULL,
  de          text,
  para        text,
  at          timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX demanda_eventos_demanda_idx ON app.demanda_eventos(demanda_id);

CREATE TABLE app.stats_diarios (
  team_id    uuid NOT NULL REFERENCES app.teams(id) ON DELETE CASCADE,
  dia        date NOT NULL,
  recebidos  integer NOT NULL DEFAULT 0,
  regra      integer NOT NULL DEFAULT 0,
  info       integer NOT NULL DEFAULT 0,
  novas      integer NOT NULL DEFAULT 0,
  PRIMARY KEY (team_id, dia)
);

-- ---------- Leitor de NF ----------
CREATE TABLE app.fornecedores (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  team_id    uuid NOT NULL REFERENCES app.teams(id) ON DELETE CASCADE,
  codigo     text NOT NULL CHECK (length(codigo) BETWEEN 1 AND 40),
  nome       text NOT NULL CHECK (length(nome) BETWEEN 1 AND 200),
  cnpj       text CHECK (cnpj IS NULL OR cnpj ~ '^[0-9]{14}$'),
  base       text CHECK (length(base) <= 40),
  obs        text NOT NULL DEFAULT '' CHECK (length(obs) <= 500),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (team_id, codigo)
);

CREATE TABLE app.notas (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  team_id        uuid NOT NULL REFERENCES app.teams(id) ON DELETE CASCADE,
  mes            text CHECK (length(mes) <= 20),
  qz             text CHECK (length(qz) <= 10),
  base           text CHECK (length(base) <= 40),
  codigo         text CHECK (length(codigo) <= 40),
  fornecedor     text CHECK (length(fornecedor) <= 200),
  cnpj           text CHECK (cnpj IS NULL OR cnpj ~ '^[0-9]{14}$'),
  rc             text CHECK (length(rc) <= 40),
  po             text CHECK (length(po) <= 40),
  migo           text CHECK (length(migo) <= 40),
  numero_nf      text NOT NULL CHECK (length(numero_nf) BETWEEN 1 AND 40),
  valor          numeric(14,2) CHECK (valor IS NULL OR valor >= 0),
  emissao        date,
  vencimento     date,
  envio_central  date,
  status         text NOT NULL DEFAULT 'pendente' CHECK (status IN ('pendente','lancada')),
  created_by     uuid REFERENCES app.users(id) ON DELETE SET NULL,
  created_at     timestamptz NOT NULL DEFAULT now(),
  updated_at     timestamptz NOT NULL DEFAULT now()
);
-- impede lançar a mesma nota duas vezes (mesmo fornecedor + número)
CREATE UNIQUE INDEX notas_unicas ON app.notas(team_id, coalesce(cnpj, fornecedor, ''), numero_nf);

-- rascunhos do leitor: dados pessoais de cada usuário
CREATE TABLE app.rascunhos_nf (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id    uuid NOT NULL REFERENCES app.users(id) ON DELETE CASCADE,
  nome       text NOT NULL CHECK (length(nome) BETWEEN 1 AND 120),
  linhas     jsonb NOT NULL DEFAULT '[]'::jsonb CHECK (jsonb_typeof(linhas) = 'array' AND pg_column_size(linhas) < 512000),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX rascunhos_user_idx ON app.rascunhos_nf(user_id);

-- ---------- auditoria (só cresce; ninguém do app altera ou apaga) ----------
CREATE TABLE app.audit_log (
  id         bigserial PRIMARY KEY,
  at         timestamptz NOT NULL DEFAULT now(),
  user_id    uuid,
  team_id    uuid,
  action     text NOT NULL,
  entity     text,
  entity_id  text,
  ip         inet,
  meta       jsonb NOT NULL DEFAULT '{}'::jsonb
);
CREATE INDEX audit_log_at_idx ON app.audit_log(at);
