-- Rodar UMA vez, por quem administra o banco (no Azure: o administrador do PostgreSQL Flexible Server).
-- As senhas vêm de variáveis do psql: nunca escreva senhas neste arquivo.
-- Exemplo:
--   psql "$ADMIN_URL" -v owner_pw="$OWNER_PW" -v auth_pw="$AUTH_PW" -v runtime_pw="$RUNTIME_PW" -v worker_pw="$WORKER_PW" -v db=central -f bootstrap-roles.sql

CREATE ROLE app_owner   LOGIN PASSWORD :'owner_pw';
CREATE ROLE app_auth    LOGIN PASSWORD :'auth_pw'    NOSUPERUSER NOBYPASSRLS NOCREATEDB NOCREATEROLE;
CREATE ROLE app_runtime LOGIN PASSWORD :'runtime_pw' NOSUPERUSER NOBYPASSRLS NOCREATEDB NOCREATEROLE;
CREATE ROLE app_worker  LOGIN PASSWORD :'worker_pw'  NOSUPERUSER NOBYPASSRLS NOCREATEDB NOCREATEROLE;

CREATE DATABASE :"db" OWNER app_owner;
\c :"db"
REVOKE ALL ON DATABASE :"db" FROM PUBLIC;
GRANT CONNECT ON DATABASE :"db" TO app_auth, app_runtime, app_worker;
REVOKE CREATE ON SCHEMA public FROM PUBLIC;
-- extensões precisam de privilégio de administrador
CREATE EXTENSION IF NOT EXISTS citext;
CREATE EXTENSION IF NOT EXISTS pgcrypto;
