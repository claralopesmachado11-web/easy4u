-- 002: permissões e regras de acesso por linha (Row-Level Security).
-- Três usuários de banco, cada um com o mínimo necessário:
--   app_auth    -> login, sessões, convites, recuperação de senha. Não lê dados de negócio.
--   app_runtime -> uso normal. Só vê linhas das equipes do usuário logado (app.user_id).
--   app_worker  -> leitura da caixa. Só escreve demandas, caixas e números. Não lê usuários.

REVOKE ALL ON SCHEMA app FROM PUBLIC;
GRANT USAGE ON SCHEMA app TO app_auth, app_runtime, app_worker;

-- ---------- funções auxiliares ----------
CREATE OR REPLACE FUNCTION app.current_user_id() RETURNS uuid
LANGUAGE sql STABLE AS $$
  SELECT nullif(current_setting('app.user_id', true), '')::uuid
$$;

-- SECURITY DEFINER: consultam a tabela de membros sem cair em recursão nas próprias regras.
CREATE OR REPLACE FUNCTION app.team_role(t uuid) RETURNS text
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, pg_temp AS $$
  SELECT role FROM app.team_members WHERE team_id = t AND user_id = app.current_user_id()
$$;

CREATE OR REPLACE FUNCTION app.is_admin() RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, pg_temp AS $$
  SELECT EXISTS (SELECT 1 FROM app.users WHERE id = app.current_user_id() AND role = 'admin' AND is_active)
$$;

CREATE OR REPLACE FUNCTION app.shares_team(other uuid) RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, pg_temp AS $$
  SELECT EXISTS (SELECT 1 FROM app.team_members a JOIN app.team_members b ON a.team_id = b.team_id
                 WHERE a.user_id = app.current_user_id() AND b.user_id = other)
$$;

REVOKE ALL ON FUNCTION app.team_role(uuid), app.is_admin(), app.shares_team(uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION app.current_user_id(), app.team_role(uuid), app.is_admin(), app.shares_team(uuid) TO app_runtime;

-- ---------- permissões por tabela ----------
GRANT SELECT, INSERT, UPDATE, DELETE ON app.users, app.sessions, app.invites, app.password_resets, app.login_attempts TO app_auth;
GRANT SELECT, INSERT ON app.team_members, app.teams TO app_auth;
GRANT INSERT ON app.audit_log TO app_auth, app_runtime, app_worker;
GRANT USAGE ON SEQUENCE app.login_attempts_id_seq, app.audit_log_id_seq TO app_auth, app_runtime, app_worker;

GRANT SELECT, UPDATE (name, role, is_active, updated_at, password_hash, password_changed_at, mfa_secret, mfa_enabled) ON app.users TO app_runtime;
GRANT SELECT, INSERT, UPDATE, DELETE ON app.teams, app.team_members, app.mailboxes, app.demandas, app.fornecedores, app.notas, app.rascunhos_nf, app.invites TO app_runtime;
GRANT SELECT, INSERT ON app.demanda_eventos TO app_runtime;
GRANT USAGE ON SEQUENCE app.demanda_eventos_id_seq TO app_runtime, app_worker;
GRANT SELECT ON app.stats_diarios TO app_runtime;
GRANT SELECT ON app.audit_log TO app_runtime;

GRANT SELECT, UPDATE ON app.mailboxes TO app_worker;
GRANT SELECT, INSERT, UPDATE ON app.demandas TO app_worker;
GRANT SELECT, INSERT, UPDATE ON app.stats_diarios TO app_worker;
GRANT INSERT ON app.demanda_eventos TO app_worker;

-- ---------- RLS ligado e forçado em todas as tabelas ----------
DO $$ DECLARE t text; BEGIN
  FOREACH t IN ARRAY ARRAY['users','sessions','teams','team_members','invites','password_resets','login_attempts',
    'mailboxes','demandas','demanda_eventos','stats_diarios','fornecedores','notas','rascunhos_nf','audit_log'] LOOP
    EXECUTE format('ALTER TABLE app.%I ENABLE ROW LEVEL SECURITY', t);
    EXECUTE format('ALTER TABLE app.%I FORCE ROW LEVEL SECURITY', t);
  END LOOP;
END $$;

-- app_auth: acesso livre só às tabelas de autenticação (já limitado pelos GRANTs acima)
CREATE POLICY auth_all ON app.users           TO app_auth USING (true) WITH CHECK (true);
CREATE POLICY auth_all ON app.sessions        TO app_auth USING (true) WITH CHECK (true);
CREATE POLICY auth_all ON app.invites         TO app_auth USING (true) WITH CHECK (true);
CREATE POLICY auth_all ON app.password_resets TO app_auth USING (true) WITH CHECK (true);
CREATE POLICY auth_all ON app.login_attempts  TO app_auth USING (true) WITH CHECK (true);
CREATE POLICY auth_read  ON app.teams         TO app_auth USING (true);
CREATE POLICY auth_insert ON app.team_members TO app_auth WITH CHECK (true);
CREATE POLICY auth_read_m ON app.team_members TO app_auth USING (true);
CREATE POLICY log_insert ON app.audit_log TO app_auth, app_runtime, app_worker WITH CHECK (true);

-- app_runtime: usuários
CREATE POLICY u_select ON app.users TO app_runtime
  USING (id = app.current_user_id() OR app.is_admin() OR app.shares_team(id));
CREATE POLICY u_update ON app.users TO app_runtime
  USING (id = app.current_user_id() OR app.is_admin())
  WITH CHECK (id = app.current_user_id() OR app.is_admin());

-- equipes e membros
CREATE POLICY t_select ON app.teams TO app_runtime USING (app.team_role(id) IS NOT NULL OR app.is_admin());
CREATE POLICY t_admin  ON app.teams FOR ALL TO app_runtime USING (app.is_admin()) WITH CHECK (app.is_admin());
CREATE POLICY m_select ON app.team_members TO app_runtime USING (app.team_role(team_id) IS NOT NULL OR app.is_admin());
CREATE POLICY m_admin  ON app.team_members FOR ALL TO app_runtime USING (app.is_admin()) WITH CHECK (app.is_admin());
CREATE POLICY i_admin  ON app.invites FOR ALL TO app_runtime USING (app.is_admin()) WITH CHECK (app.is_admin());
CREATE POLICY a_admin  ON app.audit_log FOR SELECT TO app_runtime USING (app.is_admin());

-- dados das equipes: leitor lê; operador e gestor escrevem; só gestor apaga
DO $$ DECLARE t text; BEGIN
  FOREACH t IN ARRAY ARRAY['demandas','fornecedores','notas','mailboxes'] LOOP
    EXECUTE format('CREATE POLICY r_select ON app.%I FOR SELECT TO app_runtime USING (app.team_role(team_id) IS NOT NULL)', t);
    EXECUTE format('CREATE POLICY r_insert ON app.%I FOR INSERT TO app_runtime WITH CHECK (app.team_role(team_id) IN (''gestor'',''operador''))', t);
    EXECUTE format('CREATE POLICY r_update ON app.%I FOR UPDATE TO app_runtime USING (app.team_role(team_id) IN (''gestor'',''operador'')) WITH CHECK (app.team_role(team_id) IN (''gestor'',''operador''))', t);
    EXECUTE format('CREATE POLICY r_delete ON app.%I FOR DELETE TO app_runtime USING (app.team_role(team_id) = ''gestor'')', t);
  END LOOP;
END $$;
CREATE POLICY e_select ON app.demanda_eventos FOR SELECT TO app_runtime USING (app.team_role(team_id) IS NOT NULL);
CREATE POLICY e_insert ON app.demanda_eventos FOR INSERT TO app_runtime WITH CHECK (app.team_role(team_id) IN ('gestor','operador') AND user_id = app.current_user_id());
CREATE POLICY s_select ON app.stats_diarios FOR SELECT TO app_runtime USING (app.team_role(team_id) IS NOT NULL);

-- rascunhos: só o dono
CREATE POLICY own ON app.rascunhos_nf TO app_runtime
  USING (user_id = app.current_user_id()) WITH CHECK (user_id = app.current_user_id());

-- app_worker: só o que a leitura da caixa precisa
CREATE POLICY w_all ON app.mailboxes     TO app_worker USING (true) WITH CHECK (true);
CREATE POLICY w_all ON app.demandas      TO app_worker USING (true) WITH CHECK (origem = 'email');
CREATE POLICY w_all ON app.stats_diarios TO app_worker USING (true) WITH CHECK (true);
CREATE POLICY w_ins ON app.demanda_eventos FOR INSERT TO app_worker WITH CHECK (user_id IS NULL);

-- O dono das tabelas (app_owner) também passa pelo RLS forçado: as funções auxiliares
-- SECURITY DEFINER rodam como ele e precisam enxergar membros e usuários.
DO $$ DECLARE t text; BEGIN
  FOREACH t IN ARRAY ARRAY['users','sessions','teams','team_members','invites','password_resets','login_attempts',
    'mailboxes','demandas','demanda_eventos','stats_diarios','fornecedores','notas','rascunhos_nf','audit_log'] LOOP
    EXECUTE format('CREATE POLICY owner_all ON app.%I TO app_owner USING (true) WITH CHECK (true)', t);
  END LOOP;
END $$;

-- Trava: só administrador muda nível ou ativa/desativa contas, mesmo editando a própria linha.
CREATE OR REPLACE FUNCTION app.guard_user_update() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, pg_temp AS $$
BEGIN
  IF current_user = 'app_runtime' AND (NEW.role IS DISTINCT FROM OLD.role OR NEW.is_active IS DISTINCT FROM OLD.is_active) THEN
    IF NOT app.is_admin() THEN
      RAISE EXCEPTION 'apenas administradores alteram nível ou status' USING ERRCODE = '42501';
    END IF;
    IF NEW.id = app.current_user_id() THEN
      RAISE EXCEPTION 'um administrador não pode rebaixar ou desativar a si mesmo' USING ERRCODE = '42501';
    END IF;
  END IF;
  NEW.updated_at := now();
  RETURN NEW;
END $$;
CREATE TRIGGER users_guard BEFORE UPDATE ON app.users FOR EACH ROW EXECUTE FUNCTION app.guard_user_update();

-- Auditoria só cresce: ninguém do app altera ou apaga registros.
REVOKE UPDATE, DELETE, TRUNCATE ON app.audit_log FROM app_auth, app_runtime, app_worker;
