-- Anexos das notas fiscais (PDF e XML), vindos do e-mail ou enviados pelo Leitor de NF.
-- Cada anexo pertence a uma nota; apagar a nota apaga os arquivos dela.

ALTER TABLE app.notas ALTER COLUMN numero_nf DROP NOT NULL;   -- nota escaneada sem número legível
ALTER TABLE app.notas
  ADD COLUMN origem     text NOT NULL DEFAULT 'leitor' CHECK (origem IN ('leitor','email')),
  ADD COLUMN demanda_id uuid REFERENCES app.demandas(id) ON DELETE SET NULL,
  ADD COLUMN avisos     text NOT NULL DEFAULT '' CHECK (length(avisos) <= 1000),
  ADD COLUMN conferir   boolean NOT NULL DEFAULT false;

CREATE TABLE app.anexos (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  team_id    uuid NOT NULL REFERENCES app.teams(id) ON DELETE CASCADE,
  nota_id    uuid NOT NULL REFERENCES app.notas(id) ON DELETE CASCADE,
  origem     text NOT NULL CHECK (origem IN ('leitor','email')),
  message_id text CHECK (length(message_id) <= 400),
  nome       text NOT NULL CHECK (length(nome) BETWEEN 1 AND 200),
  tipo       text NOT NULL CHECK (tipo IN ('pdf','xml')),
  tamanho    integer NOT NULL CHECK (tamanho BETWEEN 1 AND 15728640),
  sha256     text NOT NULL CHECK (sha256 ~ '^[0-9a-f]{64}$'),
  conteudo   bytea NOT NULL,
  created_by uuid REFERENCES app.users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (team_id, sha256)          -- o mesmo arquivo nunca é guardado duas vezes na equipe
);
CREATE INDEX anexos_nota_idx ON app.anexos(nota_id);
-- o anexo precisa ser da mesma equipe da nota
CREATE OR REPLACE FUNCTION app.anexo_mesma_equipe() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, pg_temp AS $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM app.notas n WHERE n.id = NEW.nota_id AND n.team_id = NEW.team_id) THEN
    RAISE EXCEPTION 'anexo e nota de equipes diferentes' USING ERRCODE = '42501';
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER anexo_mesma_equipe BEFORE INSERT OR UPDATE ON app.anexos FOR EACH ROW EXECUTE FUNCTION app.anexo_mesma_equipe();

ALTER TABLE app.anexos ENABLE ROW LEVEL SECURITY;
ALTER TABLE app.anexos FORCE ROW LEVEL SECURITY;

GRANT SELECT, INSERT, DELETE ON app.anexos TO app_runtime;
CREATE POLICY r_select ON app.anexos FOR SELECT TO app_runtime USING (app.team_role(team_id) IS NOT NULL);
CREATE POLICY r_insert ON app.anexos FOR INSERT TO app_runtime
  WITH CHECK (app.team_role(team_id) IN ('gestor','operador') AND origem = 'leitor' AND created_by = app.current_user_id());
CREATE POLICY r_delete ON app.anexos FOR DELETE TO app_runtime USING (app.team_role(team_id) = 'gestor');

-- a leitura da caixa cria notas e anexos de origem e-mail; consulta fornecedores para preencher código e base
GRANT SELECT ON app.fornecedores TO app_worker;
GRANT SELECT, INSERT ON app.notas TO app_worker;
GRANT UPDATE (demanda_id, updated_at) ON app.notas TO app_worker;
GRANT SELECT, INSERT ON app.anexos TO app_worker;
CREATE POLICY w_read ON app.fornecedores FOR SELECT TO app_worker USING (true);
CREATE POLICY w_sel  ON app.notas FOR SELECT TO app_worker USING (true);
CREATE POLICY w_ins  ON app.notas FOR INSERT TO app_worker WITH CHECK (origem = 'email' AND created_by IS NULL);
CREATE POLICY w_upd  ON app.notas FOR UPDATE TO app_worker USING (true) WITH CHECK (true);
CREATE POLICY w_sel  ON app.anexos FOR SELECT TO app_worker USING (true);
CREATE POLICY w_ins  ON app.anexos FOR INSERT TO app_worker WITH CHECK (origem = 'email' AND created_by IS NULL);

CREATE POLICY owner_all ON app.anexos TO app_owner USING (true) WITH CHECK (true);
