-- 003: corrige a trava de alteração de nível.
-- Dentro de uma função SECURITY DEFINER, current_user é o dono da função (app_owner),
-- então a checagem anterior nunca disparava. session_user é quem de fato se conectou.
CREATE OR REPLACE FUNCTION app.guard_user_update() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, pg_temp AS $$
BEGIN
  IF session_user = 'app_runtime' AND (NEW.role IS DISTINCT FROM OLD.role OR NEW.is_active IS DISTINCT FROM OLD.is_active) THEN
    IF NOT app.is_admin() THEN
      RAISE EXCEPTION 'apenas administradores alteram nível ou status' USING ERRCODE = '42501';
    END IF;
    IF NEW.id = app.current_user_id() THEN
      RAISE EXCEPTION 'um administrador não pode rebaixar ou desativar a si mesmo' USING ERRCODE = '42501';
    END IF;
  END IF;
  IF session_user = 'app_runtime' AND NEW.email IS DISTINCT FROM OLD.email THEN
    RAISE EXCEPTION 'e-mail não pode ser alterado por aqui' USING ERRCODE = '42501';
  END IF;
  NEW.updated_at := now();
  RETURN NEW;
END $$;
